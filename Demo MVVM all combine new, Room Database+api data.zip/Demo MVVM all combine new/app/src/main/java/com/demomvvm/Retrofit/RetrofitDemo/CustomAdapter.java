package com.demomvvm.Retrofit.RetrofitDemo;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.demomvvm.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder>  implements Filterable {

    private Context context;
    private List<RetroPhoto> dataSet;
    private List<RetroPhoto> dataList;
    public CustomAdapter(Context context, List<RetroPhoto> dataList)
    {
        this.context = context;
        this.dataSet = (ArrayList<RetroPhoto>) dataList;
        this.dataList = new ArrayList<>(dataList);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater li = LayoutInflater.from(context);
        View v = li.inflate(R.layout.custom_row_retrofit, parent, false);
        return  new CustomViewHolder(v);
    }


    //pass all orders, but show only completed orders == main
    @Override
    public Filter getFilter() {
        return Searched_Filter;
    }
    private Filter Searched_Filter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<RetroPhoto> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                //bydefault show all data     and    remove all filter then show all data
                Log.i("My ","FilterResults dataList size = "+dataList.size());
                filteredList.addAll(dataList);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (RetroPhoto item : dataList) {
                    if (item.getTitle().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                        Log.i("My ","dataSet getCat_name = "+item.getTitle()+" filterPattern = "+filterPattern+" == matched for "+item.getId()); //2021-01-05 00:40:56
                    }
                    else
                    {
                        Log.i("My ","dataSet no any match completed order, getCat_name = "+item.getTitle()+" filterPattern = "+filterPattern+" == matched for "+item.getId()); //2021-01-05 00:40:56
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            dataSet.clear();
            dataSet.addAll((ArrayList)results.values);
            notifyDataSetChanged();
        }
    };


    class CustomViewHolder extends RecyclerView.ViewHolder
    {
        public View myView;
        TextView title, url;
        ImageView img;
        public CustomViewHolder(View itemView) {
            super(itemView);
            myView = itemView;
            title = itemView.findViewById(R.id.title);
            url = myView.findViewById(R.id.url);
            img = myView.findViewById(R.id.img);
        }
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        RetroPhoto dp = dataList.get(position);
        holder.title.setText(dp.getTitle());
        holder.url.setText(dp.getUrl());
        //holder.img.setImageResource(dp.getUrl());




        //Picasso.with(context).load(dp.getThumbnailUrl()).placeholder(R.drawable.ic_launcher_background).into(holder.img);
        Log.i("MY CustomAdapter ","id = "+dp.getId());
        Log.i("MY CustomAdapter ","title = "+dp.getTitle());
        Log.i("MY CustomAdapter ","url = "+dp.getUrl());
        Log.i("MY CustomAdapter ","thumbnailUrl = "+dp.getThumbnailUrl());

        Picasso.get()
                .load(dp.getThumbnailUrl())
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into(holder.img);
        /*Picasso.with(context)
                .load(dp.getThumbnailUrl())
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into(holder.img);*/


        /*Picasso.Builder builder = new Picasso.Builder(context);
        builder.downloader(new OkHttp3Downloader(context));
        builder.build().load(dp.getThumbnailUrl())
        .placeholder(R.drawable.ic_launcher_background)
        .error(R.drawable.ic_launcher_background)
        .into(holder.img);*/
    }
}
