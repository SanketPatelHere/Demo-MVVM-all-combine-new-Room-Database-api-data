package com.demomvvm.whatson;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.demomvvm.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


//WhatsonAdapter of ven ue change from other apps
//for show rv with dot+left/right arrow
public class WhatsonAdapter extends RecyclerView.Adapter<WhatsonAdapter.WhatsonHolder>{
    public String TAG = "Myy WhatsonAdapter ";
    private Context context;
    List<WhatsonPojo> ECompareList;
    private OnItemClickListener listener = null;
    //for prevent multiple fragment open on fast click
    private long mLastClickTime = System.currentTimeMillis();
    private static final long CLICK_TIME_INTERVAL = 300;


    public interface OnItemClickListener {
        void onItemClick(WhatsonPojo item, int possition, String objectItemName, View viewobject);
    }

    public void setListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public OnItemClickListener getListener() {
        return listener;
    }



    public class WhatsonHolder extends RecyclerView.ViewHolder {
        public ImageView imgwhatson;
        public TextView tv_date_whatson;
        public TextView tv_venue_whatson1;
        public TextView tv_title_whatson;
        public TextView tv_address_whatson;
        public TextView tv_subtext_whatson;
        public TextView btnSeeMore;

        public WhatsonHolder(View view)
        {
            super(view);
            imgwhatson = (ImageView) view.findViewById(R.id.imgwhatson);
            tv_venue_whatson1 = (TextView) view.findViewById(R.id.tv_venue_whatson1);
            tv_title_whatson = (TextView) view.findViewById(R.id.tv_title_whatson);
            tv_date_whatson = (TextView) view.findViewById(R.id.tv_date_whatson);
            tv_address_whatson = (TextView) view.findViewById(R.id.tv_address_whatson);
            tv_subtext_whatson = (TextView) view.findViewById(R.id.tv_subtext_whatson);
            btnSeeMore = (TextView) view.findViewById(R.id.btnSeeMore);


            imgwhatson.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        long now = System.currentTimeMillis();
                        if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                            return;
                        }
                        mLastClickTime = now;

                        int possition = getAdapterPosition();

                        if (possition != RecyclerView.NO_POSITION) {
                            listener.onItemClick(ECompareList.get(possition), possition, "imgWhatsonClicked",v);
                        }
                    }
                }
            });


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        long now = System.currentTimeMillis();
                        if (now - mLastClickTime < CLICK_TIME_INTERVAL)
                        {
                            return;
                        }
                        mLastClickTime = now;

                        int possition = getAdapterPosition();

                        if (possition != RecyclerView.NO_POSITION)
                        {
                            listener.onItemClick(ECompareList.get(possition), possition, "imgWhatsonClicked",v);
                        }
                    }
                }
            });
        }

        public void bind(final WhatsonPojo item, final OnItemClickListener listener, int possition) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    long now = System.currentTimeMillis();
                    if (now - mLastClickTime < CLICK_TIME_INTERVAL)
                    {
                        return;
                    }
                    mLastClickTime = now;

                    listener.onItemClick(item,possition,"imgBannereCompare1",v);
                }
            });


        }
    }

    public WhatsonAdapter(Context c, List<WhatsonPojo> cat_list, OnItemClickListener listener) {
        this.context = c;
        this.listener = listener;
        this.ECompareList = cat_list;
    }

    @Override
    public WhatsonHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.whatson_cell, parent, false);
        Log.i(TAG, "parent.getWidth() = "+parent.getWidth());

        //holder.itemView.getLayoutParams().width = getScreenWidth(context)/2; //not proper

        //todo for show 2X2 row
        //error = pages must fill the whole ViewPager2 (use match_parent)
        /*itemView.post(new Runnable() {
            @Override
            public void run() {
                //1/2=0.5
                itemView.getLayoutParams().width = (int) Double.parseDouble(String.valueOf(parent.getWidth() * 0.5));
            }
        });*/


        return new WhatsonHolder(itemView);
    }


    @Override
    public void onBindViewHolder(WhatsonHolder holder, int position) {
        WhatsonPojo whatsonPojo = ECompareList.get(position);

        //todo for show eCompare product image start
        //https://www.bartonsrewards.com.au/upload/event/8.jpg
        //String url_str = "https://www.bartonsrewards.com.au/upload/event/"+whatsonPojo.getEvent_image();
        String url_str = whatsonPojo.getEvent_image();
        Log.i(TAG, "imgwhatson url_str = "+url_str);
        /*Picasso.get()
                .load(url_str)
                .placeholder(R.drawable.img_not_available)
                .error(R.drawable.img_not_available)
                .into(holder.imgwhatson);*/

        Glide.with(context)
                .load(url_str)
                //.diskCacheStrategy(DiskCacheStrategy.NONE)
                //.skipMemoryCache(true)
                .placeholder(R.drawable.img_not_available)
                .error(R.drawable.img_not_available)
                //.transition(DrawableTransitionOptions.withCrossFade()) //Here a fading animation
                //.dontAnimate()
                .into(holder.imgwhatson);
        //todo for show eCompare product image end


        /*
        {"event_id":"49","site_id":"101","event_title":"Saturday Sombero Session",
        "event_seourl":"saturday-sombero-session","event_startdate":"2023-04-15",
        "event_enddate":"2023-04-15",
        "event_desc":"<span>Calling all Mexican and Margarita fans! <\/span><\/span><br \/>\r\n\r\n<span>Miss Mexicana is throwing its first ever Saturday Sombrero Session! Join them for 2 hours of bottomless margaritas and Mexicana bites.<\/span><br \/>\r\n<span>WHEN: Saturday, 15th of April 2023<\/span><br \/>\r\n<span>TIME: 2:00pm - 4:00pm<\/span><br \/>\r\n<span>WHERE: Down Stairs Bar @ Miss Mexicana restaurant - 3\/89 Bay Terrace Wynnum, QLD 4178.<\/span><br \/>\r\n<span>PRICE: $70 per person - Groups of 10+ will receive 10% off their tickets.<\/span><br \/>\r\n<span>Mexicana Bites menu:<\/span><br \/>\r\n<span>-Chips &amp; house-made guacamole and Aji.<\/span><br \/>\r\n<span>-Pork belly bites with Chorizo Crumb Chilli , Plantain Chips, avocado and Aji.<\/span><br \/>\r\n<span>-Selection of tacos including &ndash; chicken, pork, beef and mushroom.<\/span><\/span><br \/>\r\n\r\n<span><br \/>\r\n<span>The drink package includes:<\/span><br \/>\r\n<span>Our signature frozen margaritas, Spicy Margarita, Red Sangria, Tap Beers and a selection of house wines including White, Red and Sparkling.<\/span><br \/>\r\n<span>There&rsquo;s only one thing left to do - reserve the date, book your tickets and message the group chat, grab your friends and get excited.&nbsp;<\/span><\/span><br \/>\r\n\r\n<span><br \/>\r\n<span>* Please note that everyone on the booking is required to participate in the promotion. *<\/span><br \/>\r\n<span>The two-hour session must conclude by 4:00pm.<\/span><\/span><br \/>\r\n"
        ,"event_information":"","event_contact_email":"",
        "event_contact_website":"https:\/\/www.eventbrite.com\/e\/saturday-sombrero-ses",
        "event_displaydate":"2023-03-23","event_image":"49.jpg",
        "event_vanue":"Miss Mexicana - Wynnum","event_facebook":"","event_insta":"",
        "event_twitter":"","event_youtube":"","status":"1"}
         */


        //2023-04-15 => 15 April 2023
        ///holder.tv_date_whatson.setText(whatsonPojo.getEvent_startdate()+" - "+whatsonPojo.getEvent_enddate());
        if (whatsonPojo.getEvent_startdate()!=null && whatsonPojo.getEvent_startdate()!="" && whatsonPojo.getEvent_enddate()!=null && whatsonPojo.getEvent_enddate()!="") {
            String startdate1 = "";
            String enddate1 = "";
            try
            {
                Log.i(TAG, "for startdate1 = " + whatsonPojo.getEvent_startdate());
                Log.i(TAG, "for enddate1 = " + whatsonPojo.getEvent_enddate());

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); //2023-04-15
                Date date = sdf.parse(whatsonPojo.getEvent_startdate());
                Date date2 = sdf.parse(whatsonPojo.getEvent_enddate());

                //sdf.applyPattern("dd MMM yyyy"); //or //15 apr 2023
                SimpleDateFormat newsdf = new SimpleDateFormat("dd MMM yyyy"); //15 apr 2023
                startdate1 = newsdf.format(date);
                enddate1 = newsdf.format(date2);

                Log.i(TAG, "for startdate12 = " + startdate1); //
                Log.i(TAG, "for enddate12 = " + enddate1); //
                //2023-04-15 2023-04-15
                //2023-03-11 2023-04-29  => 11 mar 2023 = M-DD-YY
                holder.tv_date_whatson.setText(startdate1+" - "+enddate1);
            }
            catch(Exception ex)
            {
                //$exjava.lang.IllegalArgumentException: Cannot format given Object as a Date
                //$exjava.text.ParseException: Unparseable date: "2023-04-15"
                //$exjava.text.ParseException: Unparseable date: "2023-03-11"
                Log.i(TAG, "for changeddate Error = $ex"+ex); //$exjava.text.ParseException: Unparseable date: "April 9, 2024"
            }
        }



        String mytexturlVenue = android.text.Html.fromHtml(whatsonPojo.getEvent_vanue()).toString();
        String mytexturl1 = android.text.Html.fromHtml(whatsonPojo.getEvent_title()).toString();
        holder.tv_venue_whatson1.setText(mytexturlVenue);
        holder.tv_title_whatson.setText(mytexturl1);
        holder.tv_address_whatson.setText("\uD83D\uDCCD Venue: ");
        Log.i(TAG, "tv_subtext_whatson before  = "+whatsonPojo.getEvent_desc());
        String mytexturl2 = android.text.Html.fromHtml(whatsonPojo.getEvent_desc()).toString();


        Log.i(TAG, "tv_subtext_whatson after html conversion  = "+mytexturl2);
        //holder.tv_subtext_whatson.setText(whatsonPojo.getEvent_desc());
        holder.tv_subtext_whatson.setText(mytexturl2);


        if(mytexturl2.equals(null) || mytexturl2.equals("null") || mytexturl2.equals(""))
        {
            holder.btnSeeMore.setVisibility(View.INVISIBLE);
        }
        else
        {
            holder.btnSeeMore.setVisibility(View.VISIBLE);
        }
        holder.btnSeeMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG, "btnSeeMore Read more button clicked");


                //todo read more text alert dailog start
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                //set title for alert dialog
                builder.setTitle(mytexturlVenue);
                //set message for alert dialog
                builder.setMessage(mytexturl2);
                //builder.setIcon(android.R.drawable.btn_dialog)

                //performing positive action
                builder.setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.i(TAG, "Close clicked");
                    }
                });


                // Create the AlertDialog
                AlertDialog alertDialog = builder.create();
                // Set other dialog properties
                alertDialog.setCancelable(false);
                alertDialog.show();
                //todo read more text alert dailog end


            }
        });


        holder.bind(ECompareList.get(position), listener, position);
    }

    @Override
    public int getItemCount() {
        return ECompareList.size();

    }


    public static int getScreenWidth(Context context) {
        String TAG = "Myy WhatsonAdapter ";
        WindowManager wm= (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(dm);
        Log.i(TAG, "dm.widthPixels = "+dm.widthPixels);
        return dm.widthPixels;
    }
}
