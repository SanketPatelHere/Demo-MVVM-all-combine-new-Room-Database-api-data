package com.demomvvm.Retrofit

import com.demomvvm.Retrofit.RetrofitDemo.RetroPhoto
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*

interface RestApi {

    @Headers("Content-Type: application/json")
    @POST("user/login")
    //fun addUser(@Body userData: UserInfo): Call<LoginResponse>
    fun addUser(@Body params: HashMap<String,String>): Call<LoginResponse>

    /*@Headers("Content-Type: application/json")
    @POST("login")
    fun addUser(@Body Jo: JSONObject): Call<LoginResponse>*/

    /*@GET("/api/unknown")
    Call<MultipleResource> doGetListResources();*/
    @GET("product/getproductcat")
    fun getAllPhotos(): Call<List<RetroPhoto?>?>?

    @Multipart
    @POST("upload_image.php")
    suspend fun uploadFile(@Part body: MultipartBody.Part)

}