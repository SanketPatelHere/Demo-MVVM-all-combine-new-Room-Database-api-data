package com.demomvvm.HomePageECompareBanner;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.demomvvm.R;
import com.squareup.picasso.Picasso;

import java.util.List;

//for first banner adapter
public class BannerECompareAdapter extends RecyclerView.Adapter<BannerECompareAdapter.BannerECompareHolder>{
//    List list = new ArrayList();
    String TAG = "Myy BannerECompareAdapter ";

    private Context context;
    private List<BannerEComparePojo> ECompareList;
    private String comesActivityName;
    private String bannername; //firstbanner, secondbanner = for change height of secondbanner dynmaic
    private OnItemClickListener listener = null;
    //for prevent multiple fragment open on fast click
    private long mLastClickTime = System.currentTimeMillis();
    private static final long CLICK_TIME_INTERVAL = 300;

    public interface OnItemClickListener {
        void onItemClick(BannerEComparePojo item, int possition, String objectItemName, View viewobject);
    }

    public void setListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public OnItemClickListener getListener() {
        return listener;
    }



    public class BannerECompareHolder extends RecyclerView.ViewHolder {
        public ImageView imgBannereCompare1;

        public BannerECompareHolder(View view) {
            super(view);

            imgBannereCompare1 = (ImageView) view.findViewById(R.id.imgBannereCompare1);


            imgBannereCompare1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        long now = System.currentTimeMillis();
                        if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                            return;
                        }
                        mLastClickTime = now;

                        int possition = getAdapterPosition();

                        if (possition != RecyclerView.NO_POSITION) {
                            listener.onItemClick(ECompareList.get(possition), possition, "imgBannereCompare1",v);
                        }
                    }
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        long now = System.currentTimeMillis();
                        if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                            return;
                        }
                        mLastClickTime = now;

                        int possition = getAdapterPosition();

                        if (possition != RecyclerView.NO_POSITION) {
                            listener.onItemClick(ECompareList.get(possition), possition, "imgBannereCompare1",v);
                        }
                    }
                }
            });
        }

        public void bind(final BannerEComparePojo item, final OnItemClickListener listener, int possition) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    long now = System.currentTimeMillis();
                    if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                        return;
                    }
                    mLastClickTime = now;

                    listener.onItemClick(item,possition,"imgBannereCompare1",v);
                }
            });


        }
    }


    public BannerECompareAdapter(Context c, List<BannerEComparePojo> cat_list, String comesActivityName, String bannername,OnItemClickListener listener) {
        this.context = c;
        this.listener = listener;
        this.ECompareList = cat_list;
        this.comesActivityName = comesActivityName;
        this.bannername = bannername;
    }

    @Override
    public BannerECompareHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.banner_ecompare_cell, parent, false);

        return new BannerECompareHolder(itemView);
    }


    @Override
    public void onBindViewHolder(BannerECompareHolder holder, int position) {
        BannerEComparePojo bannerEComparePojo = ECompareList.get(position);

        //todo for show eCompare product image start
        //https://www.eaglesrewards.com.au/images/epartners-banner1.png
        //String url_str = bannerEComparePojo.getBanner_image();
        //https://www.demomvvm.com.au/aus/images/banner1.png
        //https://www.wemad.com.au/upload/appbanner/1.jpg
        String url_str = context.getString(R.string.api_master_url)+"/upload/appbanner/"+bannerEComparePojo.getBanner_image();
        ///Log.i(TAG, "for "+this.bannername+" url_str = "+url_str);
        Picasso.get()
                .load(url_str)
                .placeholder(R.drawable.img_not_available)
                .error(R.drawable.img_not_available)
                .into(holder.imgBannereCompare1);
        //todo for show eCompare product image end

        holder.bind(ECompareList.get(position), listener, position);
    }

    @Override
    public int getItemCount() {
        return ECompareList.size();
    }


}
