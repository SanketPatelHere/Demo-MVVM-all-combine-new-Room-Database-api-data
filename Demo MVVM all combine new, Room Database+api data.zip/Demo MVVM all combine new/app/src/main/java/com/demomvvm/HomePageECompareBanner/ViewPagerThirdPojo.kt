package com.vsbenefits.ECompare.HomePageECompareBanner

data class ViewPagerThirdPojo(

        var id: String? = "",
        var site_id: String? = "",
        var banner_name: String? = "",
        var banner_image: String? = "",
        var banner_link: String? = "",
        var status: String? = "",
        var banner_cat: String? = ""
)
