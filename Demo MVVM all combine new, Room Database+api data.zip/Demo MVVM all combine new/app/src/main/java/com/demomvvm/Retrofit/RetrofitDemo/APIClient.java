package com.demomvvm.Retrofit.RetrofitDemo;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/*
Retrofit provides with a list of annotations for each of the
HTTP methods: @GET, @POST, @PUT, @DELETE, @PATCH or @HEAD
 */

public class APIClient {
    /*private static Retrofit retrofit = null;

    public static Retrofit getClient()
    {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor).build();

        retrofit = new Retrofit.Builder()
                .baseUrl("https://reqres.in")
                .addConverterFactory(GsonConverterFactory.create())
                //.client(client)
                .build();

        return retrofit;
    }*/

    private static String BASE_URL = "https://jsonplaceholder.typicode.com";
    private static Retrofit retrofit;





    public static Retrofit getRetrofitInstance()
    {
        if(retrofit == null)
        {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
