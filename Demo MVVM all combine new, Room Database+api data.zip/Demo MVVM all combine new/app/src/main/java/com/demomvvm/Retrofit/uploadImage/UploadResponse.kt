package com.demomvvm.Retrofit.uploadImage

data class UploadResponse(

    val error: Boolean,
    val message: String,
    val image: String
)