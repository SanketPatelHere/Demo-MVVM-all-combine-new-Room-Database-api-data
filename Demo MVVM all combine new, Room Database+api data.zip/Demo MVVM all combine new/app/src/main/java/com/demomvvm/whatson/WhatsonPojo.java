package com.demomvvm.whatson;

//WhatsonPojo = events[]
public class WhatsonPojo {
    private String event_id, site_id, event_title, event_seourl
            ,event_startdate, event_enddate, event_displaydate,
            event_desc, event_information, event_contact_email, event_contact_website,
            event_image, event_facebook, event_insta, event_twitter, event_youtube, status,
            event_vanue;

    public WhatsonPojo()
    {

    }

    public WhatsonPojo(String event_id, String site_id, String event_title, String event_seourl, String event_startdate, String event_enddate, String event_displaydate, String event_desc, String event_information, String event_contact_email, String event_contact_website, String event_image, String event_facebook, String event_insta, String event_twitter, String event_youtube, String status) {
        this.event_id = event_id;
        this.site_id = site_id;
        this.event_title = event_title;
        this.event_seourl = event_seourl;
        this.event_startdate = event_startdate;
        this.event_enddate = event_enddate;
        this.event_displaydate = event_displaydate;
        this.event_desc = event_desc;
        this.event_information = event_information;
        this.event_contact_email = event_contact_email;
        this.event_contact_website = event_contact_website;
        this.event_image = event_image;
        this.event_facebook = event_facebook;
        this.event_insta = event_insta;
        this.event_twitter = event_twitter;
        this.event_youtube = event_youtube;
        this.status = status;
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getSite_id() {
        return site_id;
    }

    public void setSite_id(String site_id) {
        this.site_id = site_id;
    }

    public String getEvent_title() {
        return event_title;
    }

    public void setEvent_title(String event_title) {
        this.event_title = event_title;
    }

    public String getEvent_seourl() {
        return event_seourl;
    }

    public void setEvent_seourl(String event_seourl) {
        this.event_seourl = event_seourl;
    }

    public String getEvent_startdate() {
        return event_startdate;
    }

    public void setEvent_startdate(String event_startdate) {
        this.event_startdate = event_startdate;
    }

    public String getEvent_enddate() {
        return event_enddate;
    }

    public void setEvent_enddate(String event_enddate) {
        this.event_enddate = event_enddate;
    }

    public String getEvent_displaydate() {
        return event_displaydate;
    }

    public void setEvent_displaydate(String event_displaydate) {
        this.event_displaydate = event_displaydate;
    }

    public String getEvent_desc() {
        return event_desc;
    }

    public void setEvent_desc(String event_desc) {
        this.event_desc = event_desc;
    }

    public String getEvent_information() {
        return event_information;
    }

    public void setEvent_information(String event_information) {
        this.event_information = event_information;
    }

    public String getEvent_contact_email() {
        return event_contact_email;
    }

    public void setEvent_contact_email(String event_contact_email) {
        this.event_contact_email = event_contact_email;
    }

    public String getEvent_contact_website() {
        return event_contact_website;
    }

    public void setEvent_contact_website(String event_contact_website) {
        this.event_contact_website = event_contact_website;
    }

    public String getEvent_image() {
        return event_image;
    }

    public void setEvent_image(String event_image) {
        this.event_image = event_image;
    }

    public String getEvent_facebook() {
        return event_facebook;
    }

    public void setEvent_facebook(String event_facebook) {
        this.event_facebook = event_facebook;
    }

    public String getEvent_insta() {
        return event_insta;
    }

    public void setEvent_insta(String event_insta) {
        this.event_insta = event_insta;
    }

    public String getEvent_twitter() {
        return event_twitter;
    }

    public void setEvent_twitter(String event_twitter) {
        this.event_twitter = event_twitter;
    }

    public String getEvent_youtube() {
        return event_youtube;
    }

    public void setEvent_youtube(String event_youtube) {
        this.event_youtube = event_youtube;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEvent_vanue() {
        return event_vanue;
    }

    public void setEvent_vanue(String event_vanue) {
        this.event_vanue = event_vanue;
    }
}
