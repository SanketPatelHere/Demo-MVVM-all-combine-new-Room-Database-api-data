package com.demomvvm.Volley

import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.AuthFailureError
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.demomvvm.R
import com.demomvvm.Singleton
import com.demomvvm.databinding.ActivityMyVolleyBinding
import org.json.JSONObject

class MyVolleyActivity : AppCompatActivity() {

    var volleyRequestQueue: RequestQueue? = null
    var dialog: ProgressDialog? = null
    val serverAPIURL: String = "https://www.vaishalimobile.com/app/user/login"


    private lateinit var binding: ActivityMyVolleyBinding ////activity_my_volley
        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyVolleyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))
        window.navigationBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))

        val email1 = "parmarsamir44@gmail.com"
        val password = "Parmar@9033"
        SendSignUpDataToServer(email1, password)

    }

    fun SendSignUpDataToServer(email: String, password: String)
    {
        volleyRequestQueue = Volley.newRequestQueue(this)
        dialog = ProgressDialog.show(this, "", "Please wait...", true);
        val parameters: HashMap<String, String> = HashMap()
        // Add your parameters in HashMap
        parameters.put("email",email);
        parameters.put("password",password);
        Log.i("Myy  ", "MyVolleyActivity volley parameters1 = " + parameters)

        val strReq: StringRequest = object : StringRequest(
            Method.POST,serverAPIURL,
            Response.Listener { response ->
                Log.i("Myy  ", "MyVolleyActivity volley response: " + response)
                dialog?.dismiss()
                // Handle Server response here
                try {
                    val responseObj = JSONObject(response)
                    Log.i("My ", "MyVolleyActivity volley  responseObj = "+responseObj)

                    var username = ""
                    var useremail = ""

                    val isSuccess = responseObj.getString("status") //200
                    val message = responseObj.getString("message")
                    if(responseObj.has("data"))
                    {
                        val data = responseObj.getJSONArray("data")
                        Log.i("My ", "MyVolleyActivity volley  data = "+data)
                        for (j in 0 until data.length()) {
                            val data_dic = data.getJSONObject(j)
                            if(data_dic.has("username"))
                            {
                                username = data_dic.getString("username")
                                Log.i("My ", "MyVolleyActivity volley  username = "+username)
                            }
                            if(data_dic.has("useremail"))
                            {
                                useremail = data_dic.getString("useremail")
                                Log.i("My ", "MyVolleyActivity volley  useremail = "+useremail)
                            }
                            binding.tvResText.text = "Details: $data \n\nUsername = "+username+"\nEmail = "+useremail
                        }

                    }
                    else
                    {
                        binding.tvResText.text = "Details: $responseObj"
                    }
                    Toast.makeText(this,message,Toast.LENGTH_LONG).show()

                } catch (e: Exception) { // caught while parsing the response
                    Log.i("My ", "MyVolleyActivity volley catch problem occurred e = "+e)
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { volleyError -> // erro
                Log.i("Myy  ", "MyVolleyActivity volley error = " + volleyError.message)
            }) {

            override fun getParams(): MutableMap<String, String> {
                Log.i("Myy  ", "MyVolleyActivity volley parameters2 = " + parameters)
                return parameters;
            }

            @Throws(AuthFailureError::class)
            override fun getHeaders(): Map<String, String> {
                val credentials = "vaishalimobile" + ":" + "nHNfTwfu!)Sq7m06J7f8yzq45"
                val base64EncodedCredentials: String =
                    Base64.encodeToString(credentials.toByteArray(), Base64.NO_WRAP)
                val headers: HashMap<String, String> = HashMap()
                headers["Authorization"] = "Basic $base64EncodedCredentials"
                return headers
            }
        }
        // Adding request to request queue
        volleyRequestQueue?.add(strReq)
    }


    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}