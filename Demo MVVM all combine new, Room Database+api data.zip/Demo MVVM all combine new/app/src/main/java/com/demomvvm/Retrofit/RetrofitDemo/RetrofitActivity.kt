package com.demomvvm.Retrofit.RetrofitDemo

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.demomvvm.R
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

//not use this
@SuppressLint("LongLogTag")
class RetrofitActivity : AppCompatActivity() {
    public var responseText: TextView? = null
    public var apiInterface: APIInterface? = null
    var progressDialog: ProgressDialog? = null
    private var rv1: RecyclerView? = null
    private var adapter: CustomAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_retrofit)
        //apiInterface = APIClient.getClient().create(APIInterface::class.java)





        progressDialog = ProgressDialog(this@RetrofitActivity)
        progressDialog?.setMessage("Loading...")
        progressDialog?.show()

        val service: APIInterface = APIClient.getRetrofitInstance().create(APIInterface::class.java)
        val call: Call<List<RetroPhoto>> = service?.getAllPhotos()!!
        call.enqueue(object : Callback<List<RetroPhoto>?> {
            override fun onResponse(
                call: Call<List<RetroPhoto>?>,
                response: Response<List<RetroPhoto>?>
            ) {
                Log.i("My Retrofit Response = ", response.toString() + "")
                progressDialog?.dismiss()
                val photos = response.body()
                generateDataList(photos)
            }
            override fun onFailure(call: Call<List<RetroPhoto>?>, t: Throwable) {
                progressDialog?.dismiss()
                Log.i("My Retrofit Data not loading = ", t.toString())
                Toast.makeText(applicationContext, "Data not load", Toast.LENGTH_SHORT).show()
            }


        })


    }

    fun generateDataList(photoList: List<RetroPhoto?>?) {
        rv1 = findViewById<View>(R.id.rv1) as RecyclerView
        adapter = CustomAdapter(this, photoList)
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this@RetrofitActivity)
        rv1?.setLayoutManager(layoutManager)
        rv1?.setAdapter(adapter)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}
