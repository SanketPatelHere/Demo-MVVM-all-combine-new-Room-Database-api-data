package com.demomvvm.SearchFilter.AllProductsSearch;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.demomvvm.R;
import com.squareup.picasso.Picasso;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.List;

@SuppressLint("LongLogTag")
public class SearchProductsAdapter extends RecyclerView.Adapter<SearchProductsAdapter.ProductHolder> implements Filterable {
    private List<SearchProductsModel> dataSet;
    private List<SearchProductsModel> FullList;

    private OnItemClickListener listener = null;
    private Context context = null;
    //for prevent multiple fragment open on fast click
    private long mLastClickTime = System.currentTimeMillis();
    private static final long CLICK_TIME_INTERVAL = 300;

    final Handler enable = new Handler();
    final Handler disable = new Handler();



    //pass all orders, but show only completed orders == main
    @Override
    public Filter getFilter() {
        return Searched_Filter;
    }
    private Filter Searched_Filter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<SearchProductsModel> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                //bydefault show all data     and    remove all filter then show all data
                Log.i("My ","FilterResults FullList size = "+FullList.size());
                filteredList.addAll(FullList);
            }
            else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (SearchProductsModel item : FullList) {
                    if (item.getProductname().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                        Log.i("My ","dataSet getCat_name = "+item.getProductname()+" filterPattern = "+filterPattern+" == Prd_id ="+item.getPrd_id()); //2021-01-05 00:40:56
                    }
                    else
                    {
                        Log.i("My ","dataSet no any match completed order, getCat_name = "+item.getProductname()+" filterPattern = "+filterPattern+" == Prd_id ="+item.getPrd_id()); //2021-01-05 00:40:56
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            dataSet.clear();
            dataSet.addAll((ArrayList)results.values);
            notifyDataSetChanged();
        }
    };






    public interface OnItemClickListener {
        void onItemClick(SearchProductsModel item, int possition, String objectItemName, View viewobject);
    }

    public void setListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public OnItemClickListener getListener() {
        return listener;
    }





    public class ProductHolder extends RecyclerView.ViewHolder {
        public ImageView img_product;
        public TextView txt_productname;


        public ProductHolder(View view) {
            super(view);
            img_product = (ImageView) view.findViewById(R.id.img_product);
            txt_productname = (TextView) view.findViewById(R.id.txt_productname);

            img_product.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int possition = getAdapterPosition();
                        if (possition != RecyclerView.NO_POSITION) {
                            listener.onItemClick(dataSet.get(possition), possition, "img_click",view);
                        }
                    }
                }
            });
        }

        public void bind(final SearchProductsModel item, final OnItemClickListener listener, int possition){

        }
    }


    public SearchProductsAdapter(List<SearchProductsModel> myCharityList) {
        this.listener = listener;
        this.FullList = myCharityList;
    }
   /* public SearchProductsAdapter(List<AllProductsPojo> myCharityList) {
        this.FullList = myCharityList;
    }*/

    public SearchProductsAdapter(@Nullable Context c, @NotNull ArrayList<SearchProductsModel> myCharityList) {
        this.context = c;
        this.listener = listener;
        this.dataSet = (ArrayList<SearchProductsModel>) myCharityList;
        FullList = new ArrayList<>(myCharityList);
        Log.i("My ","ProductAdapter cat_list.size = "+myCharityList.size());
        Log.i("My ","ProductAdapter dataSet.size = "+dataSet.size());
        Log.i("My ","ProductAdapter FullList.size = "+FullList.size());
    }

    @Override
    public ProductHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cell_product_categories, parent, false);

        return new ProductHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ProductHolder holder, int position) {


        SearchProductsModel productPojo1 = dataSet.get(position);
        holder.txt_productname.setText(productPojo1.getProductname());

        //For product
        //https://www.vaishalimobile.in/upload/product/36.jpg
        String url_str = "https://www.vaishalimobile.com/upload/product/"+productPojo1.getPrd_id()+"/"+String.valueOf(productPojo1.getPrd_image());
        Log.i("My ProductAdapter ","productPojo1 txt_productname = "+productPojo1.getProductname());
        Log.i("My ProductAdapter ","productPojo1 image getCat_img = "+url_str);
        Picasso.get()
                .load(url_str)
                .placeholder(R.drawable.app_icon1)
                .error(R.drawable.app_icon1)
                .into(holder.img_product);


        holder.bind(dataSet.get(position), listener, position);


    }




    @Override
    public int getItemCount() {
        return dataSet.size();
    }
}
