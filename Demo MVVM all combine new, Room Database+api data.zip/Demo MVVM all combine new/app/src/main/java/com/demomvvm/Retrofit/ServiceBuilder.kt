package com.demomvvm.Retrofit

import android.util.Base64
import okhttp3.Credentials
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.nio.charset.StandardCharsets

object ServiceBuilder {

    private val client = OkHttpClient.Builder().addInterceptor(BasicAuthInterceptor()).build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://www.vaishalimobile.com/app/") // change this IP for testing by your actual machine IP
        .addConverterFactory(GsonConverterFactory.create())
        .client(client)
        .build()

    fun<T> buildService(service: Class<T>): T{
        return retrofit.create(service)
    }

    class BasicAuthInterceptor(): Interceptor {
        var credentials = "vaishalimobile" + ":" + "nHNfTwfu!)Sq7m06J7f8yzq45"
        var base64EncodedCredentials = Base64.encodeToString(credentials.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
        override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
            var request = chain.request()
            request = request.newBuilder().header("Authorization", "Basic "+base64EncodedCredentials).build()

            return chain.proceed(request)
        }
    }
}