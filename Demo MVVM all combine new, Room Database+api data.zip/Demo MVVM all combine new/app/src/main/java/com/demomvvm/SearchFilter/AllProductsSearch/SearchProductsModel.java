package com.demomvvm.SearchFilter.AllProductsSearch;

//cart json
public class SearchProductsModel {

    private String prd_id, cat_id, brand_id, productname, prd_image, newprd_image, productdescription, status, prd_price, ecard_selected_qnty,prd_splprice;
    private String stock;
    private String min_stock;
    //private String item_color=""; //for selected color save
    private String item_color; //for selected color save
    private String[] item_color2; //for show all array
    private String item_color3; //for show all string - inner detail activity
    private String item_color4; //for show all string - outer adapter
    private String best_seller;
    private String new_product;

    public SearchProductsModel() {
    }

    public SearchProductsModel(String prd_id, String cat_id, String brand_id, String productname, String prd_image, String newprd_image, String productdescription, String status, String prd_price, String prd_splprice, String stock, String min_stock) {
        this.prd_id = prd_id;
        this.cat_id = cat_id;
        this.brand_id = brand_id;
        this.productname = productname;
        this.prd_image = prd_image;
        this.newprd_image = newprd_image;
        this.productdescription = productdescription;
        this.status = status;
        this.prd_price = prd_price;
        this.prd_splprice = prd_splprice;
        this.stock = stock;
        this.min_stock = min_stock;
    }

    public SearchProductsModel(String prd_id, String cat_id, String brand_id, String productname, String prd_image, String newprd_image, String productdescription, String status, String prd_price, String prd_splprice, String stock, String min_stock, String item_color) {
        this.prd_id = prd_id;
        this.cat_id = cat_id;
        this.brand_id = brand_id;
        this.productname = productname;
        this.prd_image = prd_image;
        this.newprd_image = newprd_image;
        this.productdescription = productdescription;
        this.status = status;
        this.prd_price = prd_price;
        this.prd_splprice = prd_splprice;
        this.stock = stock;
        this.min_stock = min_stock;
        this.item_color = item_color;
    }

    public SearchProductsModel(String prd_id, String cat_id, String brand_id, String productname, String prd_image, String newprd_image, String productdescription, String status, String prd_price, String prd_splprice, String stock, String min_stock, String[] item_color2) {
        this.prd_id = prd_id;
        this.cat_id = cat_id;
        this.brand_id = brand_id;
        this.productname = productname;
        this.prd_image = prd_image;
        this.newprd_image = newprd_image;
        this.productdescription = productdescription;
        this.status = status;
        this.prd_price = prd_price;
        this.prd_splprice = prd_splprice;
        this.stock = stock;
        this.min_stock = min_stock;
        this.item_color2 = item_color2;
    }

    public String getEcard_selected_qnty() {
        return ecard_selected_qnty;
    }

    public void setEcard_selected_qnty(String ecard_selected_qnty) {
        this.ecard_selected_qnty = ecard_selected_qnty;
    }

    public String getPrd_id() {
        return prd_id;
    }

    public void setPrd_id(String prd_id) {
        this.prd_id = prd_id;
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getBrand_id() {
        return brand_id;
    }

    public void setBrand_id(String brand_id) {
        this.brand_id = brand_id;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getPrd_image() {
        return prd_image;
    }

    public void setPrd_image(String prd_image) {
        this.prd_image = prd_image;
    }

    public String getNewprd_image() {
        return newprd_image;
    }

    public void setNewprd_image(String newprd_image) {
        this.newprd_image = newprd_image;
    }

    public String getProductdescription() {
        return productdescription;
    }

    public void setProductdescription(String productdescription) {
        this.productdescription = productdescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPrd_price() {
        return prd_price;
    }

    public void setPrd_price(String prd_price) {
        this.prd_price = prd_price;
    }

    public String getPrd_splprice() {
        return prd_splprice;
    }

    public void setPrd_splprice(String prd_splprice) {
        this.prd_splprice = prd_splprice;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getMin_stock() {
        return min_stock;
    }

    public void setMin_stock(String min_stock) {
        this.min_stock = min_stock;
    }

    public String getItem_color() {
        return item_color;
    }

    public void setItem_color(String item_color) {
        this.item_color = item_color;
    }

    public String[] getItem_color2() {
        return item_color2;
    }

    public void setItem_color2(String[] item_color2) {
        this.item_color2 = item_color2;
    }

    public String getBest_seller() {
        return best_seller;
    }

    public void setBest_seller(String best_seller) {
        this.best_seller = best_seller;
    }

    public String getNew_product() {
        return new_product;
    }

    public void setNew_product(String new_product) {
        this.new_product = new_product;
    }

    public String getItem_color3() {
        return item_color3;
    }

    public void setItem_color3(String item_color3) {
        this.item_color3 = item_color3;
    }

    public String getItem_color4() {
        return item_color4;
    }

    public void setItem_color4(String item_color4) {
        this.item_color4 = item_color4;
    }
}
