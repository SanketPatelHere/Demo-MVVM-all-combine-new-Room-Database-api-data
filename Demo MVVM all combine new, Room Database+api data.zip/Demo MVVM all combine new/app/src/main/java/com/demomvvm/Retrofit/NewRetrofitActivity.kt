package com.demomvvm.Retrofit

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.demomvvm.LoadMoreRecycleView.LoadMoreRecycleViewActivity
import com.demomvvm.R
import com.demomvvm.Retrofit.RetrofitDemo.APIClient
import com.demomvvm.Retrofit.RetrofitDemo.APIInterface
import com.demomvvm.Retrofit.RetrofitDemo.CustomAdapter
import com.demomvvm.Retrofit.RetrofitDemo.RetroPhoto
import com.demomvvm.Retrofit.uploadImage.*
import com.demomvvm.Singleton
import com.demomvvm.databinding.ActivityNewRetofitBinding
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.yalantis.ucrop.UCrop
import com.yalantis.ucrop.UCropFragment
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.util.*
import kotlin.collections.HashMap


//retrofit example = https://www.digitalocean.com/community/tutorials/retrofit-android-example-tutorial
//for image upload
@SuppressLint("LongLogTag")
class NewRetrofitActivity : AppCompatActivity(), UploadRequestBody.UploadCallback  {

    private var rv1: RecyclerView? = null
    private var adapter: CustomAdapter? = null


    // ----------------------------------- Image Upload
    private  val requestGallery = 2121
    private var selectedImageUri: Uri? = null

    private var requestMode = 1
    private val REQUEST_SELECT_PICTURE_FOR_FRAGMENT = 0x02
    var photoFile: File? = null
    val REQUEST_CODE_IMAGE = 101

    val PERMISSIONS = arrayOf(
        android.Manifest.permission.CAMERA,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
        android.Manifest.permission.READ_EXTERNAL_STORAGE)
    val PERMISSION_ALL = 1

    lateinit var uploadimageUri: Uri
    var uploadimage = ""// API
    var imagename = ""// API
    private var mPictureUri: Uri? = null

    val PICK_IMAGE = 100
    var service: ImageUploadServiceInterface? = null



    private lateinit var binding: ActivityNewRetofitBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewRetofitBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))
        window.navigationBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))


        binding.get.setOnClickListener {
            binding.progressBarNewRetrofitActivity.visibility = View.VISIBLE
            val service: APIInterface = APIClient.getRetrofitInstance().create(APIInterface::class.java)
            val call: Call<List<RetroPhoto>> = service.getAllPhotos()!!
            call.enqueue(object : Callback<List<RetroPhoto>?> {
                override fun onResponse(call: Call<List<RetroPhoto>?>, response: Response<List<RetroPhoto>?>) {
                    Log.i("My NewRetrofit ActivityRetrofit Response = ", response.toString() + "")
                    val photos = response.body()
                    generateDataList(photos)
                }
                override fun onFailure(call: Call<List<RetroPhoto>?>, t: Throwable) {
                    binding.progressBarNewRetrofitActivity.visibility = View.INVISIBLE
                    Log.i("My NewRetrofitActivity Retrofit Data not loading = ", t.toString())
                    Toast.makeText(applicationContext, "Something Went Wrong!", Toast.LENGTH_SHORT).show()
                }
            })
        }

        binding.post.setOnClickListener {
            binding.progressBarNewRetrofitActivity.visibility = View.VISIBLE
            /*val userInfo = UserInfo("citadelind4@gmail.com","1234")

            val userInfo = JSONObject()
            userInfo.put("email", "citadelind4@gmail.com")
            userInfo.put("password", "1234")*/

            val hashMap : HashMap<String, String> = HashMap()
            hashMap["email"] = "parmarsamir44@gmail.com"
            hashMap["password"] = "Parmar@9033"
            /*hashMap.put("email", "citadelind4@gmail.com")
            hashMap.put("password", "1234")*/

            val retrofit = ServiceBuilder.buildService(RestApi::class.java)
            retrofit.addUser(hashMap).enqueue(
                object : Callback<LoginResponse> {
                    override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                        binding.progressBarNewRetrofitActivity.visibility = View.INVISIBLE

                        val jsonObject = JSONObject(Gson().toJson(response.body()));
                        Log.i("My NewRetrofitActivity onResponse response jsonObject= ",""+jsonObject.toString()) //{"message":"wrong username or password!","status":"102"}

                        val status = jsonObject.getString("status")
                        val message = jsonObject.getString("message");
                        Log.i("My NewRetrofitActivity onResponse response status= ",""+status.toString())
                        Log.i("My NewRetrofitActivity onResponse response message= ",""+message.toString())
                        if(status.equals("200"))
                        {
                            val data = jsonObject.getString("data");
                            Log.i("My NewRetrofitActivity onResponse response data= ",""+data.toString())
                            /*val jsonObject2 = JSONObject(Gson().toJson(data));
                            val user_id = jsonObject2.getString("user_id")
                            Log.i("My NewRetrofitActivity onResponse response user_id= ",""+user_id.toString())*/

                            //val userName: String = response.body().getUsername() //when use Call<Result>
                            //val level: String = response.body().getLevel()

                            /*
                            List<UserList.Datum> datumList = response.body()?.data;
                            Toast.makeText(getApplicationContext(), text + " page\n" + total + " total\n" + totalPages + " totalPages\n", Toast.LENGTH_SHORT).show();

                            for (UserList.Datum datum : datumList) {
                                Toast.makeText(getApplicationContext(), "id : " + datum.id + " name: " + datum.first_name + " " + datum.last_name + " avatar: " + datum.avatar, Toast.LENGTH_SHORT).show();
                            }
                             */

                            val userInfo = response.body()
                            Log.i("My NewRetrofitActivity onResponse response = ",""+response.toString())
                            Log.i("My NewRetrofitActivity onResponse userInfo = ",""+userInfo.toString())
                            Log.i("My NewRetrofitActivity onResponse response body status= ",""+response.body()?.status.toString())
                            Log.i("My NewRetrofitActivity onResponse response body message= ",""+response.body()?.message.toString())
                            Log.i("My NewRetrofitActivity onResponse response body data= ",""+response.body()?.data.toString())

                            /*
         My onRespo...body data=  [{"user_id":"194","username":"SAMIR  PARMAR",
         "userpassword":"8705139ea2bd95eee2605fa8645358f4","useremail":"parmarsamir44@gmail.com",
         "usermobile":"8530000538","companyname":"VMS ZONE",
         "date":"2024-05-25 08:12:19","usr_lastlogin":"","ip":"43.250.156.208",
         "profileimage":"","address":"RAMDEV PIR CHOKDI","status":"1",
         "subscribe":"1","device_id":"UP1A.231005.007","model":"SM-A346E"
         ,"osversion":"14","platform":"Android",
         "devicetoken":"f9TbwCpWRwaohJ2kXF7pYx:APA91bHYuSS4ghe3vYZnx7_JLKtuVW1aN1BiD8FP7qB4VfoK29rF9Ee3SGoev2e04kMNh8xnM7plwkTrwpCDoWcvuM0zDG7SkegSQGrJtesJ5sBbZD9PWSDpEd7zhGbJYkrn9G8uc53w",
         "uuid":"6621e59814057aedsss","filetype":"","file_url":"194.jpg","fileurl2":"194-1.jpg"}]

                             */




                            /*Log.i("My NewRetrofitActivity onResponse response isSuccessful= ",""+response.isSuccessful.toString())
                            Log.i("My NewRetrofitActivity onResponse response errorBody= ",""+response.errorBody().toString())*/
                            binding.details.text = "Details: " + response.body()?.data.toString()
                        }
                        else
                        {
                            binding.details.text = "Details: " + jsonObject.toString()
                        }


                    }
                    override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                        binding.progressBarNewRetrofitActivity.visibility = View.INVISIBLE
                        Log.i("My NewRetrofitActivity onFailure call = ",""+call.toString())
                        Log.i("My NewRetrofitActivity onFailure t = ",""+t.toString())
                        binding.details.text ="Something Went Wrong!"
                    }
                }
            )

        }

        binding.selectImage.setOnClickListener {
//            val intent1 = Intent(this, NewRetrofitActivity::class.java)
//            startActivity(intent1)
            if(!hasPermissions(applicationContext, *PERMISSIONS))
            {
                Log.i("My NewRetrofitActivity camera_btn ", "clicked not hasPermissions")
                ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL)
            }
            else
            {
                Log.i("My NewRetrofitActivity camera_btn ", "clicked yes hasPermissions = go for crop image")
                try {
                    //selelct from only gallery
                    val intent = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
                    val mimeTypes = arrayOf("image/jpeg", "image/png") //After
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
                    /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) { //Before
                        val mimeTypes = arrayOf("image/jpeg", "image/png")
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
                    }*/
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), requestMode)
                } catch (ex: Exception) {
                    Log.i("My NewRetrofitActivity Error NewRetrofitActivity ", "in take or select image")
                }
            }
            //ImagePicker.with(this).start(requestGallery)
        }
        binding.upload.setOnClickListener {
            if(uploadimage!=""){
                uploadImage111()
            }
            else{
                binding.mainContainer.snackbar("Select An Image!")
            }
        }



        // Coroutine
        /*main()
        main2()
        main3()*/

    }

    /*fun main() = runBlocking { // this: CoroutineScope
        launch { doWorld() }
        println("My NewRetrofitActivity main() Hello")
    }
    // this is your first suspending function
    suspend fun doWorld() {
        delay(2000L)
        println("My NewRetrofitActivity main() World!")
    }

    // Sequentially executes doWorld followed by "Done"
    fun main2() = runBlocking {
        doWorld2()
        println("My NewRetrofitActivity main2() Done")
    }
    // Concurrently executes both sections
    suspend fun doWorld2() = coroutineScope { // this: CoroutineScope
        launch {
            delay(2000L)
            println("My NewRetrofitActivity main2() World 2")
        }
        launch {
            delay(1000L)
            println("My NewRetrofitActivity main2() World 1")
        }
        println("My NewRetrofitActivity main2() Hello")
    }

    fun main3() = runBlocking {
        val job = launch { // launch a new coroutine and keep a reference to its Job
            delay(1000L)
            println("My NewRetrofitActivity main3() World!")
        }
        println("My NewRetrofitActivity main3() Hello")
        job.join() // wait until child coroutine completes
        println("My NewRetrofitActivity main3() Done")
    }*/





    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        try {

            if(requestCode == 0)
            {
                val tsLong = System.currentTimeMillis()
                val ts = tsLong.toString()
                Log.i("My NewRetrofitActivity onActivityResult ", "requestCode = 0")
                if (data != null) {
                    selectedImageUri = data.data
                    Log.i("My NewRetrofitActivity selectedImageUri ", "from1 data $selectedImageUri") //for both jpg,jpeg
                    selectedImageUri?.let { startCrop(it) }
                }
                else if (selectedImageUri == null) {
                    selectedImageUri = mPictureUri
                    selectedImageUri?.let { startCrop(it) }
                    Log.i("My NewRetrofitActivity selectedImageUri ", "from2 mPictureUri $selectedImageUri")
                }
            }

            else if (resultCode == RESULT_OK) {
                Log.i("My NewRetrofitActivity onActivityResult ", "requestCode = 0 RESULT_OK")
                if (requestCode == requestMode) {
                    Log.i("My NewRetrofitActivity onActivityResult ", "from3 requestCode requestMode = $requestMode")

                    val selectedUri = data?.data
                    if (selectedUri != null) {
                        startCrop(selectedUri)
                    } else {
                        Toast.makeText(applicationContext, "Cannot retrieve selected image", Toast.LENGTH_SHORT).show()
                    }
                }
                else if (requestCode == UCrop.REQUEST_CROP) {
                    Log.i("My NewRetrofitActivity onActivityResult ", "from4 requestCode = REQUEST_CROP")
                    data?.let { handleCropResult(it) }
                    Log.i("My NewRetrofitActivity Error ", "onActivityResult else if")
                }
            }
            else if (resultCode == UCrop.RESULT_ERROR) {
                Log.i("My NewRetrofitActivity onActivityResult ", "from5 requestCode = RESULT_ERROR")
                data?.let { handleCropError(it) }
                Log.i("My NewRetrofitActivity Error ", "onActivityResult if")
            }


        } catch (ex: java.lang.Exception) {
            Log.i("My NewRetrofitActivity Error NewRetrofitActivity", "onActivityResult ex = $ex")
        }

    }

    private fun startCrop(uri: Uri) {
        val destinationFileName: String = "SampleCropImage.jpg"

        var uCrop: UCrop = UCrop.of(uri, Uri.fromFile(File(cacheDir, destinationFileName)))

        try {
            uCrop = advancedConfig(uCrop)
            val ratioX: Float = java.lang.Float.valueOf("5")
            val ratioY: Float = java.lang.Float.valueOf("4")
            if (ratioX > 0 && ratioY > 0) {
                uCrop = uCrop.withAspectRatio(ratioX, ratioY)
            }
        } catch (e: Exception) {
            Log.i("My NewRetrofitActivity startCrop ", String.format("Number please: %s", e))
        }
        if (requestMode == REQUEST_SELECT_PICTURE_FOR_FRAGMENT) {
            setupFragment(uCrop)
        } else {
            uCrop.start(this@NewRetrofitActivity)
        }
    }

    open fun setupFragment(uCrop: UCrop) {
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, UCropFragment(), UCropFragment.TAG)
            .commitAllowingStateLoss()
    }

    private fun handleCropResult(result: Intent) {
        val resultUri = UCrop.getOutput(result)
        if (resultUri != null) {

            val iv: ImageView = findViewById<View>(R.id.couponImage) as ImageView

            iv.setImageURI(null)
            iv.setImageURI(resultUri)

            uploadimageUri = resultUri
            //file:///data/user/0/com.example.androiddemo/cache/SampleCropImage.jpg
            Log.i("My NewRetrofitActivity handleCropResult ", "uploadimageUri = "+ uploadimageUri)

            val tsLong = System.currentTimeMillis()
            val ts = tsLong.toString()
            val fileName: String = "app_" + ts + ".jpg" //for concate date and time = app_1613638967094
            uploadimage = fileName
            //app_1673503879335.jpg
            Log.i("My NewRetrofitActivity handleCropResult ", "uploadimage = "+ uploadimage)
            var f1 : File = File(fileName)
            Log.i("My NewRetrofitActivity handleCropResult ", "file f1 = "+ f1) //app_1673504209219



            //Uri.parse(fileUri.toString())
            //val requestFile2 = result.asRequestBody(contentResolver.getType(resultUri)?.toMediaTypeOrNull())
            val requestFile = f1.asRequestBody(contentResolver.getType(resultUri)?.toMediaTypeOrNull())
            val body = MultipartBody.Part.createFormData("image", fileName, requestFile)
            Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity requestFile = $requestFile")
            Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity file.name = $fileName")
            Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity body = $body")




/*
RetrofitUploadImageActivity onFailure = java.io.FileNotFoundException:
 app_1673516503164.jpg: open failed: ENOENT (No such file or directory)
 */
            //val response: Call<ImageUploadOutputModel>? = service?.postImage(body, fileName)
            //val response: Call<ImageUploadOutputModel>? = service?.uploadImage2(body)


            /*val parcelFileDescriptor = contentResolver.openFileDescriptor(
                uploadimageUri, "r", null
            ) ?: return
            val inputStream = FileInputStream(parcelFileDescriptor.fileDescriptor)
            val file = File(cacheDir,contentResolver.getFileName(uploadimageUri))
            val outputStream = FileOutputStream(file)
            inputStream.copyTo(outputStream)
            Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity inputStream = $inputStream")
            Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity file = $file")
            Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity outputStream = $outputStream")
            Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity inputStream2 = $inputStream")


            //val body2 = UploadRequestBody(f1,"image",this)
            val body2 = UploadRequestBody(file,"image",this)
            ImageUploadServiceInterface().uploadImage3(MultipartBody.Part.createFormData(
                "image",
                fileName,
                body2
            ),
                RequestBody.create("multipart/form-data".toMediaTypeOrNull(),"json")
            ).enqueue(object : Callback<UploadResponse?> {

                override fun onResponse(
                    call: Call<UploadResponse?>,
                    response: Response<UploadResponse?>
                ) {
                    Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity call = $call")
                    Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity response = $response")
                    val responseCode = response.code()
                    if (responseCode == 200) {
                        Toast.makeText(applicationContext, "Uploaded !", Toast.LENGTH_SHORT).show()

                    }
                }
                override fun onFailure(call: Call<UploadResponse?>, t: Throwable) {
                    Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity onFailure = $t")
                    Toast.makeText(applicationContext, "Failed due ${t.message}", Toast.LENGTH_SHORT)
                        .show()
                    t.printStackTrace()
                }

            });*/

        } else {
            Toast.makeText(this@NewRetrofitActivity, "Cannot retrieve cropped image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun advancedConfig(uCrop: UCrop): UCrop {
        val options = UCrop.Options()
        options.setHideBottomControls(true) //for hide bottom buttons
        options.setShowCropGrid(intent.getBooleanExtra(UCrop.Options.EXTRA_SHOW_CROP_GRID, false)) //for hide grid 9x9
        return uCrop.withOptions(options)
    }

    private fun handleCropError(result: Intent) {
        val cropError = UCrop.getError(result)
        if (cropError != null) {
            Toast.makeText(this@NewRetrofitActivity, cropError.message, Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this@NewRetrofitActivity, "Unexpected error", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_ALL) {
            //if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                //Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show()
                Log.i("My NewRetrofitActivity inside ", "first time no permission, and after give permission open camera or gallery")
                try {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                        .setType("image/*")
                        .addCategory(Intent.CATEGORY_OPENABLE)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        val mimeTypes = arrayOf("image/jpeg", "image/png")
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
                    }
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), requestMode)

                } catch (ex: Exception) {
                    Log.i("My NewRetrofitActivity Error RetrofitUploadImageActivity onRequestPermissionsResult ", "in take or select image")
                }
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun hasPermissions(context: Context, vararg permissions: String): Boolean = permissions.all {
        ActivityCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onProgressUpdate(percentage: Int) {
        //binding.progressBarNewRetrofitActivity.progress = percentage
        Log.i("My NewRetrofitActivity ", "RetrofitUploadImageActivity percentage = $percentage")

    }



    public fun uploadImage111() {
        Log.i("My NewRetrofitActivity RetrofitUploadImageActivity ", "selectedImageUri = "+selectedImageUri)
        //file:///data/user/0/com.example.androiddemo/cache/SampleCropImage.jpg
        Log.i("My NewRetrofitActivity RetrofitUploadImageActivity ", "uploadimageUri = "+uploadimageUri)
        Log.i("My NewRetrofitActivity RetrofitUploadImageActivity ", "uploadimage = "+uploadimage) //app_1673518654170.jpg


        var b: Bitmap? = null
        val ssl : ImageView = findViewById(R.id.couponImage);
        b = ScreenshotUtils.getScreenShot(ssl) //upload image of after taking imageview screenshot(not saved image)

        val now = Date()
        DateFormat.format("yyyy-MM-dd_hh:mm:ss", now)
        val saveFile = ScreenshotUtils.getMainDirectoryName(applicationContext)
        val f12 = ScreenshotUtils.store(b, "screenshot_" + now + ".jpg", saveFile)

        val photoURI = f12?.let {
            FileProvider.getUriForFile(
                applicationContext, applicationContext.packageName.toString() + ".provider",
                it
            )
        }
        //f12=/storage/emulated/0/Android/data/com.example.androiddemo/files/Pictures/Demo/screenshot_Thu Jan 12 16:37:08 GMT+05:30 2023.jpg
        //f12 getAbsolutePath = /storage/emulated/0/Android/data/com.example.androiddemo/files/Pictures/Demo/screenshot_Thu Jan 12 16:37:08 GMT+05:30 2023.jpg
        Log.i("My NewRetrofitActivity RetrofitUploadImageActivity ", "f12 = "+f12)
        Log.i("My NewRetrofitActivity RetrofitUploadImageActivity ", "f12 getAbsolutePath = "+f12?.getAbsolutePath())
        //content://com.example.androiddemo.provider/external_files/Android/data/com.example
        Log.i("My NewRetrofitActivity RetrofitUploadImageActivity ", "f12 photoURI = "+photoURI)




        if(uploadimageUri == null) {
            binding.mainContainer.snackbar("Select an Image First")
            return
        }


        val body = UploadRequestBody(f12!!,"image",this)
        Log.i("My NewRetrofitActivity RetrofitUploadImageActivity ", "body = "+body) //com.example.androiddemo.RetrofitUploadImage.UploadRequestBody@98c2f61

        binding.progressBarNewRetrofitActivity.setVisibility(View.VISIBLE)
        //binding.progressBarNewRetrofitActivity.progress = 0
        ImageUploadServiceInterface().uploadImage3(
            MultipartBody.Part.createFormData(
            "uploaded_file",
            //f12.name, //file name,
            "266.jpg", //file name,
            body //file path, "image"
        ), RequestBody.create("multipart/form-data".toMediaTypeOrNull(),"json")
        )
            .enqueue(object : Callback<UploadResponse>{
                override fun onResponse(call: Call<UploadResponse>, response: Response<UploadResponse>)
                {
                    //Response{protocol=http/1.1, code=200, message=OK, url=https://app.wemad.com.au/sub/localshopadmin/get_couponimageupload}
                    Log.i("My NewRetrofitActivity  ", "RetrofitUploadImageActivity onResponse response = "+response)
                    //UploadResponse(error=false, message=Success, image=null)
                    Log.i("My NewRetrofitActivity ", " RetrofitUploadImageActivity onResponse response body = "+response.body())

                    response.body()?.let {
                        binding.mainContainer.snackbar(it.message)
                        //binding.progressBarNewRetrofitActivity.progress = 100
                        binding.progressBarNewRetrofitActivity.setVisibility(View.GONE)
                    }
                }
                override fun onFailure(call: Call<UploadResponse>, t: Throwable)
                {
                    binding.mainContainer.snackbar(t.message!!)
                    //binding.progressBarNewRetrofitActivity.progress = 0
                    binding.progressBarNewRetrofitActivity.setVisibility(View.GONE)

                    Log.i("My NewRetrofitActivity ", "Error in RetrofitUploadImageActivity onFailure t = "+t)
                    /*
                    Error RetrofitUploadImageActivity onFailure:
                    t = java.io.FileNotFoundException: /storage/emulated/0/Download/app_1673518935937.jpg:
                     open failed: ENOENT (No such file or directory)
                     */

                }

            })


    }

    private fun View.snackbar(message: String) {
        Snackbar.make(this, message, Snackbar.LENGTH_LONG).also { snackbar ->
            snackbar.setAction("OK") {
                snackbar.dismiss()
            }
        }.show()

    }



    fun generateDataList(photoList: List<RetroPhoto?>?) {
        rv1 = findViewById<View>(R.id.retrofit_rv) as RecyclerView
        adapter = CustomAdapter(this, photoList)
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
        rv1?.layoutManager = layoutManager
        rv1?.adapter = adapter
        binding.progressBarNewRetrofitActivity.visibility = View.INVISIBLE
    }

}