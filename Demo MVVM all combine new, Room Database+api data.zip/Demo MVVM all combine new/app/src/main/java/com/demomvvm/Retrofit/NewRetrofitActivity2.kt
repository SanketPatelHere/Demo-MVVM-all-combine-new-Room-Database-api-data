package com.demomvvm.Retrofit

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.demomvvm.LoadMoreRecycleView.LoadMoreRecycleViewActivity
import com.demomvvm.MVVM.GiftCard.GiftCardMovieAdapter
import com.demomvvm.MVVM.GiftCard.GiftCardMovies
import com.demomvvm.MVVM.GiftCard.GiftCardResult
import com.demomvvm.MVVM.RetrofitInstance
import com.demomvvm.MVVM.RoomDatabase.Book
import com.demomvvm.MVVM.RoomDatabase.BookDatabase
import com.demomvvm.R
import com.demomvvm.Retrofit.RetrofitDemo.APIClient
import com.demomvvm.Retrofit.RetrofitDemo.APIInterface
import com.demomvvm.Retrofit.RetrofitDemo.CustomAdapter
import com.demomvvm.Retrofit.RetrofitDemo.RetroPhoto
import com.demomvvm.Retrofit.uploadImage.*
import com.demomvvm.Singleton
import com.demomvvm.databinding.ActivityNewRetofit2Binding
import com.demomvvm.databinding.ActivityNewRetofitBinding
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.yalantis.ucrop.UCrop
import com.yalantis.ucrop.UCropFragment
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.util.*
import kotlin.collections.HashMap

//without mvvm
//retrofit example = https://www.digitalocean.com/community/tutorials/retrofit-android-example-tutorial
//for image upload
@SuppressLint("LongLogTag")
class NewRetrofitActivity2 : AppCompatActivity() {
    val TAG = "Myy NewRetrofitActivity2 "
    //val egift_card_list: ArrayList<GiftCardResult> = ArrayList()
    private var movieLiveData2 = MutableLiveData<List<GiftCardResult>>()
    private lateinit var GiftCardMovieAdapter : GiftCardMovieAdapter
    var isLoading = false //false then loadmore(res 102 then true - not call again)
    var pageList:Int = 0

    private lateinit var binding: ActivityNewRetofit2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewRetofit2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))
        window.navigationBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))

        binding.post.setOnClickListener {

            getEgiftCardLiveURL("No")

        }


    }



    fun deleteAndInsertData(array: List<GiftCardResult>, con: Context) {

        /*val bookDao = db.bookDao()

        for(i in array.indices){
            bookDao.insertBook(Book(0,*//* array[i].ecard_id, *//*array[i].ecard_name, array[i].ecard_image))
        }
        val books = bookDao.getAllBooks()
        for(book in books){
            Log.i("My MovieViewModel","id: ${book.id} ecard_name: ${book.name} ecard_image: ${book.author}")
        }*/
    }



    fun getEgiftCardLiveURL(againCalls:String)
    {
        binding.progressBarNewRetrofitActivity.visibility = View.VISIBLE
        //No - simple first time, Yes - loadmore
        Log.i(TAG, "getEgiftCardLiveURL againCalls  = " + againCalls + " for pageList = " + pageList+" and isLoading = "+isLoading)

        if(againCalls.equals("No"))
        {
            pageList = 0  //when select or search category then always start from pageList=0
            //egift_card_list.clear()
            //movieLiveData2.clear()
        }

        /*val userInfo = UserInfo("citadelind4@gmail.com","1234")

        val userInfo = JSONObject()
        userInfo.put("email", "citadelind4@gmail.com")
        userInfo.put("password", "1234")*/
        val hashMap : HashMap<String, String> = HashMap()
        hashMap["site_id"] = "117"
        hashMap["user_id"] = "7178"
        hashMap["page_number"] = pageList.toString()
        hashMap["category_id"] = ""
        //val retrofit = ServiceBuilder.buildService(RestApi::class.java)
        //retrofit.getEgiftCardLiveURL(hashMap).enqueue(object : Callback<GiftCardMovies> {
        RetrofitInstance.api.getEgiftCardLiveURL(hashMap).enqueue(object : Callback<GiftCardMovies>{
            override fun onResponse(call: Call<GiftCardMovies>, response: Response<GiftCardMovies>) {
                binding.progressBarNewRetrofitActivity.visibility = View.INVISIBLE
                try{
                    Log.i(TAG, "getEgiftCardLiveURL onResponse response.body() = "+response.body().toString())
                    if(response.body()!=null){
                        Log.i(TAG, "getEgiftCardLiveURL onResponse response.body()!!.data = "+response.body()!!.data.toString())

                        if(response.body()!!.status == 200){
                            //for direct save whole object in pojo
                            //no need to write 1-1 field in while loop
                            //use .value to save in MutableLiveData
                            movieLiveData2.value = response.body()!!.data //in retrofit saved all list once at a time(in GiftCardMovies=>GiftCardResult)
                            Log.i(TAG, "getEgiftCardLiveURL movieLiveData2.value size = "+movieLiveData2.value!!.size.toString())
                            Log.i(TAG, "getEgiftCardLiveURL movieLiveData2.value = "+movieLiveData2.value.toString()) //10

                            if(againCalls.equals("Yes"))
                            {
                                isLoading = false //for second time load more
                            }
                            if(movieLiveData2.value!!.size==0)
                            {
                                Log.i(TAG, "getEgiftCardLiveURL API Full myecards array is not null egiftcardArr size 0 stop api call")
                                isLoading = true //for stop loadmore when data = []
                                return; //working //main - need to use retuen and android:descendantFocusability="blocksDescendants" for stop continuous api calling
                            }

                            if(movieLiveData2.value!=null && movieLiveData2.value!!.size>0) //[] or [com.wemakeadifference.Charity.CharityPojo@f4fca2f, com.wemakeadifference.Charity.CharityPojo@3ed983c]
                            {

                                //data array exist
                                Log.i(TAG, "getEgiftCardLiveURL data array exist")
                                var ecardName = movieLiveData2.value?.get(0)?.ecard_name
                                Log.i(TAG, "getEgiftCardLiveURL ecardName = "+ecardName.toString()) //Woolworths Supermarket Card
                                //code of rv to display list
                                GiftCardMovieAdapter = GiftCardMovieAdapter()
                                GiftCardMovieAdapter.setMovieList(movieLiveData2.value!!,true)
                                //GiftCardMovieAdapter.setMovieList(movieLiveData2.value!!,true) //true = when all data loaded
                                binding.retrofitRv.apply {
                                    //layoutManager = LinearLayoutManager(applicationContext,LinearLayoutManager.VERTICAL,false)
                                    layoutManager = GridLayoutManager(applicationContext,2)
                                    adapter = GiftCardMovieAdapter
                                }



                                try {
                                    Log.i(TAG, "in binding.nestedscroll.getViewTreeObserver try")
                                    //when recyclerview inside binding.nestedscrollview then prevent autoscrolling of binding.nestedscrollview =
                                    binding.nestedscroll.getViewTreeObserver().addOnScrollChangedListener {
                                        Log.i(TAG, "in binding.nestedscroll.getViewTreeObserver addOnScrollChangedListener try")
                                        val view = binding.nestedscroll.getChildAt(binding.nestedscroll.getChildCount() - 1) as View
                                        val diff: Int = view.bottom - (binding.nestedscroll.getHeight() + binding.nestedscroll.getScrollY())
                                        if(diff == 0) {
                                            //code to fetch more data for endless scrolling
                                            //load when recyclerview scroll until not run
                                            //atoz = false
                                            Log.i(TAG, "select isLoading = " + isLoading)
                                            //if (!isLoading && atoz == false) {
                                            if(!isLoading) //false then loadmore
                                            {
                                                //bottom of list!
                                                pageList++
                                                //loadMore()
                                                getEgiftCardLiveURL("Yes")
                                                isLoading = true //for stop loadmore
                                            }
                                        }
                                    }
                                }
                                catch (ex:Exception)
                                {
                                    isLoading = false
                                    //stopAnim()
                                    Log.i(TAG, "catch Error in binding.nestedscroll.getViewTreeObserver ex = " + ex)
                                }

                            }
                            else
                            {
                                //data array not exist
                                Log.i(TAG, "getEgiftCardLiveURL data array not exist")
                            }

                        }
                        else{
                            Toast.makeText(applicationContext, "Something Went Wrong!", Toast.LENGTH_LONG).show()
                        }

                    }
                    else{
                        Log.i(TAG, "getEgiftCardLiveURL onResponse response.body()!!.data = null")
                        return
                    }
                }
                catch(ex:Exception){
                    Log.i(TAG, "getEgiftCardLiveURL response Error in catch ex = "+ex.toString()) //{"message":"wrong username or password!","status":"102"}
                }


            }
            override fun onFailure(call: Call<GiftCardMovies>, t: Throwable) {
                isLoading = false
                //stopAnim()
                binding.progressBarNewRetrofitActivity.visibility = View.INVISIBLE
                Log.i(TAG, "onFailure call = "+call.toString())
                Log.i(TAG, "onFailure t = "+t.toString())
                binding.details.text ="Something Went Wrong!"
            }
        }
        )

    }


}