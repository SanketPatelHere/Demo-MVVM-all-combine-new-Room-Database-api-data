package com.demomvvm;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;

public class Singleton1 {

    private String product_cell_validation;
    private String online_coupon_cell_validation;
    private String online_special_cell_validation;
    private String cart_cell_flg;
    private String archive_cell_flg;

    //todo bPoint var start
    private String in_merchant_number;
    private String in_merchant_username;
    private String in_merchant_password;
    private String in_amount;
    private String in_billercode;
    private String in_merchant_reference;
    private String in_ip_address;
    private String in_crn1;
    private String in_crn2;
    private String in_crn3;
    private String in_receipt_page_url;


    /*  let jsonObject: [String: Any] = [
            "site_id": Singleton1.shared.site_id,
            "fields": ["in_merchant_number": Singleton1.shared.bpoint_merchant_number,
            "in_merchant_username":Singleton1.shared.bpoint_merchant_user_name,
            "in_merchant_password":Singleton1.shared.bpoint_merchant_password,
            "in_amount":String(myInt3),
"in_billercode":Singleton1.shared.bpoint_biller_code,
            "in_merchant_reference":Singleton1.shared.site_id,
            "in_ip_address":"",
            "in_crn1": Singleton1.shared.site_id,
            "in_crn2":userid,
            "in_crn3":userid,
            "in_receipt_page_url":"https://www.rewards.wemakeadifference.com.au/thanks"]
            ]*/
    //todo bPoint var end


    //todo for wemake login with all site - merge all site in wemake start
    Context context;
    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }
    private String MY_DEVICETOKEN = "";
    private String MY_DEVICEIP = "";
    private String MY_DEVICEUUID = "";
    private String MY_FIREBASEDEVICEUUID = "";
    private String placeorderApi = "ON";
    private String keepappstopforallusers = "false";


    //todo for check api field is null or not start
    public String hasCheckSingleton(String arriveField)
    {
        Log.i("Myy ","inside hasCheckSingleton before arriveField = "+arriveField);
        //if(arriveField.equals(null) || arriveField.equals("null") || arriveField.equals(""))
        if(arriveField==null || arriveField.equals("null"))
        {
            arriveField = ""; //if default 0 => "0"
        }
        Log.i("Myy ","inside hasCheckSingleton after arriveField = "+arriveField);
        return arriveField;

    }
    //todo for check api field is null or not end



    public String getMY_DEVICETOKEN() {
        if(MY_DEVICETOKEN.equals(""))
        {
            //come into this when first time splashscreen internet is off
            /*FirebaseMessaging.getInstance().getToken().addOnSuccessListener(new OnSuccessListener<String>() {
                        @Override
                        public void onSuccess(String token) {
                            if(!TextUtils.isEmpty(token)) {
                                Singleton1.getInstance().setMY_DEVICETOKEN(token.toString()); //for Log1.i
                                Log.i("Myy ", "Singleton1 Firebase Device devicetoken retrieve token successful : "+token); //dUZKqbLiQpSwCvDC_fIAbq:APA91bG33XThYAe9sXQyD8njs6DONIQyoiOghBcUQgQ8nsnhf4vAium1_VXI7nnTlrt3odEQiSqV1gbl1TA-mhh676iBKlLQ-ds1CxYs87i8ipezV4LD5Tar70A5PcDpxyWvl3eoWIP5
                            } else {
                                Log.i("Myy ", "Singleton1 Firebase Device devicetoken should not be null...");
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                        }
                    })
                    .addOnCompleteListener(new OnCompleteListener<String>() {
                        @Override
                        public void onComplete(@NonNull Task<String> task) {
                            Log.i("Myy ", "Singleton1 Firebase Device This is the task = " + task.toString()); //dUZKqbLiQpSwCvDC_fIAbq:APA91bG33XThYAe9sXQyD8njs6DONIQyoiOghBcUQgQ8nsnhf4vAium1_VXI7nnTlrt3odEQiSqV1gbl1TA-mhh676iBKlLQ-ds1CxYs87i8ipezV4LD5Tar70A5PcDpxyWvl3eoWIP5
                            ///Log.i("Myy ", "Singleton1 Firebase Device This is the task.result = " + task.getResult()); //dUZKqbLiQpSwCvDC_fIAbq:APA91bG33XThYAe9sXQyD8njs6DONIQyoiOghBcUQgQ8nsnhf4vAium1_VXI7nnTlrt3odEQiSqV1gbl1TA-mhh676iBKlLQ-ds1CxYs87i8ipezV4LD5Tar70A5PcDpxyWvl3eoWIP5
                        }
                    });
*/
        }
        return MY_DEVICETOKEN;
    }


    public void setMY_DEVICETOKEN(String MY_DEVICETOKEN) {
        this.MY_DEVICETOKEN = MY_DEVICETOKEN;
    }

    public String getMY_DEVICEIP() {
        return MY_DEVICEIP;
    }

    public void setMY_DEVICEIP(String MY_DEVICEIP) {
        this.MY_DEVICEIP = MY_DEVICEIP;
    }

    public String getMY_DEVICEUUID() {
        return MY_DEVICEUUID;
    }

    public void setMY_DEVICEUUID(String MY_DEVICEUUID) {
        this.MY_DEVICEUUID = MY_DEVICEUUID;
    }

    public String getMY_FIREBASEDEVICEUUID() {
        return MY_FIREBASEDEVICEUUID;
    }

    public void setMY_FIREBASEDEVICEUUID(String MY_FIREBASEDEVICEUUID) {
        this.MY_FIREBASEDEVICEUUID = MY_FIREBASEDEVICEUUID;
    }


    public String getPlaceorderApi() {
        return placeorderApi;
    }

    public void setPlaceorderApi(String placeorderApi) {
        this.placeorderApi = placeorderApi;
    }


    public String getKeepappstopforallusers() {
        return keepappstopforallusers;
    }

    public void setKeepappstopforallusers(String keepappstopforallusers) {
        this.keepappstopforallusers = keepappstopforallusers;
    }

    //private String MY_SITEID "54";
    private String MY_SITEID;
    private String MY_SITEName;
    private String MYSITETITLE;
    private String MY_SITEColorPrimary = "#48cfe0"; //default wemake colorPrimary
    private String MY_SITEColorPrimaryDark = "#042638"; //default wemake button_color
    private String MY_SITETEXTCOLOR = "#ffffff"; //default wemake button_color


    //todo for dynamic apibaseurl start
    //for all api calling
    ///private String APIBASEURL = "https://app.wemad.com.au"; //<!--live1-->
    private String APIBASEURL = "https://appv2.wemad.com.au"; //<!--live2-->
    ///private String APIBASEURL = "https://appv3.wemad.com.au</string> //<!--live3-->
    ///private String APIBASEURL = "https://app.wemad.com.au/sub"; //<!--sub-->
    ///private String APIBASEURL = "https://app.wemad.com.au/sublive"; //<!--sub live for testing given demo with live database-->


    //for app maintenance popup display
    ///private String APIBASEURLHomePage = "https://app.wemad.com.au"; //<!--live1-->
    private String APIBASEURLHomePage = "https://appv2.wemad.com.au"; //<!--live2-->
    ///private String APIBASEURLHomePage = "https://appv3.wemad.com.au</string> //<!--live3-->
    ///private String APIBASEURLHomePage = "https://app.wemad.com.au/sub"; //<!--sub-->
    ///private String APIBASEURLHomePage = "https://app.wemad.com.au/sublive"; //<!--sub live for testing given demo with live database-->


    public String getAPIBASEURL() {
        return APIBASEURL;
    }
    public void setAPIBASEURL(String APIBASEURL) {
        this.APIBASEURL = APIBASEURL;
    }

    public String getAPIBASEURLHomePage() {
        return APIBASEURLHomePage;
    }

    public void setAPIBASEURLHomePage(String APIBASEURLHomePage) {
        this.APIBASEURLHomePage = APIBASEURLHomePage;
    }

    //todo for dynamic apibaseurl end



    public String getMY_SITEID() {
        return MY_SITEID;
    }

    public void setMY_SITEID(String MY_SITEID) {
        this.MY_SITEID = MY_SITEID;
    }

    public String getMY_SITEName() {
        return MY_SITEName;
    }

    public void setMY_SITEName(String MY_SITEName) {
        this.MY_SITEName = MY_SITEName;
    }

    //for SITE_TITLE
    public String getMYSITETITLE() {
        if(MYSITETITLE.equals("") || MYSITETITLE.equals("null") || MYSITETITLE.equals(null))
        {
            //Log.i("Myy Singleton1 ","Singleton1 getMYSITETITLE inside if");
            MYSITETITLE = context.getString(R.string.app_name);
            //Log.i("Myy Singleton1 ","Singleton1 getMYSITETITLE inside if MYSITETITLE = "+MYSITETITLE);
        }
        //Log.i("Myy Singleton1 ","Singleton1 getMYSITETITLE inside MYSITETITLE = "+MYSITETITLE);
        return MYSITETITLE;
    }

    public void setMYSITETITLE(String MYSITETITLE) {
        this.MYSITETITLE = MYSITETITLE;
    }

    /*
       Singleton1 = app default color then api color
       Sp = api color save, when app open get from it and save in Singleton1

       Singleton1 = app default color
       SplashActivity = api color
       NewBaseActivity = first get sp color then Singleton1 color
        */
    public String getMY_SITEColorPrimary() {
        //right = 7 = #ff0000,
        //wrong = ff0000, #ff000,    ##ff0000, ##ff000
        if(MY_SITEColorPrimary.equals("") || MY_SITEColorPrimary.equals("null") || MY_SITEColorPrimary.equals(null)
                || MY_SITEColorPrimary.length()!=7 || !MY_SITEColorPrimary.startsWith("#"))
        {
            MY_SITEColorPrimary = "#48cfe0"; //cyan
        }
        return MY_SITEColorPrimary;
    }

    public void setMY_SITEColorPrimary(String MY_SITEColorPrimary) {
        this.MY_SITEColorPrimary = MY_SITEColorPrimary;
    }

    public String getMY_SITEColorPrimaryDark() {
        //right = 7 = #ff0000,
        //wrong = ff0000, #ff000,    ##ff0000, ##ff000
        if(MY_SITEColorPrimaryDark.equals("") || MY_SITEColorPrimaryDark.equals("null") || MY_SITEColorPrimaryDark.equals(null)
                || MY_SITEColorPrimaryDark.length()!=7 || !MY_SITEColorPrimaryDark.startsWith("#"))
        {
            MY_SITEColorPrimaryDark = "#042638"; //dark blue
        }
        return MY_SITEColorPrimaryDark;
    }

    public void setMY_SITEColorPrimaryDark(String MY_SITEColorPrimaryDark) {
        this.MY_SITEColorPrimaryDark = MY_SITEColorPrimaryDark;
    }

    public String getMY_SITETEXTCOLOR() {
        return MY_SITETEXTCOLOR;
    }

    public void setMY_SITETEXTCOLOR(String MY_SITETEXTCOLOR) {
        this.MY_SITETEXTCOLOR = MY_SITETEXTCOLOR;
    }

    //todo for wemake login with all site - merge all site in wemake end




    //todo for change section name dynamically start
    String GiftCard111 = "Gift Card";
    String GiftCards111 = "Gift Cards";
    String Cashback111 = "Cashback";
    String ShopLocal111 = "Shop Local";
    String Sales111 = "Sales";
    String Wallet111 = "Wallet";
    String Gift111 = "Gift";
    String Gifting111 = "Gifting";
    String Travel111 = "Travel";
    String Vault111 = "Vault";
    String Compare111 = "Compare";
    String Voucher111 = "Voucher";
    String Vouchers111 = "Vouchers";
    String Partners111 = "Partners";

    public String getGiftCard111() {
        return GiftCard111;
    }

    public void setGiftCard111(String giftCard111) {
        GiftCard111 = giftCard111;
    }

    public String getGiftCards111() {
        return GiftCards111;
    }

    public void setGiftCards111(String giftCards111) {
        GiftCards111 = giftCards111;
    }

    public String getCashback111() {
        return Cashback111;
    }

    public void setCashback111(String cashback111) {
        Cashback111 = cashback111;
    }

    public String getShopLocal111() {
        return ShopLocal111;
    }

    public void setShopLocal111(String shopLocal111) {
        ShopLocal111 = shopLocal111;
    }

    public String getSales111() {
        return Sales111;
    }

    public void setSales111(String sales111) {
        Sales111 = sales111;
    }

    public String getWallet111() {
        return Wallet111;
    }

    public void setWallet111(String wallet111) {
        Wallet111 = wallet111;
    }

    public String getGift111() {
        return Gift111;
    }

    public void setGift111(String gift111) {
        Gift111 = gift111;
    }

    public String getGifting111() {
        return Gifting111;
    }

    public void setGifting111(String gifting111) {
        Gifting111 = gifting111;
    }

    public String getTravel111() {
        return Travel111;
    }

    public void setTravel111(String travel111) {
        Travel111 = travel111;
    }

    public String getVault111() {
        return Vault111;
    }

    public void setVault111(String vault111) {
        Vault111 = vault111;
    }

    public String getCompare111() {
        return Compare111;
    }

    public void setCompare111(String compare111) {
        Compare111 = compare111;
    }

    public String getVoucher111() {
        return Voucher111;
    }

    public void setVoucher111(String voucher111) {
        Voucher111 = voucher111;
    }

    public String getVouchers111() {
        return Vouchers111;
    }

    public void setVouchers111(String vouchers111) {
        Vouchers111 = vouchers111;
    }

    public String getPartners111() {
        return Partners111;
    }

    public void setPartners111(String partners111) {
        Partners111 = partners111;
    }

    //todo for change section name dynamically end



    /////////////////////////////////////////////
    //for all screen category
    private ArrayList<String> category_list;
    private ArrayList<String> category_list_id;

    public void setCategory_list_id(ArrayList<String> category_list_id) {
        this.category_list_id = category_list_id;
    }

    public ArrayList<String> getCategory_list_id() {
        return category_list_id;
    }

    public void setCategory_list(ArrayList<String> category_list) {
        this.category_list = category_list;
    }

    public ArrayList<String> getCategory_list() {
        return category_list;
    }
    /////////////////////////////////////////////

    /////////////////////////////////////////////
    //for egift card screen category
    private ArrayList<String> category_list_egiftcard;
    private ArrayList<String> category_list_egiftcard_id;


    public ArrayList<String> getCategory_list_egiftcard() {
        return category_list_egiftcard;
    }

    public void setCategory_list_egiftcard(ArrayList<String> category_list_egiftcard) {
        this.category_list_egiftcard = category_list_egiftcard;
    }

    public ArrayList<String> getCategory_list_egiftcard_id() {
        return category_list_egiftcard_id;
    }

    public void setCategory_list_egiftcard_id(ArrayList<String> category_list_egiftcard_id) {
        this.category_list_egiftcard_id = category_list_egiftcard_id;
    }
    /////////////////////////////////////////////



    /////////////////////////////////////////////
    //for charity category
    private ArrayList<String> charity_list1;
    private ArrayList<String> charity_list_id1;

    public ArrayList<String> getCharity_list1() {
        return charity_list1;
    }

    public void setCharity_list1(ArrayList<String> charity_list1) {
        this.charity_list1 = charity_list1;
    }

    public ArrayList<String> getCharity_list_id1() {
        return charity_list_id1;
    }

    public void setCharity_list_id1(ArrayList<String> charity_list_id1) {
        this.charity_list_id1 = charity_list_id1;
    }
    /////////////////////////////////////////////


    /////////////////////////////////////////////
    //for sendagift occasion
    private ArrayList<String> occasion_list1;
    private ArrayList<String> occasion_list_id1;
    private ArrayList<String> occasion_list_image1;

    public ArrayList<String> getOccasion_list1() {
        return occasion_list1;
    }

    public void setOccasion_list1(ArrayList<String> occasion_list1) {
        this.occasion_list1 = occasion_list1;
    }

    public ArrayList<String> getOccasion_list_id1() {
        return occasion_list_id1;
    }

    public void setOccasion_list_id1(ArrayList<String> occasion_list_id1) {
        this.occasion_list_id1 = occasion_list_id1;
    }

    public ArrayList<String> getOccasion_list_image1() {
        return occasion_list_image1;
    }

    public void setOccasion_list_image1(ArrayList<String> occasion_list_image1) {
        this.occasion_list_image1 = occasion_list_image1;
    }
    /////////////////////////////////////////////

    //for GiftCardWalletData occasion
    private ArrayList<String> giftcardwallet_list1;
    private ArrayList<String> giftcardwallet_listOnlyName;
    private ArrayList<String> giftcardwallet_id1;

    public ArrayList<String> getGiftcardwallet_list1() {
        return giftcardwallet_list1;
    }

    public void setGiftcardwallet_list1(ArrayList<String> giftcardwallet_list1) {
        this.giftcardwallet_list1 = giftcardwallet_list1;
    }

    public ArrayList<String> getGiftcardwallet_id1() {
        return giftcardwallet_id1;
    }

    public void setGiftcardwallet_id1(ArrayList<String> giftcardwallet_id1) {
        this.giftcardwallet_id1 = giftcardwallet_id1;
    }

    public ArrayList<String> getGiftcardwallet_listOnlyName() {
        return giftcardwallet_listOnlyName;
    }

    public void setGiftcardwallet_listOnlyName(ArrayList<String> giftcardwallet_listOnlyName) {
        this.giftcardwallet_listOnlyName = giftcardwallet_listOnlyName;
    }

    /////////////////////////////////////////////



    /////////////////////////////////////////////
    //for localshop state
    private ArrayList<String> state_list_id;
    private ArrayList<String> state_list_name;

    public ArrayList<String> getState_list_id() {
        return state_list_id;
    }

    public void setState_list_id(ArrayList<String> state_list_id) {
        this.state_list_id = state_list_id;
    }

    public ArrayList<String> getState_list_name() {
        return state_list_name;
    }

    public void setState_list_name(ArrayList<String> state_list_name) {
        this.state_list_name = state_list_name;
    }

    //for localshop city
    private ArrayList<String> city_list_id;
    private ArrayList<String> city_list_name;
    public ArrayList<String> getCity_list_id() {
        return city_list_id;
    }
    public void setCity_list_id(ArrayList<String> city_list_id) {
        this.city_list_id = city_list_id;
    }
    public ArrayList<String> getCity_list_name() {
        return city_list_name;
    }
    public void setCity_list_name(ArrayList<String> city_list_name) {
        this.city_list_name = city_list_name;
    }

    //for localshop category
    private ArrayList<String> localshop_category_id;
    private ArrayList<String> localshop_category_name;
    public ArrayList<String> getLocalshop_category_id() {
        return localshop_category_id;
    }

    public void setLocalshop_category_id(ArrayList<String> localshop_category_id) {
        this.localshop_category_id = localshop_category_id;
    }

    public ArrayList<String> getLocalshop_category_name() {
        return localshop_category_name;
    }

    public void setLocalshop_category_name(ArrayList<String> localshop_category_name) {
        this.localshop_category_name = localshop_category_name;
    }
    /////////////////////////////////////////////





    //todo for login all in one and forgot password start
    //for new site selection dropdown
    private ArrayList<String> category_sitelist;
    private ArrayList<String> category_sitelist_id;
    private ArrayList<String> category_sitelist_usr_id;
    private ArrayList<String> category_sitelist_usr_phone;
    private ArrayList<String> category_sitelist_usr_email;

    public ArrayList<String> getCategory_sitelist() {
        return category_sitelist;
    }

    public void setCategory_sitelist(ArrayList<String> category_sitelist) {
        this.category_sitelist = category_sitelist;
    }

    public ArrayList<String> getCategory_sitelist_id() {
        return category_sitelist_id;
    }

    public void setCategory_sitelist_id(ArrayList<String> category_sitelist_id) {
        this.category_sitelist_id = category_sitelist_id;
    }

    public ArrayList<String> getCategory_sitelist_usr_id() {
        return category_sitelist_usr_id;
    }

    public void setCategory_sitelist_usr_id(ArrayList<String> category_sitelist_usr_id) {
        this.category_sitelist_usr_id = category_sitelist_usr_id;
    }

    public ArrayList<String> getCategory_sitelist_usr_phone() {
        return category_sitelist_usr_phone;
    }

    public void setCategory_sitelist_usr_phone(ArrayList<String> category_sitelist_usr_phone) {
        this.category_sitelist_usr_phone = category_sitelist_usr_phone;
    }

    public ArrayList<String> getCategory_sitelist_usr_email() {
        return category_sitelist_usr_email;
    }

    public void setCategory_sitelist_usr_email(ArrayList<String> category_sitelist_usr_email) {
        this.category_sitelist_usr_email = category_sitelist_usr_email;
    }
    //todo for login all in one and forgot password end


    public void setCart_cell_flg(String cart_cell_flg) {
        this.cart_cell_flg = cart_cell_flg;
    }

    public String getCart_cell_flg() {
        return cart_cell_flg;
    }



    public void setArchive_cell_flg(String archive_cell_flg) {
        this.archive_cell_flg = archive_cell_flg;
    }

    public String getArchive_cell_flg() {
        return archive_cell_flg;
    }








    public void setOnline_special_cell_validation(String online_special_cell_validation) {
        this.online_special_cell_validation = online_special_cell_validation;
    }

    public String getOnline_special_cell_validation() {
        return online_special_cell_validation;
    }

    public void setOnline_coupon_cell_validation(String online_coupon_cell_validation) {
        this.online_coupon_cell_validation = online_coupon_cell_validation;
    }

    public String getOnline_coupon_cell_validation() {
        return online_coupon_cell_validation;
    }

    public void setProduct_cell_validation(String product_cell_validation) {
        this.product_cell_validation = product_cell_validation;
    }

    public String getProduct_cell_validation() {
        return product_cell_validation;
    }

    private static Singleton1 instance = null;

    private Singleton1(){
    }

    private synchronized static void createInstance() {
        if (instance == null) {
            instance = new Singleton1();
        }
    }

    public static Singleton1 getInstance() {
        if (instance == null) createInstance();
        return instance;
    }

    public static void setInstance(Singleton1 instance) {
        Singleton1.instance = instance;
    }

}
