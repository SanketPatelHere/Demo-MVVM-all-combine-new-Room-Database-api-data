package com.demomvvm.Retrofit.uploadImage

import android.util.Base64
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import okhttp3.*
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import java.nio.charset.StandardCharsets


interface  ImageUploadServiceInterface {
    @Multipart
    //@POST("/")
    @POST("sub/localshopadmin/get_couponimageupload")
    //fun postImage(@Part image: Part?, @Part("name") name: RequestBody?): Call<ResponseBody?>?
    //fun postImage(body: MultipartBody.Part, name: String): Call<ResponseBody>
    fun postImage(@Part body: MultipartBody.Part, @Body name: String): Call<ImageUploadOutputModel>
    //fun postImage(@Part body: MultipartBody.Part, @Part name: MultipartBody.Part): Call<ImageUploadOutputModel>

    @Multipart
    @POST("sub/localshopadmin/get_couponimageupload")
    fun uploadImage2( @Part image:MultipartBody.Part):Call<ImageUploadOutputModel>

    //https://app.wemad.com.au/sub/localshopadmin/get_couponimageupload/266.jpg
    //for image upload use = Multipart => @part = MultipartBody.Part, @part = RequestBody
    @Multipart
    @POST("sub/localshopadmin/get_couponimageupload")
    fun uploadImage3(
        @Part image: MultipartBody.Part,
        @Part("uploaded_file") desc: RequestBody
    ): Call<UploadResponse>

    companion object {


        //for retrofit authentication start
        public fun getHTTPClient(): OkHttpClient.Builder? {

            val credentials = "wemakeadifference" + ":" + "nHNfTwfu!)Sq7m06J73BNYHq"
            val base64EncodedCredentials = Base64.encodeToString(credentials.toByteArray(
                StandardCharsets.UTF_8), Base64.NO_WRAP)


            val builder = OkHttpClient.Builder()

            //1.Application layer = addInterceptor()
            builder.addInterceptor(Interceptor { chain ->
                val ongoing: Request.Builder = chain.request().newBuilder()
                ///ongoing.addHeader("Accept", "application/json;versions=1");
                //ongoing.addHeader("Authorization", base64EncodedCredentials);
                ongoing.addHeader("Authorization", "Basic " + base64EncodedCredentials)
                chain.proceed(ongoing.build())
            }).build()

            return builder
        }

        //for retrofit authentication end
        var gson: Gson? = GsonBuilder()
            .setLenient()
            .create()

        operator fun invoke(): ImageUploadServiceInterface{
            return Retrofit.Builder()
                .baseUrl("https://app.wemad.com.au/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(getHTTPClient()?.build())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
                .create(ImageUploadServiceInterface::class.java)
        }
    }

}

