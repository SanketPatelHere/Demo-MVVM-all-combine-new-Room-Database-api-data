package com.demomvvm.MVVM.GiftCard

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.demomvvm.databinding.MovieLayoutBinding
import com.squareup.picasso.Picasso


/*
1.load data from api
2.save in room

1.load data from room
2.load new data from api
3.save in room
 */
class GiftCardMovieAdapter : RecyclerView.Adapter<GiftCardMovieAdapter.ViewHolder>() {
    private var movieList = ArrayList<GiftCardResult>()
    private var checkClickEnable = false

    fun setMovieList(movieList: List<GiftCardResult>, checkClickEnable:Boolean) {
        this.movieList = movieList as ArrayList<GiftCardResult>
        this.checkClickEnable = checkClickEnable //for not touch any view of room data , until new data load from api
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: MovieLayoutBinding) : RecyclerView.ViewHolder(binding.root) {}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(MovieLayoutBinding.inflate(LayoutInflater.from(parent.context)))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        Picasso.get()
            .load("https://www.wemad.com.au/upload/ecards/" + movieList[position].ecard_image)
            .into(holder.binding.movieImage)
        holder.binding.movieName.text = movieList[position].ecard_name

        holder.itemView.setOnClickListener {
            if(checkClickEnable){
                Log.i("My Adapter"," click is Enable")
            }
            else{
                Log.i("My Adapter"," click is Disable")
            }
        }

    }

    override fun getItemCount(): Int {
        return movieList.size
    }
}