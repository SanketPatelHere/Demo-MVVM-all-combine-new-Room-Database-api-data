package com.demomvvm.Api_Interface;

import okhttp3.Call;
import okhttp3.RequestBody;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
//not use this
public interface ServiceWrapper {
    @Multipart
    @POST("paytmallinone/init_Transaction.php")
    <Token_Res>
    Call generateTokenCall(
            @Part("code") RequestBody language,
            @Part("MID") RequestBody mid,
            @Part("ORDER_ID") RequestBody order_id,
            @Part("AMOUNT") RequestBody amount
    );
}
