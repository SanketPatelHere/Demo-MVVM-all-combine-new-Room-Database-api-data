package com.demomvvm.MVVM.GiftCard

data class GiftCardResult(
    val ecard_id: String,
    val ecard_name: String,
    val ecard_image: String,
)
