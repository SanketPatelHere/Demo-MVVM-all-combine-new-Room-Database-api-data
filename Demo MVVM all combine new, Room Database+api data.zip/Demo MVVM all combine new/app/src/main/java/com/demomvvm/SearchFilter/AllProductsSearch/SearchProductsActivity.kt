package com.demomvvm.SearchFilter.AllProductsSearch

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.demomvvm.R
import com.demomvvm.Singleton
import com.demomvvm.databinding.ActivitySearchProductsBinding
import com.google.gson.GsonBuilder
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import com.xoxoer.lifemarklibrary.Lifemark
import es.dmoral.toasty.Toasty
import okhttp3.*
import org.json.JSONObject
import java.util.*

@SuppressLint("LongLogTag")
class SearchProductsActivity : AppCompatActivity() {

    val my_product_list: ArrayList<SearchProductsModel> = ArrayList()
    private lateinit var recyclerView: RecyclerView;
    lateinit var SearchProductsAdapter: SearchProductsAdapter
    var myselectedcolor = "default"
    var colorItemArr = arrayOf("White", "Black", "Red") //"black,grey"

    var count = 1
    var stock1:Int = 1
    var minStock1:Int = 1 //0


    private lateinit var binding: ActivitySearchProductsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchProductsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))
        window.navigationBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))


        binding.txtSearchEvaultEVault.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                /*if (binding.txtSearchEvaultEVault.text.toString()!=""){
                    getAllProducts(binding.txtSearchEvaultEVault.text.toString())
                }*/
            }
            override fun afterTextChanged(s: Editable) {
                Log.i("My MainActivity category txt_search_evaultEVault ", "afterTextChanged :- " + binding.txtSearchEvaultEVault.getText())
                val handler= Handler()
                handler.postDelayed({
                    //if (egift_card_list.size > 0 && mEvaultAdapter != null) {
                    if (SearchProductsAdapter != null) {
                        Log.i("My MainActivity category txt_search_evaultEVault ", "if")
                        ///mEvaultAdapter.getFilter().filter(txt_search_evaultEVault.getText()); //for filter using entered ecard name
                        //or
                        SearchProductsAdapter.filter.filter(binding.txtSearchEvaultEVault.getText()) //for filter using entered ecard name
                    }
                    else {
                        //issue app crash when search without data load of getEVaultData()
                        //sol.show/hide when data get
                        Log.i("My MainActivity category txt_search_evaultEVault ", "else")
                    }
                },1000)
            }
        })

        getAllProducts(" ")

    }

    fun getAllProducts(searchKeyword:String){
        val networkConnection = applicationContext?.let { Lifemark(it) }
        if(networkConnection?.isNetworkConnected()==true)
        {
            var api_url = "https://www.vaishalimobile.com/app/product/get_product_search"
            var authstr = "vaishalimobile:nHNfTwfu!)Sq7m06J7f8yzq45"
            val encodedString  = android.util.Base64.encodeToString(
                authstr.toByteArray(),
                android.util.Base64.NO_WRAP
            );
            val encoding = encodedString as String
            binding.productProgressBar.visibility = View.VISIBLE

            val okHttpClient: OkHttpClient = OkHttpClient.Builder()
                .authenticator(object : Authenticator {
                    @Throws(Exception::class)
                    override fun authenticate(route: Route?, response: Response): Request? {
                        return response.request.newBuilder()
                            .header("Authorization", "Basic $encoding")
                            .build()
                    }
                })
                .build()

            val jsonObject: JSONObject = JSONObject()
            jsonObject.put("product_name", searchKeyword)
            jsonObject.put("page_no", "")
            Log.i("My getProductCat ", "jsonObject param = $jsonObject Api URL :- $api_url");

            AndroidNetworking.post(api_url)
                .setOkHttpClient(okHttpClient)
                .addBodyParameter("product_name", searchKeyword)
                .addBodyParameter("page_no", "")
                .setTag("test")
                .build()
                .getAsJSONObject(object : JSONObjectRequestListener {
                    override fun onResponse(response: JSONObject) {
                        Log.i("My getProductCat Response = ", "" + response.toString())
                        my_product_list.clear()
                        binding.productProgressBar.visibility = View.GONE

                        if (response.getString("status") == "200") {
                            Log.i("My getProductCat Response = ", "Equal To 200")
                            val logindetailarr = response.getJSONArray("data")

/*
                            val logindetailarr = response.getJSONArray("data")
                            i(TAG, "getAllCharityData siteCharities = "+siteCharities) //
                            //Object=>Array=>ArrayList<Pojo>
                            //JsonObject=>JsonArray=>ArrayList<CharityPojo>
                            val gson = GsonBuilder().serializeNulls().create() //return null => "" //not work
                            val jsonObject: JsonObject = gson.fromJson(response.toString(), JsonObject::class.java) //whole api res
                            i(TAG, "getAllCharityData jsonObject = "+jsonObject)
                            val dataObjectResponse: JsonArray = jsonObject.getAsJsonArray("sitecharity") //only main data res in JsonArray
                            i(TAG, "getAllCharityData dataArrayResponse = "+dataObjectResponse)
                            //val responseDataVales: MutableList<CharityPojo> = gson.fromJson(dataObjectResponse, object: TypeToken<List<CharityPojo>>(){}.type) //save whole main data array in pojo array
                            val responseDataVales: ArrayList<CharityPojo> = gson.fromJson(dataObjectResponse, object: TypeToken<List<CharityPojo>>(){}.type) //save whole main data array in pojo array, TypeToken=Represents a generic type T(when pojo class type not provide, it arrive at runttime)
                            ///i(TAG, "getAllCharityData responseDataVales = "+responseDataVales) //only main data res in pojo array
                            i(TAG, "getAllCharityData responseDataVales = "+ Arrays.toString(responseDataVales.toArray())) //only main data res in pojo array

                            //if(responseDataVales.size>0)
                            if(responseDataVales!=null && responseDataVales.size>0) //[] or  [com.vsbenefits.Charity.CharityPojo@f4fca2f, com.vsbenefits.Charity.CharityPojo@3ed983c]
                            {
                                //data array exist
                                Log.i(TAG, "getAllCharityData data array exist")
                                ///my_charity_list.add(responseDataVales) //not working
                                my_charity_list = responseDataVales //working
                                ///my_charity_list.addAll(responseDataVales) //working
                            }
                            else
                            {
                                i(TAG, "getAllCharityData data array size = 0")

                            }
*/


                            var count: Int = 0;
                            var prd_id: String = "";
                            var cat_id: String = "";
                            var brand_id: String = "";
                            var productname: String = "";
                            var prd_image: String = "";
                            var newprd_image: String = "";
                            var productdescription: String = "";
                            var status: String = "";
                            var prd_price: String = "";
                            var prd_splprice: String = "";
                            var stock: String = "";
                            var min_stock: String = "";
                            var best_seller: String = "";
                            var new_product: String = "";
                            var product_color: String = "";
                            var newprd_color: String = "";

                            while (count < logindetailarr.length()) //count = 25
                            {
                                val data_dic = logindetailarr.getJSONObject(count);
                                if (data_dic.has("prd_id")) {
                                    prd_id = data_dic.getString("prd_id");
                                }
                                if (data_dic.has("best_seller")) {
                                    best_seller = data_dic.getString("best_seller");
                                }
                                if (data_dic.has("product_color")) {
                                    product_color = data_dic.getString("product_color");
                                    Log.i("My inside ", "getAllProducts beofre colorItemArr1 = " + Arrays.toString(colorItemArr)) //[White, Black, Red]
                                    if (product_color.equals("")) {
                                        newprd_color = "default" //outer adapter color
                                        product_color = "default" //inner detail activity
                                        myselectedcolor = "default" //for mylistjson
                                        colorItemArr = arrayOf("default")
                                    }
                                    else
                                    {
                                        val newprd_colorArr = product_color?.split(",".toRegex())?.toTypedArray()
                                        newprd_color = newprd_colorArr?.get(0).toString() //outer adapter color
                                        myselectedcolor = newprd_colorArr?.get(0).toString()  //for mylistjson
                                        //newprd_image = newprd_imageArr!!.get(0).toString()
                                        colorItemArr = newprd_colorArr!!;


                                        /*for(i in 0 until colorItemArr.size)
                                        {
                                            //myselectedcolor = colorItemArr[i];
                                            myselectedcolor = colorItemArr.get(i)+","+myselectedcolor;
                                            Log.i("My inside ", "getAllProducts after myselectedcolor = " + myselectedcolor)
                                        }*/
                                        Log.i("My inside ", "getAllProducts after colorItemArr2 = " + Arrays.toString(colorItemArr)); //[black, grey]
                                    }
                                }
                                if (data_dic.has("prd_image")) {
                                    prd_image = data_dic.getString("prd_image");
                                    val newprd_imageArr = prd_image?.split(",".toRegex())?.toTypedArray()
                                    newprd_image = newprd_imageArr!!.get(0).toString()
                                    Log.i("My inside ", "getAllProducts prd_image = " + prd_image)
                                    Log.i("My inside ", "getAllProducts newprd_image = " + newprd_image)
                                }
                                if (data_dic.has("new_product")) {
                                    new_product = data_dic.getString("new_product");
                                }
                                if (data_dic.has("cat_id")) {
                                    cat_id = data_dic.getString("cat_id");
                                }
                                if (data_dic.has("brand_id")) {
                                    brand_id = data_dic.getString("brand_id");
                                }
                                if (data_dic.has("productname")) {
                                    productname = data_dic.getString("productname");
                                }

                                if (data_dic.has("productdescription")) {
                                    productdescription = data_dic.getString("productdescription");
                                }
                                if (data_dic.has("status")) {
                                    status = data_dic.getString("status");
                                }
                                if (data_dic.has("prd_price")) {
                                    prd_price = data_dic.getString("prd_price");
                                }
                                if (data_dic.has("prd_splprice")) {
                                    prd_splprice = data_dic.getString("prd_splprice");
                                }
                                if (data_dic.has("stock")) {
                                    stock = data_dic.getString("stock")
                                    Log.i("My ", "new stock = " + stock)
                                    stock1 = stock.toString().toInt()
                                }
                                if (data_dic.has("minimum_qty")) {
                                    min_stock = data_dic.getString("minimum_qty")
                                    minStock1 = min_stock.toString().toInt()
                                    //count = min_stock.toString().toInt() //for set default counter as min quantity
                                    //Singleton.getInstance().selectedcardobj.ecard_selected_qnty = count.toString(); //for set default counter as min quantity
                                }
                                Log.i("My inside ", "getAllProducts name = " + productname+" stock = "+stock+" minStock = "+min_stock); //[black, grey]


                                var roundPojo: SearchProductsModel? =
                                    SearchProductsModel()
                                roundPojo =
                                    SearchProductsModel(
                                        prd_id,
                                        cat_id,
                                        brand_id,
                                        productname,
                                        prd_image,
                                        newprd_image,
                                        productdescription,
                                        status,
                                        prd_price,
                                        prd_splprice,
                                        stock,
                                        min_stock
                                    )
                                //roundPojo.ecard_selected_qnty = "1"; ///main==by default quantity static 1
                                roundPojo.ecard_selected_qnty = min_stock; //main==for initial default value set to minStock
                                roundPojo.best_seller = best_seller;
                                roundPojo.new_product = new_product;

                                roundPojo.item_color = myselectedcolor; //for pass default array
                                roundPojo.item_color2 = colorItemArr; //for pass color array
                                roundPojo.item_color3 = product_color; //for pass color array - inner detail activity
                                roundPojo.item_color4 = newprd_color; //for pass color array - outer adapter

                                my_product_list.add(roundPojo)
                                count++;

                            }

                            if (my_product_list.size == 0) {
                                Log.i("My my_product_list getProductCat ", "size = 0")

                            }
                            else {
                                Log.i("My my_product_list getProductCat ", "size not 0")

                                recyclerView = findViewById(R.id.product_rv)
                                recyclerView.setLayoutManager(LinearLayoutManager(applicationContext));
                                recyclerView.setItemAnimator(androidx.recyclerview.widget.DefaultItemAnimator())
                                SearchProductsAdapter = SearchProductsAdapter(applicationContext, my_product_list);
                                recyclerView.adapter = SearchProductsAdapter

                                //recyclerView.setLayoutManager(LinearLayoutManager(applicationContext));
                                recyclerView.setLayoutManager(GridLayoutManager(applicationContext, 2));
                                recyclerView.adapter?.notifyDataSetChanged()

                            }
                        }
                        else {
                            Log.i("My getProductCat Response = ", "Not Equal to 200")
                            //Toasty.warning(applicationContext, "No Product Found!", Toasty.LENGTH_LONG).show()
                        }
                    }
                    override fun onError(error: ANError) {
                        Log.i("My getProductCat onError = ", "error = " + error)
                        Toasty.warning(applicationContext, "Something went wrong, please try again later!", Toasty.LENGTH_LONG).show()
                        binding.productProgressBar.visibility = View.GONE
                    }
                })
        }

        else
        {
            // do something when device disconnected to internet
            applicationContext?.let { Toasty.warning(it, getString(R.string.no_internet_message), Toast.LENGTH_SHORT, true).show() };

        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }

}