package com.demomvvm.Retrofit.uploadImage

import android.annotation.SuppressLint
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.text.format.DateFormat
import android.util.Base64
import android.util.Log
import android.util.Log.i
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import com.demomvvm.R
import com.demomvvm.databinding.ActivityRetrofitUploadImageBinding
import com.google.android.material.snackbar.Snackbar
import com.yalantis.ucrop.UCrop
import com.yalantis.ucrop.UCropFragment
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import java.io.File
import java.util.*


@SuppressLint("LongLogTag")
class RetrofitUploadImageActivity2 : AppCompatActivity(), UploadRequestBody.UploadCallback {
    private  val requestGallery = 2121
    private var selectedImageUri: Uri? = null

    private var requestMode = 1
    private val REQUEST_SELECT_PICTURE_FOR_FRAGMENT = 0x02
    var photoFile: File? = null
    val REQUEST_CODE_IMAGE = 101

    val PERMISSIONS = arrayOf(
        android.Manifest.permission.CAMERA,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
        android.Manifest.permission.READ_EXTERNAL_STORAGE
    )
    val PERMISSION_ALL = 1

    lateinit var uploadimageUri: Uri
    var uploadimage = ""// API
    var imagename = ""// API
    private var mPictureUri: Uri? = null





    val PICK_IMAGE = 100
    var service: ImageUploadServiceInterface? = null
    private lateinit var imageView: ImageView


    private lateinit var binding: ActivityRetrofitUploadImageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRetrofitUploadImageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        val interceptor = HttpLoggingInterceptor()
        interceptor.level = HttpLoggingInterceptor.Level.BODY
        val client: OkHttpClient = OkHttpClient.Builder().addInterceptor(interceptor).build()

        // Change base URL to your upload server URL.
        //https://app.wemad.com.au/sub/localshopadmin/get_couponimageupload/198.jpg
        service =
                //Retrofit.Builder().baseUrl("http://192.168.0.234:3000").client(client).build().create(
            Retrofit.Builder().baseUrl("https://app.wemad.com.au/sub/localshopadmin/").client(client).build().create(
                ImageUploadServiceInterface::class.java
            )


        val button = findViewById<Button>(R.id.btnOpenGallery)
        imageView = findViewById<ImageView>(R.id.imgSelected)
        button?.setOnClickListener {


            if(!hasPermissions(applicationContext, *PERMISSIONS))
            {
                Log.i("My camera_btn ", "clicked not hasPermissions")
                ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL)
            }
            else
            {
                Log.i("My camera_btn ", "clicked yes hasPermissions = go for crop image")
                try {
                    //selelct from only gallery
                    val intent = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
                    val mimeTypes = arrayOf("image/jpeg", "image/png") //After
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
                    /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) { //Before
                        val mimeTypes = arrayOf("image/jpeg", "image/png")
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
                    }*/
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), requestMode)
                } catch (ex: Exception) {
                    Log.i("My Error RetrofitUploadImageActivity2 ", "in take or select image")
                }
            }
            //ImagePicker.with(this).start(requestGallery)


        }

    }






/*
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.i("My ", "RetrofitUploadImageActivity requestCode = $requestCode")
        Log.i("My ", "RetrofitUploadImageActivity data = $data")

        if (resultCode == Activity.RESULT_OK) {
            Log.i("My ", "RetrofitUploadImageActivity inside RESULT_OK")
            if (requestCode == requestGallery && data != null) {
                Log.i("My ", "RetrofitUploadImageActivity inside data = "+data)
                val fileUri = data.data
                Log.i("My ", "RetrofitUploadImageActivity inside data.data = "+fileUri)
                setImage(Uri.parse(fileUri.toString()))
                ImagePicker.getFile(data)?.let { doRequest(it,Uri.parse(fileUri.toString())) } ?: run{ Toast.makeText(applicationContext,"Ops. Something went wrong.",Toast.LENGTH_SHORT)}


            }
        }


    }
    private fun setImage(uri: Uri) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(contentResolver, uri)
            val bitmap = ImageDecoder.decodeBitmap(source)
            imageView.setImageBitmap(bitmap)

        } else {
            @Suppress("DEPRECATION") val bitmap =
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            imageView.setImageBitmap(bitmap)

        }
    }
    fun doRequest(file:File,uri: Uri) {
        val requestFile = file.asRequestBody(contentResolver.getType(uri)?.toMediaTypeOrNull())
        val body = MultipartBody.Part.createFormData("image", file.name, requestFile)
        Log.i("My ", "RetrofitUploadImageActivity requestFile = $requestFile")
        Log.i("My ", "RetrofitUploadImageActivity file.name = $file.name")
        Log.i("My ", "RetrofitUploadImageActivity body = $body")


//            Log.d("THIS", data.getData().getPath());
        val req = service?.postImage(body, file.name.toString())
        req?.enqueue(object : Callback<ResponseBody?> {
            override fun onResponse(call: Call<ResponseBody?>, response: Response<ResponseBody?>) {
                Log.i("My ", "RetrofitUploadImageActivity call = $call")
                Log.i("My ", "RetrofitUploadImageActivity response = $response")
                val responseCode = response.code()
                if (responseCode == 200) {
                    Toast.makeText(applicationContext, "Uploaded !", Toast.LENGTH_SHORT).show()

                }
            }

            override fun onFailure(call: Call<ResponseBody?>, t: Throwable) {
                Log.i("My ", "RetrofitUploadImageActivity onFailure = $t")
                Toast.makeText(applicationContext, "Failed due ${t.message}", Toast.LENGTH_SHORT)
                    .show()
                t.printStackTrace()
            }
        })

    }

*/

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        try {

            if (requestCode == 0)
            {
                val tsLong = System.currentTimeMillis()
                val ts = tsLong.toString()
                Log.i("My onActivityResult ", "requestCode = 0")
                if (data != null) {
                    selectedImageUri = data.data
                    Log.i("My selectedImageUri ", "from1 data $selectedImageUri") //for both jpg,jpeg
                    selectedImageUri?.let { startCrop(it) }



                }
                else if (selectedImageUri == null) {
                    selectedImageUri = mPictureUri
                    selectedImageUri?.let { startCrop(it) }
                    Log.i("My selectedImageUri ", "from2 mPictureUri $selectedImageUri")
                }
            }

            else if (resultCode == RESULT_OK) {
                Log.i("My onActivityResult ", "requestCode = 0 RESULT_OK")
                if (requestCode == requestMode) {
                    Log.i("My onActivityResult ", "from3 requestCode requestMode = $requestMode")

                    val selectedUri = data?.data
                    if (selectedUri != null) {
                        startCrop(selectedUri)
                    } else {
                        Toast.makeText(applicationContext, "Cannot retrieve selected image", Toast.LENGTH_SHORT).show()
                    }
                }
                else if (requestCode == UCrop.REQUEST_CROP) {
                    Log.i("My onActivityResult ", "from4 requestCode = REQUEST_CROP")
                    data?.let { handleCropResult(it) }
                    Log.i("My Error ", "onActivityResult else if")
                }
            }
            else if (resultCode == UCrop.RESULT_ERROR) {
                Log.i("My onActivityResult ", "from5 requestCode = RESULT_ERROR")
                data?.let { handleCropError(it) }
                Log.i("My Error ", "onActivityResult if")
            }


        } catch (ex: java.lang.Exception) {
            Log.i("My Error RetrofitUploadImageActivity2", "onActivityResult ex = $ex")
        }

    }

    private fun startCrop(uri: Uri) {
        val destinationFileName: String = "SampleCropImage.jpg"

        var uCrop: UCrop = UCrop.of(uri, Uri.fromFile(File(cacheDir, destinationFileName)))

        try {
            uCrop = advancedConfig(uCrop)
            val ratioX: Float = java.lang.Float.valueOf("5")
            val ratioY: Float = java.lang.Float.valueOf("4")
            if (ratioX > 0 && ratioY > 0) {
                uCrop = uCrop.withAspectRatio(ratioX, ratioY)
            }
        } catch (e: Exception) {
            Log.i("My startCrop ", String.format("Number please: %s", e))
        }
        if (requestMode == REQUEST_SELECT_PICTURE_FOR_FRAGMENT) {
            setupFragment(uCrop)
        } else {
            uCrop.start(this@RetrofitUploadImageActivity2)
        }
    }

    open fun setupFragment(uCrop: UCrop) {
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, UCropFragment(), UCropFragment.TAG)
            .commitAllowingStateLoss()
    }

    private fun handleCropResult(result: Intent) {
        val resultUri = UCrop.getOutput(result)
        if (resultUri != null) {

            val iv: ImageView = findViewById<View>(R.id.imgSelected) as ImageView

            iv.setImageURI(null)
            iv.setImageURI(resultUri)

            uploadimageUri = resultUri
            //file:///data/user/0/com.example.androiddemo/cache/SampleCropImage.jpg
            Log.i("My handleCropResult ", "uploadimageUri = "+ uploadimageUri)

            val tsLong = System.currentTimeMillis()
            val ts = tsLong.toString()
            val fileName: String = "app_" + ts + ".jpg" //for concate date and time = app_1613638967094
            uploadimage = fileName
            //app_1673503879335.jpg
            Log.i("My handleCropResult ", "uploadimage = "+ uploadimage)
            var f1 : File = File(fileName)
            Log.i("My handleCropResult ", "file f1 = "+ f1) //app_1673504209219



            //Uri.parse(fileUri.toString())
            //val requestFile2 = result.asRequestBody(contentResolver.getType(resultUri)?.toMediaTypeOrNull())
            val requestFile = f1.asRequestBody(contentResolver.getType(resultUri)?.toMediaTypeOrNull())
            val body = MultipartBody.Part.createFormData("image", fileName, requestFile)
            Log.i("My ", "RetrofitUploadImageActivity requestFile = $requestFile")
            Log.i("My ", "RetrofitUploadImageActivity file.name = $fileName")
            Log.i("My ", "RetrofitUploadImageActivity body = $body")


            binding.btnUploadImage.setOnClickListener {
                uploadImage111()
            }

/*
RetrofitUploadImageActivity onFailure = java.io.FileNotFoundException:
 app_1673516503164.jpg: open failed: ENOENT (No such file or directory)
 */
            //val response: Call<ImageUploadOutputModel>? = service?.postImage(body, fileName)
            //val response: Call<ImageUploadOutputModel>? = service?.uploadImage2(body)


            /*val parcelFileDescriptor = contentResolver.openFileDescriptor(
                uploadimageUri, "r", null
            ) ?: return
            val inputStream = FileInputStream(parcelFileDescriptor.fileDescriptor)
            val file = File(cacheDir,contentResolver.getFileName(uploadimageUri))
            val outputStream = FileOutputStream(file)
            inputStream.copyTo(outputStream)
            Log.i("My ", "RetrofitUploadImageActivity inputStream = $inputStream")
            Log.i("My ", "RetrofitUploadImageActivity file = $file")
            Log.i("My ", "RetrofitUploadImageActivity outputStream = $outputStream")
            Log.i("My ", "RetrofitUploadImageActivity inputStream2 = $inputStream")


            //val body2 = UploadRequestBody(f1,"image",this)
            val body2 = UploadRequestBody(file,"image",this)
            ImageUploadServiceInterface().uploadImage3(MultipartBody.Part.createFormData(
                "image",
                fileName,
                body2
            ),
                RequestBody.create("multipart/form-data".toMediaTypeOrNull(),"json")
            ).enqueue(object : Callback<UploadResponse?> {

                override fun onResponse(
                    call: Call<UploadResponse?>,
                    response: Response<UploadResponse?>
                ) {
                    Log.i("My ", "RetrofitUploadImageActivity call = $call")
                    Log.i("My ", "RetrofitUploadImageActivity response = $response")
                    val responseCode = response.code()
                    if (responseCode == 200) {
                        Toast.makeText(applicationContext, "Uploaded !", Toast.LENGTH_SHORT).show()

                    }
                }
                override fun onFailure(call: Call<UploadResponse?>, t: Throwable) {
                    Log.i("My ", "RetrofitUploadImageActivity onFailure = $t")
                    Toast.makeText(applicationContext, "Failed due ${t.message}", Toast.LENGTH_SHORT)
                        .show()
                    t.printStackTrace()
                }

            });*/

        } else {
            Toast.makeText(this@RetrofitUploadImageActivity2, "Cannot retrieve cropped image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun advancedConfig(uCrop: UCrop): UCrop {
        val options = UCrop.Options()
        options.setHideBottomControls(true) //for hide bottom buttons
        options.setShowCropGrid(intent.getBooleanExtra(UCrop.Options.EXTRA_SHOW_CROP_GRID, false)) //for hide grid 9x9
        return uCrop.withOptions(options)
    }

    private fun handleCropError(result: Intent) {
        val cropError = UCrop.getError(result)
        if (cropError != null) {
            Toast.makeText(this@RetrofitUploadImageActivity2, cropError.message, Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this@RetrofitUploadImageActivity2, "Unexpected error", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_ALL) {
            //if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                //Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show()
                Log.i("My inside ", "first time no permission, and after give permission open camera or gallery")
                try {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                        .setType("image/*")
                        .addCategory(Intent.CATEGORY_OPENABLE)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        val mimeTypes = arrayOf("image/jpeg", "image/png")
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
                    }
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), requestMode)

                } catch (ex: Exception) {
                    Log.i("My Error RetrofitUploadImageActivity onRequestPermissionsResult ", "in take or select image")
                }
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun hasPermissions(context: Context, vararg permissions: String): Boolean = permissions.all {
        ActivityCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onProgressUpdate(percentage: Int) {
        //binding.progressBar.progress = percentage
        Log.i("My ", "RetrofitUploadImageActivity percentage = $percentage")

    }






    public fun uploadImage111() {
        Log.i("My RetrofitUploadImageActivity ", "selectedImageUri = "+selectedImageUri)
        //file:///data/user/0/com.example.androiddemo/cache/SampleCropImage.jpg
        Log.i("My RetrofitUploadImageActivity ", "uploadimageUri = "+uploadimageUri)
        Log.i("My RetrofitUploadImageActivity ", "uploadimage = "+uploadimage) //app_1673518654170.jpg


        var b: Bitmap? = null
        val ssl : ImageView = findViewById(R.id.imgSelected);
        b = ScreenshotUtils.getScreenShot(ssl) //upload image of after taking imageview screenshot(not saved image)

        val now = Date()
        DateFormat.format("yyyy-MM-dd_hh:mm:ss", now)
        val saveFile = ScreenshotUtils.getMainDirectoryName(applicationContext)
        val f12 = ScreenshotUtils.store(b, "screenshot_" + now + ".jpg", saveFile)

        val photoURI = f12?.let {
            FileProvider.getUriForFile(
                applicationContext, applicationContext.packageName.toString() + ".provider",
                it
            )
        }
        //f12=/storage/emulated/0/Android/data/com.example.androiddemo/files/Pictures/Demo/screenshot_Thu Jan 12 16:37:08 GMT+05:30 2023.jpg
        //f12 getAbsolutePath = /storage/emulated/0/Android/data/com.example.androiddemo/files/Pictures/Demo/screenshot_Thu Jan 12 16:37:08 GMT+05:30 2023.jpg
        Log.i("My RetrofitUploadImageActivity ", "f12 = "+f12)
        Log.i("My RetrofitUploadImageActivity ", "f12 getAbsolutePath = "+f12?.getAbsolutePath())
        //content://com.example.androiddemo.provider/external_files/Android/data/com.example
        Log.i("My RetrofitUploadImageActivity ", "f12 photoURI = "+photoURI)




        if (uploadimageUri == null) {
            binding.layoutRoot.snackbar("Select an Image First")
            return
        }


        val body = UploadRequestBody(f12!!,"image",this)
        Log.i("My RetrofitUploadImageActivity ", "body = "+body) //com.example.androiddemo.RetrofitUploadImage.UploadRequestBody@98c2f61





        binding.progressBar.setVisibility(View.VISIBLE)
        //binding.progressBar.progress = 0
        ImageUploadServiceInterface().uploadImage3(MultipartBody.Part.createFormData(
            "uploaded_file",
            //f12.name, //file name,
            "266.jpg", //file name,
            body //file path, "image"
        ), RequestBody.create("multipart/form-data".toMediaTypeOrNull(),"json")
        )
            .enqueue(object : Callback<UploadResponse>{
                override fun onResponse(
                    call: Call<UploadResponse>,
                    response: Response<UploadResponse>
                ) {
                    Log.i("My RetrofitUploadImageActivity onResponse ", "response = "+response)
                    //UploadResponse(error=false, message=Success, image=null)
                    Log.i("My RetrofitUploadImageActivity onResponse ", "response body = "+response.body())

                    response.body()?.let {
                        binding.layoutRoot.snackbar(it.message)
                        //binding.progressBar.progress = 100
                        binding.progressBar.setVisibility(View.GONE)
                    }
                }

                override fun onFailure(call: Call<UploadResponse>, t: Throwable) {
                    binding.layoutRoot.snackbar(t.message!!)
                    //binding.progressBar.progress = 0
                    binding.progressBar.setVisibility(View.GONE)

                    Log.i("My Error RetrofitUploadImageActivity onFailure ", "t = "+t)
                    /*
                    Error RetrofitUploadImageActivity onFailure:
                    t = java.io.FileNotFoundException: /storage/emulated/0/Download/app_1673518935937.jpg:
                     open failed: ENOENT (No such file or directory)
                     */

                }

            })


    }



    private fun View.snackbar(message: String) {
        Snackbar.make(this, message, Snackbar.LENGTH_LONG).also { snackbar ->
            snackbar.setAction("OK") {
                snackbar.dismiss()
            }
        }.show()

    }



}