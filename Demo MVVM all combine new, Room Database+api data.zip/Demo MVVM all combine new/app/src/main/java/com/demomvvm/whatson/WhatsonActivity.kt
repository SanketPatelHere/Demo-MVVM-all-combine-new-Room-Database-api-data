package com.demomvvm.whatson

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.text.format.DateFormat
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.demomvvm.LoadMoreRecycleView.LoadMoreRecycleViewActivity
import com.demomvvm.MVVM.GiftCard.GiftCardMovieAdapter
import com.demomvvm.MVVM.GiftCard.GiftCardMovies
import com.demomvvm.MVVM.GiftCard.GiftCardResult
import com.demomvvm.MVVM.RetrofitInstance
import com.demomvvm.MVVM.RoomDatabase.Book
import com.demomvvm.MVVM.RoomDatabase.BookDatabase
import com.demomvvm.R
import com.demomvvm.Retrofit.RetrofitDemo.APIClient
import com.demomvvm.Retrofit.RetrofitDemo.APIInterface
import com.demomvvm.Retrofit.RetrofitDemo.CustomAdapter
import com.demomvvm.Retrofit.RetrofitDemo.RetroPhoto
import com.demomvvm.Retrofit.uploadImage.*
import com.demomvvm.Singleton
import com.demomvvm.databinding.ActivityNewRetofit2Binding
import com.demomvvm.databinding.ActivityNewRetofitBinding
import com.demomvvm.databinding.ActivityWhatsonBinding
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.xoxoer.lifemarklibrary.Lifemark
import com.yalantis.ucrop.UCrop
import com.yalantis.ucrop.UCropFragment
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.Authenticator
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.Route
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.util.*
import kotlin.collections.HashMap

//without mvvm
//retrofit example = https://www.digitalocean.com/community/tutorials/retrofit-android-example-tutorial
//for image upload
@SuppressLint("LongLogTag")
class WhatsonActivity : AppCompatActivity() {
    val TAG = "Myy WhatsonActivity "
    
    //for whatson rv =
    val whatson_list: ArrayList<WhatsonPojo> = ArrayList()

    private lateinit var binding: ActivityWhatsonBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWhatsonBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))
        window.navigationBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))

        getWhatsOnData()

    }

    public open fun getAuthentication(): OkHttpClient {
        var authstr = getString(R.string.api_auth_user) + ":" + getString(R.string.api_auth_pass);
        val encodedString  = android.util.Base64.encodeToString(authstr.toByteArray(), android.util.Base64.NO_WRAP);
        val encoding = encodedString as String
        ///binding2.newbaseLoading.start()

        val okHttpClient: OkHttpClient = OkHttpClient.Builder()
            .authenticator(object : Authenticator {
                @Throws(Exception::class)
                override fun authenticate(route: Route?, response: okhttp3.Response): okhttp3.Request? {
                    return response.request.newBuilder()
                        .header("Authorization", "Basic $encoding")
                        .build()
                }
            })
            .build()

        return okHttpClient
    }


    //todo What's On rv start
    //getWhatsOnData of ven ue change from other apps
    fun getWhatsOnData()
    {
        val networkConnection = Lifemark(applicationContext)
        if (networkConnection.isNetworkConnected())
        {

            //egift_card_price_list.clear()  //for both res success or error remove list and rv refresh
            //startEGiftCardAnim()

            //val api_url = Singleton1.getInstance().apibaseurl + "/home/homepagenewlayout"
            val api_url = "https://appv2.wemad.com.au" + "/home/homepagenewlayout"

            val sharedPreferences = this@WhatsonActivity.getSharedPreferences(getString(R.string.login_detail), Context.MODE_PRIVATE)
            //val login_user_id = sharedPreferences?.getString(getString(R.string.user_id), "")

            val sharedPreferencesCharity = this@WhatsonActivity.getSharedPreferences("CharityPopup", Context.MODE_PRIVATE)
            val jsonObject = JSONObject()
            jsonObject.put("site_id", "101")
            jsonObject.put("user_id", "")
            Log.i(TAG, "getAllData API parameter = $jsonObject Api URL :- $api_url")

            AndroidNetworking.post(api_url)
                .setOkHttpClient(getAuthentication())
                //.addBodyParameter("site_id", getString(R.string.site_id)) //new=pass new site_id, old=getString(R.string.site_id)
                .addBodyParameter("site_id", "101") //new=pass new site_id, old=getString(R.string.site_id)
                .addBodyParameter("user_id", "") //when logout then pass user_id=0
                .setTag("test")
                .build()
                .getAsJSONObject(object : JSONObjectRequestListener {
                    override fun onResponse(response: JSONObject) {
                        // do anything with response            }

                        //stopEGiftCardAnim()

                        Log.i(TAG, "getWhatsOnData card API Full Responce :- $response")
                        try {
                            if (response.getString("status") == "200")
                            {
                                if (response.has("events"))
                                {
                                    Log.i(TAG, "getWhatsOnData = getting data")

                                    whatson_list.clear()
                                    Log.i(TAG, "getWhatsOnData = events array is not null")

                                    var event_id= ""
                                    var site_id= ""
                                    var event_title= ""
                                    var event_seourl= ""
                                    var event_startdate= ""
                                    var event_enddate= ""
                                    var event_displaydate= ""
                                    var event_desc= ""
                                    var event_vanue= ""
                                    var event_information= ""
                                    var event_contact_email= ""
                                    var event_contact_website= ""
                                    var event_image= ""
                                    var event_facebook= ""
                                    var event_insta= ""
                                    var event_twitter= ""
                                    var event_youtube= ""
                                    var status= ""

                                    val eventsArray = response.getJSONArray("events")
                                    Log.i(TAG, "getWhatsOnData res eventsArray = "+eventsArray)

                                    for (j in 0..(eventsArray.length() - 1))
                                    {
                                        val data_dic = eventsArray.getJSONObject(j)

                                        if (data_dic.has("event_id")) {
                                            event_id = data_dic.getString("event_id")
                                        }
                                        if (data_dic.has("event_title")) {
                                            event_title = data_dic.getString("event_title")
                                        }
                                        if (data_dic.has("event_startdate")) {
                                            event_startdate = data_dic.getString("event_startdate")
                                        }
                                        if (data_dic.has("event_enddate")) {
                                            event_enddate = data_dic.getString("event_enddate")
                                        }

                                        if (data_dic.has("event_displaydate")) {
                                            event_displaydate = data_dic.getString("event_displaydate")
                                        }
                                        if (data_dic.has("event_image")) {
                                            event_image = data_dic.getString("event_image")
                                        }
                                        if (data_dic.has("event_seourl")) {
                                            event_seourl = data_dic.getString("event_seourl")
                                        }
                                        if (data_dic.has("event_desc")) {
                                            event_desc = data_dic.getString("event_desc")
                                        }

                                        if (data_dic.has("event_contact_website")) {
                                            event_contact_website = data_dic.getString("event_contact_website")
                                        }
                                        if (data_dic.has("status")) {
                                            status = data_dic.getString("status")
                                        }

                                        if (data_dic.has("event_vanue")) {
                                            event_vanue = data_dic.getString("event_vanue")
                                        }

                                        val whatsonPojo1 = WhatsonPojo()
                                        whatsonPojo1.event_id = event_id
                                        whatsonPojo1.event_title = event_title
                                        whatsonPojo1.event_desc = event_desc
                                        whatsonPojo1.event_startdate = event_startdate
                                        whatsonPojo1.event_enddate = event_enddate
                                        whatsonPojo1.event_displaydate = event_displaydate

                                        whatsonPojo1.event_image = event_image
                                        whatsonPojo1.event_seourl = event_seourl
                                        whatsonPojo1.event_contact_website = event_contact_website
                                        whatsonPojo1.status = status
                                        whatsonPojo1.event_vanue = event_vanue
                                        whatson_list.add(whatsonPojo1)



                                    }

                                    if (whatson_list.size == 0)
                                    {
                                        Log.i(TAG, "getWhatsOnData = data size 0")
                                        //show when text search not blank
                                    }
                                    else
                                    {
                                        Log.i(TAG, "getWhatsOnData = data size not 0")
                                        //binding.myWhatsOnLv.setVisibility(View.VISIBLE)

                                        //todo for sort whatson_list by date wise start
                                        //whatson_list.sortedBy { it.event_startdate }
                                        ///whatson_list.sortByDescending  { it.event_startdate } //working
                                        // Reverse order by date
                                        /*Comparator<Movie> comparator = new Comparator<Movie>() {
                                        @Override
                                        public int compare(Movie movie, Movie t1) {
                                            return movie.genre.compareTo(t1.genre)
                                        }
                                    }
                                    Collections.sort(whatson_list, Collections.reverseOrder(comparator))*/
                                        //todo for sort whatson_list by date wise end

                                        //for viewpager
                                        //Set the pager with an adapter
                                        val viewPager = binding.viewPagerWhatsOn

                                        //val mViewPagerWithIndicator = whatson_viewpager as ViewPagerWithIndicator
                                        //val objects = Arrays.asList(Color.BLUE, Color.RED, Color.GREEN)
                                        //mViewPager.setAdapter(CustomViewPagerAdapter(activity, objects))
                                        viewPager.setAdapter(WhatsonAdapter(this@WhatsonActivity, whatson_list, WhatsonAdapter.OnItemClickListener() { whatsonPojo: WhatsonPojo, indexPos: Int, objectName: String, viewobject: View ->

                                            if (objectName.equals("imgWhatsonClicked")) //my new event add
                                            {
                                                Log.i(TAG,"getWhatsOnData if imgBannereCompare1 clicked for event_title = "+whatsonPojo.event_title+ " and event_contact_website = "+whatsonPojo.event_contact_website)
                                                //https://wynnumfringe.com/events/imaanhadchiti/
                                                //https://wynnumfringe.com/events/goodchat/
                                                /*val intent = Intent(this@WhatsonActivity, WebviewActivity::class.java)
                                                intent.putExtra("item_link", whatsonPojo.event_contact_website)
                                                intent.putExtra("item_html", "")
                                                intent.putExtra("item_name", whatsonPojo.event_title)
                                                intent.putExtra("hide_header", "true")
                                                intent.putExtra("comes_from", "WhatsonActivity")
                                                startActivity(intent)*/
                                            }
                                            else
                                            {
                                                Log.i(TAG,"getWhatsOnData else clicked")
                                                //https://wynnuWhatsonActivityevents/imaanhadchiti/
                                                //https://wynnumfringe.com/events/goodchat/
                                                /*val intent = Intent(this@WhatsonActivity, WebviewActivity::class.java)
                                                intent.putExtra("item_link", whatsonPojo.event_contact_website)
                                                intent.putExtra("item_html", "")
                                                intent.putExtra("item_name", Html.fromHtml(whatsonPojo.getEvent_title()).toString())
                                                intent.putExtra("hide_header", "true")
                                                intent.putExtra("comes_from", "WhatsonActivity")
                                                startActivity(intent)*/
                                            }


                                        })) //for viewpager or
                                        //mViewPagerWithIndicator.setViewPager(mViewPager) //for show dot+left+right arrow



                                        //for rv
                                        /* recyclerViewWhatson = findViewById(R.id.binding.whatsonRecyclerHome) as RecyclerView


                                     recyclerViewWhatson.adapter = WhatsonAdapter(activity, whatson_list, WhatsonAdapter.OnItemClickListener() { whatsonPojo: WhatsonPojo, indexPos: Int, objectName: String, viewobject: View ->

                                         if (objectName.equals("imgWhatsonClicked")) //my new event add
                                         {
                                             Log.i(TAG,"getWhatsOnData if imgBannereCompare1 clicked for event_title = "+whatsonPojo.event_title+ " and event_contact_website = "+whatsonPojo.event_contact_website)
                                             //https://wynnumfringe.com/events/imaanhadchiti/
                                             //https://wynnumfringe.com/events/goodchat/
                                             val intent = Intent(activity, WebviewActivity::class.java)
                                             intent.putExtra("item_link", whatsonPojo.event_contact_website)
                                             intent.putExtra("item_html", "")
                                             intent.putExtra("item_name", whatsonPojo.event_title)
                                             intent.putExtra("hide_header", "true")
                                             intent.putExtra("comes_from", "WhatsonActivity")
                                             startActivity(intent)
                                         }
                                         else
                                         {
                                             Log.i(TAG,"getWhatsOnData else clicked")
                                             //https://wynnumfringe.com/events/imaanhadchiti/
                                             //https://wynnumfringe.com/events/goodchat/
                                             val intent = Intent(activity, WebviewActivity::class.java)
                                             intent.putExtra("item_link", whatsonPojo.event_contact_website)
                                             intent.putExtra("item_html", "")
                                             intent.putExtra("item_name", Html.fromHtml(whatsonPojo.getEvent_title()).toString())
                                             intent.putExtra("hide_header", "true")
                                             intent.putExtra("comes_from", "WhatsonActivity")
                                             startActivity(intent)
                                         }

                                     })

                                     recyclerViewWhatson.setLayoutManager(LinearLayoutManager(getActivity()?.getApplicationContext(), LinearLayoutManager.HORIZONTAL, false)) //for show horizontal rv
                                     //recyclerViewWhatson.setLayoutManager(LinearLayoutManager(activity))
                                     //recyclerViewWhatson.setLayoutManager(GridLayoutManager(activity, 2)) //for show 2X2 rv
                                     recyclerViewWhatson.setItemAnimator(androidx.recyclerview.widget.DefaultItemAnimator())
*/
                                        //todo disable recyclerview touch event - only scroll by arrow action start
                                        /*
                                    val disabler: OnItemTouchListener = RecyclerViewDisabler()
                                    recyclerViewWhatson.addOnItemTouchListener(disabler) //disables scolling - bydefault disable
                                    */
                                        //todo disable recyclerview touch event - only scroll by arrow action end



                                        var count : Int = 0
                                        ///binding.imgLeftarrow.setVisibility(View.GONE) //bydefault remove left arrow
                                        if(whatson_list.size==1)
                                        {
                                            //when only two item = remove left/right arrow
                                            binding.imgLeftarrow.setVisibility(View.GONE)
                                            binding.imgRightarrow.setVisibility(View.GONE)
                                        }

                                        Log.i(TAG, "getWhatsOnData = count = "+count+" and whatson_list.size = "+whatson_list.size)

                                        //for viewpager - left,right image event
                                        binding.imgLeftarrow.setOnClickListener{
                                            Log.i(TAG, "getWhatsOnData img_leftarrow = new viewPager.currentItem = "+viewPager.currentItem+" and viewPager.currentItem = "+whatson_list.size)
                                            var tab = viewPager.currentItem
                                            if (tab > 0) {
                                                tab--
                                                viewPager.currentItem = tab
                                            }
                                            else if (tab == 0) {
                                                viewPager.currentItem = tab
                                                //binding.imgLeftarrow.setVisibility(View.GONE)
                                            }

                                            /*if(tab == 0)
                                        {
                                            binding.imgLeftarrow.setVisibility(View.GONE)
                                        }
                                        else
                                        {
                                            binding.imgLeftarrow.setVisibility(View.VISIBLE)
                                        }*/
                                            binding.imgRightarrow.setVisibility(View.VISIBLE)
                                            Log.i(TAG, "getWhatsOnData img_leftarrow = new viewPager.currentItem = "+viewPager.currentItem+" and tab = "+tab+" and viewPager.currentItem = "+whatson_list.size)
                                        }

                                        binding.imgRightarrow.setOnClickListener{
                                            var tab = viewPager.currentItem
                                            tab++
                                            viewPager.currentItem = tab
                                            binding.imgLeftarrow.setVisibility(View.VISIBLE)
                                            /*if(tab.equals(whatson_list.size))
                                        {
                                            binding.imgRightarrow.setVisibility(View.GONE)
                                        }
                                        else
                                        {
                                            binding.imgRightarrow.setVisibility(View.VISIBLE)
                                        }*/
                                            Log.i(TAG, "getWhatsOnData img_rightarrow = new viewPager.currentItem = "+viewPager.currentItem+" and tab = "+tab+" and viewPager.currentItem = "+whatson_list.size)
                                        }

                                        //for rv - left,right image event
                                        /*binding.imgLeftarrow.setOnClickListener{


                                        Log.i(TAG, "Myy WhatsonActivity getWhatsOnData img_leftarrow = ", "new count = "+count+" and whatson_list.size = "+whatson_list.size)
                                        if(count==0)
                                        {
                                            ///binding.imgLeftarrow.setVisibility(View.GONE)
                                            //recyclerViewWhatson.smoothScrollToPosition(recyclerViewWhatson.findViewHolderForPosition() + 1)
                                        }
                                        else
                                        {
                                            binding.imgRightarrow.setVisibility(View.VISIBLE)
                                            count--
                                            recyclerViewWhatson.smoothScrollToPosition(count)
                                        }


                                    }*/

                                        /*binding.imgRightarrow.setOnClickListener {
                                        *//*recyclerViewWhatson.removeOnItemTouchListener(disabler) //scrolling is enabled again - for click action
                                                val handler = Handler()
                                                handler.postDelayed({
                                                    recyclerViewWhatson.addOnItemTouchListener(disabler) //disables scolling
                                                }, 3000)
*//*

                                                //count++
                                                //Log.i(TAG, "Myy WhatsonActivity getWhatsOnData img_rightarrow11 = ", "new count = "+(count)+" >= whatson_list.size = "+(whatson_list.size-2))
                                                //if(count>=(whatson_list.size-1)) //13==14, 14==14 => 13==14-1, 13==13
                                                //at the 13 th pos also hide arrow = 13,14 hide arrow
                                                //if((count+1)>=(whatson_list.size-1)) //13+1==14, 14==14
                                                if((count)==whatson_list.size) //13+1==14, 14==14
                                                {
                                                    ///binding.imgRightarrow.setVisibility(View.GONE)
                                                }
                                                else
                                                {
                                                    binding.imgLeftarrow.setVisibility(View.VISIBLE)
                                                    count++
                                                    recyclerViewWhatson.smoothScrollToPosition(count)
                                                }
                                                i("Myy WhatsonActivity getWhatsOnData img_rightarrow = ", "new count = "+count+" and whatson_list.size = "+whatson_list.size)
                                                if((count)==(whatson_list.size-1)) //13+1==14, 14==14
                                                {
                                                    ///binding.imgRightarrow.setVisibility(View.GONE)
                                                }


                                            }*/

                                        //not work - left arrow two items scrolled
                                        /*recyclerViewWhatson.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                                        override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                                            super.onScrollStateChanged(recyclerView, newState)

                                            val scrolledPosition = (recyclerViewWhatson.layoutManager as? LinearLayoutManager)?.findFirstVisibleItemPosition() ?: return
                                            i("Myy WhatsonActivity getWhatsOnData = ", "count = "+count+" and whatson_list.size = "+whatson_list.size+" and scrolledPosition = "+scrolledPosition)
                                            count = scrolledPosition

                                            if(count==0)
                                            {
                                                binding.imgLeftarrow.setVisibility(View.GONE)
                                                //recyclerViewWhatson.smoothScrollToPosition(recyclerViewWhatson.findViewHolderForPosition() + 1)
                                            }
                                            if((count)==(whatson_list.size-1)) //13+1==14, 14==14
                                            {
                                                binding.imgRightarrow.setVisibility(View.GONE)
                                            }
                                        }

                                        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                                            super.onScrolled(recyclerView, dx, dy)

                                        }
                                    })*/

                                    }
                                }
                                else
                                {
                                    Log.i(TAG,"getWhatsOnData = empty data")
                                    whatson_list.clear()
                                    //binding.myWhatsOnLv.setVisibility(View.GONE)
                                    //activity?.let { Toasty.warning(it, "Something went wrong please try again !", Toast.LENGTH_SHORT, true).show() }
                                }
                            }
                            else
                            {
                                //stopEGiftCardAnim()
                                whatson_list.clear()
                                //for both res success or error remove list and rv refresh
                                if (whatson_list.size == 0)
                                {
                                    //binding.myWhatsOnLv.setVisibility(View.GONE)
                                }
                                Log.i(TAG, "getWhatsOnData card API res else Error :- $response")
                                //when search for specific category and res success = 102
                                //Toasty.warning(this@WhatsonActivity, "Something went wrong please try again !", Toast.LENGTH_SHORT, true).show()
                            }

                        }
                        catch(ex: Exception)
                        {
                            //stopEGiftCardAnim()
                            if (whatson_list.size == 0)
                            {
                                //binding.myWhatsOnLv.setVisibility(View.GONE)
                            }
                            Log.i(TAG, "getWhatsOnData card API catch Error :- $ex")
                            //when search for specific category and res success = 102
                            //Toasty.warning(this@WhatsonActivity, "Something went wrong please try again !", Toast.LENGTH_SHORT, true).show()
                        }
                        finally
                        {
                            // optional finally block
                            //todo for refresh rv when search new category
                            ////recyclerView.adapter?.notifyDataSetChanged()
                        }
                    }

                    override fun onError(error: ANError)
                    {
                        //error = com.androidnetworking.error.ANError: java.net.SocketTimeoutException: SSL handshake timed out
                        //stopEGiftCardAnim()
                        if (whatson_list.size == 0)
                        {
                            //binding.myWhatsOnLv.setVisibility(View.GONE)
                        }
                        Log.i(TAG, "getWhatsOnData get_ecard API onError :- $error")
                    }
                })
        }
        else
        {
            // do something when device disconnected to internet
            Log.i(TAG, "getWhatsOnData Egift no internet connection")
            whatson_list.clear() ////for remove last search data from list when no internet
            if (whatson_list.size == 0)
            {
                //binding.myWhatsOnLv.setVisibility(View.GONE)
                //binding.egiftCardErrorViewHome.setTitle(getString(R.string.no_internet_message))
            }
            //ToastyWarning(getString(R.string.no_internet_message))
        }
    }
    //todo What's On rv end


}