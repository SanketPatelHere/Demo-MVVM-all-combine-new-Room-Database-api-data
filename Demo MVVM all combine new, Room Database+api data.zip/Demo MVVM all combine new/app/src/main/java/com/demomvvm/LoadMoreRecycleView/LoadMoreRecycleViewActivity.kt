package com.demomvvm.LoadMoreRecycleView

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.demomvvm.Singleton
import com.demomvvm.databinding.ActivityLoadMoreRecycleViewBinding

@SuppressLint("LongLogTag","LogNotTimber")
class LoadMoreRecycleViewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoadMoreRecycleViewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoadMoreRecycleViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))
        window.navigationBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))



    }


}