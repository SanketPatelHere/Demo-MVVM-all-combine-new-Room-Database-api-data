package com.demomvvm.Retrofit.RetrofitDemo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

/*
Retrofit provides with a list of annotations for each of the
HTTP methods: @GET, @POST, @PUT, @DELETE, @PATCH or @HEAD
 */
public interface APIInterface {
    /*@GET("/api/unknown")
    Call<MultipleResource> doGetListResources();*/


    @GET("/photos")
    Call <List<RetroPhoto>> getAllPhotos();


}