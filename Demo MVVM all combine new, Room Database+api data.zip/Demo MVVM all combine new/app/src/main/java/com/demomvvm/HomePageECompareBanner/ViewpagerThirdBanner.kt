package com.vsbenefits.ECompare.HomePageECompareBanner

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.demomvvm.HomePageECompareBanner.BannerEComparePojo
import com.demomvvm.R
import com.squareup.picasso.Picasso

//use in viewpager
//use = third_banner_ecompare_cell_viewpager
//not use this now - a auto viewpager with custom design
/* viewPagerSecondBanner.setAdapter(ViewpagerThirdBanner(activity, my_second_banner_list,
 "home", "secondbanner", ViewpagerThirdBanner.OnItemClickListener() {
  bannerEComparePojo: BannerEComparePojo, indexPos: Int, objectName: String, viewobject: View ->
 */
 /*
class ViewpagerThirdBanner (
    val viewpager : ViewPager2, val imgList:ArrayList<ViewPagerThirdPojo>
): RecyclerView.Adapter<ViewpagerThirdBanner.SliderViewHolder>()
*/
/*

class ViewpagerThirdBanner (
    val context: Context, val viewpager : ViewPager2, val imgList:ArrayList<ViewPagerThirdPojo>,
    var comesActivityName:String, var bannername:String, var listener: OnItemClickListener
): RecyclerView.Adapter<ViewpagerThirdBanner.SliderViewHolder>()
*/

//use for manufacturer(brands) and partners(viewPagerPartners) banners
class ViewpagerThirdBanner(
        var context: Context, val viewpager : ViewPager2, val imgList:ArrayList<ViewPagerThirdPojo>, var comesFrom:String
): RecyclerView.Adapter<ViewpagerThirdBanner.SliderViewHolder>()

{

    val TAG = "Myy ViewpagerThirdBanner "

    //var context = context
    interface OnItemClickListener {
        fun onItemClick(item: BannerEComparePojo?, possition: Int, objectItemName: String?, viewobject: View?)
    }

    inner class SliderViewHolder(var v: View) : RecyclerView.ViewHolder(v) {
        val img = v.findViewById<ImageView>(R.id.imgBannereCompare1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SliderViewHolder {
        val inflator = LayoutInflater.from(parent.context)
        val v = inflator.inflate(R.layout.third_banner_ecompare_cell_viewpager,parent,false)
        return SliderViewHolder(v)
    }

    override fun onBindViewHolder(holder: SliderViewHolder, position: Int) {
        var bannerPojo = imgList.get(position)

        //todo for show eCompare product image start
        //https://www.wemad.com.au/upload/appbanner/1.jpg
        //val url_str: String = listImg.banner_image.toString()
        /*val url_str = context.getString(R.string.api_master_url) + "/upload/appbanner/" + bannerPojo.banner_image
        Log1.i("Myy ", "ViewpagerThirdBanner for " + bannerPojo.banner_cat + " url_str = " + url_str)


        //pass full link from save in pojo
        if(comesFrom.equals("partners") || comesFrom.equals("brands"))
        {
            val url_str = bannerPojo.banner_image
            Log1.i("Myy ", "ViewpagerThirdBanner for " + bannerPojo.banner_cat + " url_str = " + url_str)
        }*/

        val url_str = bannerPojo.banner_image
        ///Log.i(TAG, "for " + bannerPojo.banner_cat + " url_str = " + url_str)
        Picasso.get()
                .load(url_str)
                .placeholder(R.drawable.img_not_available)
                .error(R.drawable.img_not_available)
                .into(holder.img)
        //todo for show eCompare product image end

        //for banner click event
        holder.itemView.setOnClickListener {
            Log.i(TAG,  "our partners clicked for banner_name = "+bannerPojo.banner_name+" and banner_link = "+bannerPojo.banner_link);
            if(bannerPojo.banner_link!=null && bannerPojo.banner_link!="")
            {
                Log.i(TAG, "our partners banner clicked");
                //https://www.wemakeadifferences.net.au/
                //open webview
                //issue - take too much load time in webview
                /*val intent = Intent(context, WebviewActivity::class.java)
                intent.putExtra("item_link", bannerPojo.banner_link)
                intent.putExtra("item_html", "")
                intent.putExtra("item_name", "")
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent)*/

                //redirect to browser
                //issue - in we make app show open with bar tons, ea gles
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(bannerPojo.banner_link))
                context.startActivity(browserIntent)

            }
            else
            {
                Log.i(TAG,  "our partners else clicked");
            }

        }



        if(position==imgList.size-2){
            viewpager.post(run)
        }
    }
    val run = Runnable {
        imgList.addAll(imgList)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = imgList.size
}