package com.demomvvm.Api_Interface
//not use this
interface ApiInterface {



}