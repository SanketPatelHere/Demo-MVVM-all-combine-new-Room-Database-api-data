package com.demomvvm


import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.CompositePageTransformer
import androidx.viewpager2.widget.MarginPageTransformer
import androidx.viewpager2.widget.ViewPager2
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.demomvvm.Cart.AddCartProductsActivity
import com.demomvvm.HomePageECompareBanner.BannerECompareAdapter
import com.demomvvm.HomePageECompareBanner.BannerEComparePojo
import com.demomvvm.LoadMoreRecycleView.LoadMoreRecycleViewActivity
import com.demomvvm.MVVM.MainActivity
import com.demomvvm.Register_Login.LoginActivity
import com.demomvvm.Retrofit.NewRetrofitActivity
import com.demomvvm.Retrofit.NewRetrofitActivity2
import com.demomvvm.SearchFilter.AllProductsSearch.SearchProductsActivity
import com.demomvvm.Volley.MyVolleyActivity
import com.demomvvm.databinding.ActivityHomeDrawerBinding
import com.demomvvm.databinding.NavHeaderHomeBinding
import com.demomvvm.whatson.WhatsonActivity
import com.vsbenefits.ECompare.HomePageECompareBanner.ViewPagerThirdPojo
import com.vsbenefits.ECompare.HomePageECompareBanner.ViewpagerThirdBanner
import com.xoxoer.lifemarklibrary.Lifemark
import es.dmoral.toasty.Toasty
import okhttp3.*
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.*


@Suppress("DEPRECATION")
@SuppressLint("LongLogTag","LogNotTimber","UseCompatLoadingForDrawables", "SetTextI18n")
class HomeActivity : AppCompatActivity(){

    val TAG = "Myy HomeActivity "
    private var isMemberVisible=false
    //for first banner
    val my_first_banner_list: ArrayList<BannerEComparePojo> = ArrayList()
    var timer: Timer? = null

    private lateinit var my_brands_banner_list:ArrayList<ViewPagerThirdPojo>
    private lateinit var sliderAdapter: ViewpagerThirdBanner
    private var sliderHandle2:Handler? =null
    private var sliderHandle3:Handler? =null
    private var sliderRun2:Runnable? =null
    private var sliderRun3:Runnable? =null

    private lateinit var binding: ActivityHomeDrawerBinding
    @SuppressLint("Recycle","ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val window = this.window
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)


        val manager = this.packageManager
        val info = manager.getPackageInfo(this.packageName, PackageManager.GET_ACTIVITIES)
        binding.appVersion.text = "Version : "+info.versionName

        val sharedPreferences = this.getSharedPreferences(getString(R.string.login_detail), Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        //Change Icon
        val icon = sharedPreferences?.getString("icon", "").toString()
        binding.contentHome.localShopLogo.setOnClickListener {
            binding.contentHome.iconThemeContainer.visibility=View.VISIBLE
        }
        binding.contentHome.closeIconThemeContainer.setOnClickListener {
            binding.contentHome.iconThemeContainer.visibility=View.INVISIBLE
        }


        getFirstBanner()
        getBrandsBannerListStatic()

        //for change whole app color base on app icon select
        if(icon=="1"){
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon1)
            Singleton.getInstance().site_color = "#c4ccfc"
        }
        else if(icon=="2"){
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon2)
            Singleton.getInstance().site_color = "#ffc4d4"
        }
        else{
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon3)
            Singleton.getInstance().site_color = "#e42c2c"
        }

        binding.navHeaderHome.navHeaderContainer.setBackgroundColor(Color.parseColor(Singleton.getInstance().site_color.replace(" ", "")))
        window.statusBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))
        window.navigationBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))



        //for change app icon color and app close and again open app
        binding.contentHome.icon1Background.setOnClickListener {
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon1)
            editor.putString("icon","1").apply()
            appIcon1()
        }
        binding.contentHome.icon2Background.setOnClickListener {
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon2)
            editor.putString("icon","2").apply()
            appIcon2()
        }
        binding.contentHome.icon3Background.setOnClickListener {
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon3)
            editor.putString("icon","3").apply()
            appIcon3()
        }



        binding.contentHome.logout.setOnClickListener {
            logout()
        }

        binding.contentHome.volley.setOnClickListener {
            val intent1 = Intent(this, MyVolleyActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.retrofit.setOnClickListener {
            val intent1 = Intent(this, NewRetrofitActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.retrofit2.setOnClickListener {
            val intent1 = Intent(this, NewRetrofitActivity2::class.java)
            startActivity(intent1)
        }
        binding.contentHome.cartActivity.setOnClickListener {
            val intent1 = Intent(this, AddCartProductsActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.searchFilter.setOnClickListener {
            val intent1 = Intent(this, SearchProductsActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.loadMore.setOnClickListener {
            val intent1 = Intent(this, LoadMoreRecycleViewActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.mvvm.setOnClickListener {
            val intent1 = Intent(this, MainActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.whatson.setOnClickListener {
            val intent1 = Intent(this, WhatsonActivity::class.java)
            startActivity(intent1)
        }


        //                          To Access Nav Header
        /*val viewHeader = binding.navView.getHeaderView(0)
        // nav_header.xml is headerLayout
        val navViewHeaderBinding : NavHeaderHomeBinding = NavHeaderHomeBinding.bind(viewHeader)
        // userNameTitle is Children of nav_header
        navViewHeaderBinding.lblUserName.text = "Hi, D!"*/
        binding.navHeaderHome.lblUserName.text = "Hi, DP!"

        //--------------------------Navigation Drawer And Bar
        binding.navView.menu.findItem(R.id.setting_option).setActionView(R.layout.menu_down)
        binding.navView.setNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.setting_option -> {
                    if(!isMemberVisible){
                        binding.navView.menu.findItem(R.id.setting_option).setActionView(R.layout.menu_up)
                        binding.navView.menu.setGroupVisible(R.id.memberBehavior, true)
                        isMemberVisible=true
                    }
                    else{
                        binding.navView.menu.findItem(R.id.setting_option).setActionView(R.layout.menu_down)
                        binding.navView.menu.setGroupVisible(R.id.memberBehavior, false)
                        isMemberVisible=false
                    }
                    true
                }
                else -> false
            }
        }



    }

    private fun appIcon1() {
        Log.i("My --------------------", "appIcon1() called")
        val pm = packageManager
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity3"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.SplashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        val handler = Handler()
        handler.postDelayed({
            //recreate()
            val intent1 = Intent(this, HomeActivity::class.java)
            startActivity(intent1)
            finish()
        },2700)
        //Toast.makeText(this@HomeActivity, "Enable Old Icon", Toast.LENGTH_LONG).show()
    }
    private fun appIcon2() {
        Log.i("My --------------------", "appIcon2() called")
        val pm = packageManager
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.SplashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity3"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        val handler = Handler()
        handler.postDelayed({
            //recreate()
            val intent1 = Intent(this, HomeActivity::class.java)
            startActivity(intent1)
            finish()
        },2700)
        //Toast.makeText(this@HomeActivity, "Enable New Icon", Toast.LENGTH_LONG).show()
    }
    private fun appIcon3() {
        Log.i("My --------------------", "appIcon3() called")
        val pm = packageManager
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.SplashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity3"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        val handler = Handler()
        handler.postDelayed({
            //recreate()
            val intent1 = Intent(this, HomeActivity::class.java)
            startActivity(intent1)
            finish()
        },2700)
        //Toast.makeText(this@HomeActivity, "Enable New Icon", Toast.LENGTH_LONG).show()
    }



    private fun logout() {
        Log.i("My --------------------", "logoutbutton clicked")
        val sharedPreferences = this.getSharedPreferences(getString(R.string.login_detail), Context.MODE_PRIVATE)
        val alertDialog: AlertDialog.Builder = AlertDialog.Builder(this)
        alertDialog.setTitle("Logout")
        alertDialog.setMessage("Do you really want to logout ?")
        alertDialog.setPositiveButton("yes") { _, _ ->
            Log.i("My --------------------", "Yes clicked(logoutbutton)")
            val editor = sharedPreferences.edit()
            editor.clear()
            editor.apply()

            val intent1 = Intent(this, LoginActivity::class.java)
            intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent1)
            finish()
        }
        alertDialog.setNegativeButton("No") { _, _ ->
            Log.i("My --------------------", "No clicked(logoutbutton)")
        }
        val alert: AlertDialog = alertDialog.create()
        alert.setCanceledOnTouchOutside(false)
        alert.show()
    }






    override fun onDestroy() {
        Log.i("My HomeActivity ","onDestroy called")
        super.onDestroy()
    }

    //For No Internet Connection Dialog
    override fun onResume() {
        Log.i("My HomeActivity ","onResume called")
        super.onResume()
        Log.i(TAG, "inside onResume")
        //on resume = every time when any screen come to home screen = on resume again show last screen

        if(sliderHandle2!=null)
        {
            sliderRun2?.let { sliderHandle2?.postDelayed(it,4000) } //for viewpager auto scroll after 3 second
        }
        if(sliderHandle3!=null)
        {
            sliderRun3?.let { sliderHandle3?.postDelayed(it,4000) } //for viewpager auto scroll after 3 second
        }
    }


    override fun onBackPressed() {
        Log.i("My HomeActivity ", "onBackPressed()")
        super.onBackPressed()
    }



    public open fun getAuthentication(): OkHttpClient {
        var authstr = getString(R.string.api_auth_user) + ":" + getString(R.string.api_auth_pass);
        val encodedString  = android.util.Base64.encodeToString(authstr.toByteArray(), android.util.Base64.NO_WRAP);
        val encoding = encodedString as String
        ///binding2.newbaseLoading.start()

        val okHttpClient: OkHttpClient = OkHttpClient.Builder()
            .authenticator(object : Authenticator {
                @Throws(Exception::class)
                override fun authenticate(route: Route?, response: okhttp3.Response): okhttp3.Request? {
                    return response.request.newBuilder()
                        .header("Authorization", "Basic $encoding")
                        .build()
                }
            })
            .build()

        return okHttpClient
    }

    
    //todo for show getFirstBanner banner - api banner start
    fun getFirstBanner()
    {
        binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE) //bydefault hide eCompare banner

        val networkConnection = Lifemark(applicationContext)
        try {
            if(networkConnection.isNetworkConnected()){
                //startAnim()

                val api_url = Singleton1.getInstance().apibaseurl + "/banner/get_banner"
                val sharedPreferences = this@HomeActivity.getSharedPreferences(getString(R.string.login_detail), Context.MODE_PRIVATE)
                //val login_user_id = sharedPreferences?.getString(getString(R.string.user_id), "")

                val jsonObject = JSONObject()
                jsonObject.put("site_id", "54")
                jsonObject.put("banner_cat", "main_home")
                Log.i(TAG, "getFirstBanner get_myecard Ecard API :- $jsonObject Api URL :- $api_url")

                AndroidNetworking.post(api_url)
                    .setOkHttpClient(getAuthentication())
                    .addBodyParameter("site_id", "54")
                    .addBodyParameter("banner_cat", "main_home")
                    .setTag("test")
                    .build()
                    .getAsJSONObject(object : JSONObjectRequestListener {
                        override fun onResponse(response: JSONObject) {

                            ///stopAnim() //main for hide loader
                            Log.i(TAG, "getFirstBanner get_myecard1 Ecard API Full Responce :- $response")

                            try
                            {
                                if(response.getString("status") == "200")
                                {

                                    if(response.has("data"))
                                    {
                                        Log.i(TAG,"getFirstBanner API Fulldata array is not null")
                                        my_first_banner_list.clear()
                                        val eComapreBannerArr = response.getJSONArray("data")

                                        var id = ""
                                        var site_id = ""
                                        var banner_name = ""
                                        var banner_image = ""
                                        var banner_link = ""
                                        var status = ""
                                        var banner_cat = ""
                                        for (j in 0..(eComapreBannerArr.length() - 1)) {
                                            val data_dic = eComapreBannerArr.getJSONObject(j)

                                            if (data_dic.has("id")) {
                                                id = data_dic.getString("id")
                                            }
                                            if (data_dic.has("site_id")) {
                                                site_id = data_dic.getString("site_id")
                                            }
                                            if (data_dic.has("banner_name")) {
                                                banner_name = data_dic.getString("banner_name")
                                            }
                                            if (data_dic.has("banner_image")) {
                                                banner_image = data_dic.getString("banner_image")
                                            }

                                            if (data_dic.has("banner_link")) {
                                                banner_link = data_dic.getString("banner_link")
                                            }
                                            if (data_dic.has("status")) {
                                                status = data_dic.getString("status")
                                            }
                                            if (data_dic.has("banner_cat")) {
                                                banner_cat = data_dic.getString("banner_cat")
                                            }

                                            val ecomapre_banner_dic = BannerEComparePojo(id, site_id, banner_name, banner_image, banner_link, status)
                                            ecomapre_banner_dic.banner_cat = banner_cat
                                            my_first_banner_list.add(ecomapre_banner_dic)
                                        }


                                        Log.i(TAG, "getFirstBanner binding.viewPager my_first_banner_list.size =  ${my_first_banner_list.size} ")

                                        //----------
                                        //uncmomment this when use banner
                                        //not use eCards slide viewpager now
                                        if(my_first_banner_list.size == 0)
                                        {
                                            binding.contentHome.viewPagerFirstBanner.setVisibility(View.INVISIBLE)

                                            //for hide banner LinearLayout
                                            binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE)

                                        }
                                        else
                                        {
                                            //for show banner LinearLayout
                                            binding.contentHome.viewPagerFirstBanner.setVisibility(View.VISIBLE)

                                            //for show banner LinearLayout
                                            binding.contentHome.tblLayoutFirstbanner.setVisibility(View.VISIBLE)

                                            //show banner if SITE_APP_BANNER=1
                                            //otherwise hide
                                            val sharedPreferences = this@HomeActivity.getSharedPreferences(getString(R.string.login_detail), Context.MODE_PRIVATE)
                                            val SITE_APP_BANNER = sharedPreferences?.getString("SITE_APP_BANNER", "")
                                            Log.i(TAG,"getFirstBanner SITE_APP_BANNER = "+SITE_APP_BANNER)

                                            /*if(SITE_APP_BANNER.equals("1"))
                                            {
                                                Log.i(TAG,"getFirstBanner SITE_APP_BANNER = "+SITE_APP_BANNER+" banner shown")
                                                binding.contentHome.tblLayoutFirstbanner.setVisibility(View.VISIBLE)
                                                //binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE) //remove ecompare banner
                                            }
                                            else
                                            {
                                                Log.i(TAG,"getFirstBanner SITE_APP_BANNER = "+SITE_APP_BANNER+" banner hide")
                                                binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE)
                                            }*/




                                            val dotsIndicator = binding.contentHome.firstBannerDotsIndicator
                                            val viewPagerFirstBanner:ViewPager2 = binding.contentHome.viewPagerFirstBanner
                                            //old eWallet
                                            ////viewPager.setAdapter(MyEcardAdapter(context, my_first_banner_list, MyEcardAdapter.OnItemClickListener() { egiftCard: EgiftCard, indexPos: Int, objectName: String, viewobject: View ->
                                            //new eWallet (not used rv = because not scroll full item, user = viewpager)
                                            //mAdapter = MyEcardAdapterHome(context, my_first_banner_list, MyEcardAdapterHome.OnItemClickListener() { egiftCard: EgiftCard, indexPos: Int, objectName: String, viewobject: View ->
                                            viewPagerFirstBanner.setAdapter(BannerECompareAdapter(this@HomeActivity, my_first_banner_list, "home", "firstbanner",
                                                BannerECompareAdapter.OnItemClickListener() { bannerEComparePojo: BannerEComparePojo, indexPos: Int, objectName: String, viewobject: View ->

                                                /*
                                                open activity if = estore, elocal, ecompare, ecard
                                                open browser if  = fix url
                                                 */
                                                if(objectName.equals("imgBannereCompare1")) //my new event add
                                                {
                                                    Log.i(TAG,"getFirstBanner if imgBannereCompare1 clicked for banner_link = "+bannerEComparePojo.banner_link)
                                                    if(bannerEComparePojo.banner_link.equals("ecompare"))
                                                    {
                                                        Log.i(TAG,"getFirstBanner inside if imgBannereCompare1 ecompare")
                                                        //val intent = Intent(this@HomeActivity, TestingActivity::class.java)
                                                        /*val intent = Intent(this@HomeActivity, ECompareActivity::class.java)
                                                        intent.putExtra("push_view", "HomedActivity")
                                                        startActivity(intent)*/
                                                    }
                                                    else
                                                    {
                                                        Log.i(TAG,"getFirstBanner inside if imgBannereCompare1 else")
                                                        try
                                                        {
                                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(bannerEComparePojo.banner_link))
                                                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                            startActivity(intent)
                                                        }
                                                        catch (ex:Exception)
                                                        {
                                                            Log.i(TAG,"getFirstBanner imgBannereCompare1 Error in catch ex = "+ex)
                                                        }
                                                    }

                                                }
                                                else
                                                {
                                                    Log.i(TAG,"getFirstBanner else clicked")
                                                }


                                            })) //for viewpager or
                                            //}) //for recyclerview

                                            dotsIndicator.setViewPager2(viewPagerFirstBanner) //for viewpager dots show

                                            //for autoscroll viewpager --main
                                            try
                                            {
                                                val timerTask: TimerTask = object : TimerTask() {
                                                    override fun run() {
                                                        //list size = 3
                                                        if(my_first_banner_list.size != 0) {
                                                            viewPagerFirstBanner.post(Runnable {
                                                                viewPagerFirstBanner.setCurrentItem(
                                                                    (viewPagerFirstBanner.getCurrentItem() + 1) % my_first_banner_list.size
                                                                )
                                                            })
                                                        }
                                                    }
                                                }
                                                timer = Timer()
                                                timer?.schedule(timerTask, 3000, 3000)
                                            }
                                            catch (ex: Exception) {
                                                Log.i(TAG, "Error in HomeActivity viewPagerFirstBanner slider timerTask = " + ex)
                                            }

                                            if(my_first_banner_list.size == 1)
                                            {
                                                dotsIndicator.setVisibility(View.GONE)
                                            }
                                            else
                                            {
                                                dotsIndicator.setVisibility(View.VISIBLE)
                                            }

                                        }
                                        //---------------

                                    }
                                    else
                                    {
                                        Log.i(TAG, "getFirstBanner Ecard API Fulldata array is null")
                                    }

                                }
                                else
                                {
                                    Log.i(TAG, "getFirstBanner API else not 200")
                                    binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE)
                                }
                            }
                            catch (ex: Exception)
                            {
                                Log.i(TAG, "getFirstBanner API catch ex = " + ex)
                                binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE)
                            }
                            finally
                            {
                                // optional finally block
                            }
                        }

                        override fun onError(error: ANError) {
                            ///stopAnim()
                            binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE)
                            Log.i(TAG, "getFirstBannerAPI onError :- $error")
                        }
                    })
            }
            else
            {
                // do something when device disconnected to internet
                ToastyWarning(getString(R.string.no_internet_message))
                binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE)
            }

        }
        catch (ex: Exception)
        {
            Log.i(TAG, "Error in catch getFirstBanner getDataCardList ex = " + ex)
            binding.contentHome.tblLayoutFirstbanner.setVisibility(View.GONE)
        }


    }
    //todo for show getFirstBanner banner - api banner end

    //todo for show Our Brands - app fix banner start
    //for autoscroll viewpage
    fun getBrandsBannerListStatic()
    {

        val networkConnection = Lifemark(applicationContext)
        try {
            if (networkConnection.isNetworkConnected())
            {
                //1.
                //todo for add static list in second banner start

                my_brands_banner_list = ArrayList()
                //https://www.vsbenefits.com.au/aus/images/app/vs_logo1.png
                val ecomapre_banner_dic1 = ViewPagerThirdPojo("1", "101", "manufacturerBannerClick1", getString(R.string.domain_url2)+"/aus/images/app/vs_logo1.png", "https://www.vsbenefitssmitsubishi.com.au/", "")
                val ecomapre_banner_dic2 = ViewPagerThirdPojo("2", "101", "manufacturerBannerClick2", getString(R.string.domain_url2)+"/aus/images/app/vs_logo2.png", "https://www.vsbenefitss.net.au/", "")
                val ecomapre_banner_dic3 = ViewPagerThirdPojo("3", "101", "manufacturerBannerClick3", getString(R.string.domain_url2)+"/aus/images/app/vs_logo3.png", "https://vsbenefitssldv.com.au/", "")
                val ecomapre_banner_dic4 = ViewPagerThirdPojo("4", "101", "manufacturerBannerClick4", getString(R.string.domain_url2)+"/aus/images/app/vs_logo4.png", "https://www.vsbenefitss.net.au", "")

                val ecomapre_banner_dic5 = ViewPagerThirdPojo("5", "101", "manufacturerBannerClick5", getString(R.string.domain_url2)+"/aus/images/app/vs_logo5.png", "https://www.vsbenefitssgwmhaval.com.au/", "")
                val ecomapre_banner_dic6 = ViewPagerThirdPojo("6", "101", "manufacturerBannerClick6", getString(R.string.domain_url2)+"/aus/images/app/vs_logo6.png", "https://www.vsbenefitsssubaru.com.au/", "")
                val ecomapre_banner_dic7 = ViewPagerThirdPojo("7", "101", "manufacturerBannerClick7", getString(R.string.domain_url2)+"/aus/images/app/vs_logo7.png", "https://www.vsbenefitss.net.au/brands/holden", "")
                //val ecomapre_banner_dic8 = ViewPagerThirdPojo("8", "101", "manufacturerBannerClick8", getString(R.string.domain_url)+"/images/app/manufacturer/8.png", "https://www.evmotobrisbane.com.au/", "")
                val ecomapre_banner_dic9 = ViewPagerThirdPojo("9", "101", "manufacturerBannerClick9", getString(R.string.domain_url2)+"/aus/images/app/vs_logo8.png", "https://www.vsbenefitsschery.com.au/", "")
                val ecomapre_banner_dic10 = ViewPagerThirdPojo("10", "101", "manufacturerBannerClick10", getString(R.string.domain_url2)+"/aus/images/app/vs_logo9.png", "https://www.vsbenefitsschery.com.au/", "")

                my_brands_banner_list.add(ecomapre_banner_dic1)
                my_brands_banner_list.add(ecomapre_banner_dic2)
                my_brands_banner_list.add(ecomapre_banner_dic3)
                my_brands_banner_list.add(ecomapre_banner_dic4)
                my_brands_banner_list.add(ecomapre_banner_dic5)
                my_brands_banner_list.add(ecomapre_banner_dic6)
                my_brands_banner_list.add(ecomapre_banner_dic7)
                //my_brands_banner_list.add(ecomapre_banner_dic8)
                my_brands_banner_list.add(ecomapre_banner_dic9)
                my_brands_banner_list.add(ecomapre_banner_dic10)
                //todo for add static list in second banner end


                Log.i(TAG, "getBrandsBannerListStatic binding.viewPager my_brands_banner_list.size  ${my_brands_banner_list.size} ")


                //todo for added viewpager start
                val viewPagerBrandsBanner = binding.contentHome.viewPagerBrandsBanner
                //sliderAdapter = ViewpagerThirdBanner(context!!.applicationContext, viewPagerBrandsBanner, my_second_banner_list)
                sliderAdapter = ViewpagerThirdBanner(this@HomeActivity, viewPagerBrandsBanner, my_brands_banner_list, "brands")
                /*sliderAdapter = ViewpagerThirdBanner(this@HomeActivity, viewPagerBrandsBanner, my_second_banner_list, "home", "secondbanner", ThirdBannerECompareAdapter.OnItemClickListener() { bannerEComparePojo: BannerEComparePojo, indexPos: Int, objectName: String, viewobject: View ->
                }))*/
                viewPagerBrandsBanner.adapter = sliderAdapter


                //todo for binding.contentHome.imgLeftarrowBrand left,right click start
                if(my_brands_banner_list.size==1)
                {
                    //when only two item = remove left/right arrow
                    binding.contentHome.imgLeftarrowBrand.setVisibility(View.GONE)
                    binding.contentHome.imgLeftarrowBrand.setVisibility(View.GONE)
                }
                //for viewPagerBrandsBanner - left,right image event
                binding.contentHome.imgLeftarrowBrand.setOnClickListener{
                    Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgLeftarrowBrand = new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem)
                    var tab = viewPagerBrandsBanner?.currentItem
                    if (tab != null) {
                        if (tab > 0) {
                            tab--
                            viewPagerBrandsBanner?.currentItem = tab
                        }
                        else if (tab == 0) {
                            viewPagerBrandsBanner?.currentItem = tab
                            //binding.imgLeftarrow.setVisibility(View.GONE)
                        }
                        Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgLeftarrowBrand = tab is not null new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                    }
                    else
                    {
                        Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgLeftarrowBrand = tab is null new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                    }

                    binding.contentHome.imgRightarrowBrand.setVisibility(View.VISIBLE)
                    Log.i(TAG, "getBrandsBannerListStatic new binding.contentHome.imgLeftarrowBrand = new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.currentItem.size = "+my_brands_banner_list.size)

                }

                binding.contentHome.imgRightarrowBrand.setOnClickListener{
                    Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgRightarrowBrand = viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)


                    var tab = viewPagerBrandsBanner?.currentItem
                    if (tab != null) {
                        Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgRightarrowBrand = tab is not null new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                        tab++
                        viewPagerBrandsBanner?.currentItem = tab
                    }
                    else
                    {
                        Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgRightarrowBrand = tab is null new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                    }
                    binding.contentHome.imgLeftarrowBrand.setVisibility(View.VISIBLE)

                    Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgRightarrowBrand = new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and tab = "+tab+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                }

                //todo for binding.contentHome.imgLeftarrowBrand left,right click end




                //for auto scroll viewpage
                viewPagerBrandsBanner.clipToPadding = false  //comment this for only 1 image(padding 20)
                viewPagerBrandsBanner.clipChildren = false //comment this for only 1 image(padding 20)
                viewPagerBrandsBanner.offscreenPageLimit = 3 //comment this for only 1 image(padding 20)
                viewPagerBrandsBanner.getChildAt(0).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
                val comPosPageTarn = CompositePageTransformer()
                //viewPagerThirdBanner.setPageTransformer(MarginPageTransformer(40)) //or
                comPosPageTarn.addTransformer(MarginPageTransformer(40))
                comPosPageTarn.addTransformer { page, position ->
                    val r:Float = 1 - Math.abs(position)
                    page.scaleY = 0.85f + r * 0.15f
                }
                viewPagerBrandsBanner.setPageTransformer(comPosPageTarn)
                sliderHandle2 = Handler()
                sliderRun2 = Runnable {
                    viewPagerBrandsBanner.currentItem = viewPagerBrandsBanner.currentItem+1
                }

                //for autoscroll item at every 3 second
                viewPagerBrandsBanner.registerOnPageChangeCallback(
                    object : ViewPager2.OnPageChangeCallback(){
                        override fun onPageSelected(position: Int) {
                            sliderHandle2!!.removeCallbacks(sliderRun2!!)
                            sliderHandle2!!.postDelayed(sliderRun2!!,4000)
                        }
                    }
                )
                //todo for added viewpager end

            }
            else
            {
                // do something when device disconnected to internet
                ToastyWarning(getString(R.string.no_internet_message))
            }
        }
        catch (ex: Exception)
        {
            Log.i(TAG, "getSecondBannerListStatic Error in catch getDataCardList ex = " + ex)
        }

    }
    //todo for show Our Brands - app fix banner end



    //todo convert image to base64 encryption start
    private fun encodeImage(filesToUpload: Uri): String?{
        var encoded: String? = null

        //Log.i(TAG, "encodeImage filesToUpload = "+filesToUpload); //tquujJ3XECq9Z5OTp8tJGomfjylFLo2gkg0Qrxnjuru

        //or
        //Encode Bitmap in base64
        //or from image path
        val bitmap2 = MediaStore.Images.Media.getBitmap(contentResolver, filesToUpload)
        //initialize byte stream
        val stream = ByteArrayOutputStream()
        //compress Bitmap
        //bitmap2.compress(Bitmap.CompressFormat.JPEG, 100, stream)
        bitmap2.compress(Bitmap.CompressFormat.JPEG, 60, stream)
        //Initialize byte array
        val bytes = stream.toByteArray()
        //get base64 encoded string
        //encoded = Base64.encodeToString(bytes, Base64.DEFAULT)
        encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
        //Log.i(TAG, "encodeImage encoded = "+encoded); //tquujJ3XECq9Z5OTp8tJGomfjylFLo2gkg0Qrxnjuru
        return encoded
    }
    //todo convert image to base64 encryption end

    public fun ToastyWarning(s: String) {
        //Toasty.warning(this,s,Toasty.LENGTH_SHORT).show()
        Toasty.warning(applicationContext,s, Toasty.LENGTH_SHORT).show()
    }
    public fun ToastySuccess(s: String) {
        //Toasty.success(this,s,Toasty.LENGTH_SHORT).show()
        Toasty.success(applicationContext,s, Toasty.LENGTH_SHORT).show()
    }
    
    
}