package com.demomvvm


import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.CompositePageTransformer
import androidx.viewpager2.widget.MarginPageTransformer
import androidx.viewpager2.widget.ViewPager2
import com.demomvvm.Cart.AddCartProductsActivity
import com.demomvvm.LoadMoreRecycleView.LoadMoreRecycleViewActivity
import com.demomvvm.MVVM.MainActivity
import com.demomvvm.Register_Login.LoginActivity
import com.demomvvm.Retrofit.NewRetrofitActivity
import com.demomvvm.Retrofit.NewRetrofitActivity2
import com.demomvvm.SearchFilter.AllProductsSearch.SearchProductsActivity
import com.demomvvm.Volley.MyVolleyActivity
import com.demomvvm.databinding.ActivityHomeDrawerBinding
import com.demomvvm.databinding.NavHeaderHomeBinding
import com.demomvvm.whatson.WhatsonActivity
import com.vsbenefits.ECompare.HomePageECompareBanner.ViewPagerThirdPojo
import com.vsbenefits.ECompare.HomePageECompareBanner.ViewpagerThirdBanner
import com.xoxoer.lifemarklibrary.Lifemark
import es.dmoral.toasty.Toasty
import okhttp3.*
import java.util.*


@Suppress("DEPRECATION")
@SuppressLint("LongLogTag","LogNotTimber","UseCompatLoadingForDrawables", "SetTextI18n")
class HomeActivity : AppCompatActivity(){

    val TAG = "Myy HomeActivity "
    private var isMemberVisible=false
    private lateinit var my_brands_banner_list:ArrayList<ViewPagerThirdPojo>
    private lateinit var sliderAdapter: ViewpagerThirdBanner
    private var sliderHandle2:Handler? =null
    private var sliderHandle3:Handler? =null
    private var sliderRun2:Runnable? =null
    private var sliderRun3:Runnable? =null

    private lateinit var binding: ActivityHomeDrawerBinding
    @SuppressLint("Recycle","ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val window = this.window
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)


        val manager = this.packageManager
        val info = manager.getPackageInfo(this.packageName, PackageManager.GET_ACTIVITIES)
        binding.appVersion.text = "Version : "+info.versionName

        val sharedPreferences = this.getSharedPreferences(getString(R.string.login_detail), Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        //Change Icon
        val icon = sharedPreferences?.getString("icon", "").toString()
        binding.contentHome.localShopLogo.setOnClickListener {
            binding.contentHome.iconThemeContainer.visibility=View.VISIBLE
        }
        binding.contentHome.closeIconThemeContainer.setOnClickListener {
            binding.contentHome.iconThemeContainer.visibility=View.INVISIBLE
        }



        getBrandsBannerListStatic()

        //for change whole app color base on app icon select
        if(icon=="1"){
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon1)
            Singleton.getInstance().site_color = "#c4ccfc"
        }
        else if(icon=="2"){
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon2)
            Singleton.getInstance().site_color = "#ffc4d4"
        }
        else{
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon3)
            Singleton.getInstance().site_color = "#e42c2c"
        }

        binding.navHeaderHome.navHeaderContainer.setBackgroundColor(Color.parseColor(Singleton.getInstance().site_color.replace(" ", "")))
        window.statusBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))
        window.navigationBarColor = Color.parseColor(Singleton.getInstance().site_color.replace(" ", ""))



        //for change app icon color and app close and again open app
        binding.contentHome.icon1Background.setOnClickListener {
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon1)
            editor.putString("icon","1").apply()
            appIcon1()
        }
        binding.contentHome.icon2Background.setOnClickListener {
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon2)
            editor.putString("icon","2").apply()
            appIcon2()
        }
        binding.contentHome.icon3Background.setOnClickListener {
            binding.contentHome.icon1Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon2Background.setBackgroundColor(Color.parseColor("#FFFFFF"))
            binding.contentHome.icon3Background.setBackgroundColor(Color.parseColor("#9FCDF1"))
            binding.contentHome.localShopLogo.setImageResource(R.drawable.app_icon3)
            editor.putString("icon","3").apply()
            appIcon3()
        }



        binding.contentHome.logout.setOnClickListener {
            logout()
        }

        binding.contentHome.volley.setOnClickListener {
            val intent1 = Intent(this, MyVolleyActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.retrofit.setOnClickListener {
            val intent1 = Intent(this, NewRetrofitActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.retrofit2.setOnClickListener {
            val intent1 = Intent(this, NewRetrofitActivity2::class.java)
            startActivity(intent1)
        }
        binding.contentHome.cartActivity.setOnClickListener {
            val intent1 = Intent(this, AddCartProductsActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.searchFilter.setOnClickListener {
            val intent1 = Intent(this, SearchProductsActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.loadMore.setOnClickListener {
            val intent1 = Intent(this, LoadMoreRecycleViewActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.mvvm.setOnClickListener {
            val intent1 = Intent(this, MainActivity::class.java)
            startActivity(intent1)
        }
        binding.contentHome.whatson.setOnClickListener {
            val intent1 = Intent(this, WhatsonActivity::class.java)
            startActivity(intent1)
        }


        //                          To Access Nav Header
        /*val viewHeader = binding.navView.getHeaderView(0)
        // nav_header.xml is headerLayout
        val navViewHeaderBinding : NavHeaderHomeBinding = NavHeaderHomeBinding.bind(viewHeader)
        // userNameTitle is Children of nav_header
        navViewHeaderBinding.lblUserName.text = "Hi, D!"*/
        binding.navHeaderHome.lblUserName.text = "Hi, DP!"

        //--------------------------Navigation Drawer And Bar
        binding.navView.menu.findItem(R.id.setting_option).setActionView(R.layout.menu_down)
        binding.navView.setNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.setting_option -> {
                    if(!isMemberVisible){
                        binding.navView.menu.findItem(R.id.setting_option).setActionView(R.layout.menu_up)
                        binding.navView.menu.setGroupVisible(R.id.memberBehavior, true)
                        isMemberVisible=true
                    }
                    else{
                        binding.navView.menu.findItem(R.id.setting_option).setActionView(R.layout.menu_down)
                        binding.navView.menu.setGroupVisible(R.id.memberBehavior, false)
                        isMemberVisible=false
                    }
                    true
                }
                else -> false
            }
        }



    }

    private fun appIcon1() {
        Log.i("My --------------------", "appIcon1() called")
        val pm = packageManager
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity3"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.SplashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        val handler = Handler()
        handler.postDelayed({
            //recreate()
            val intent1 = Intent(this, HomeActivity::class.java)
            startActivity(intent1)
            finish()
        },2700)
        //Toast.makeText(this@HomeActivity, "Enable Old Icon", Toast.LENGTH_LONG).show()
    }
    private fun appIcon2() {
        Log.i("My --------------------", "appIcon2() called")
        val pm = packageManager
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.SplashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity3"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        val handler = Handler()
        handler.postDelayed({
            //recreate()
            val intent1 = Intent(this, HomeActivity::class.java)
            startActivity(intent1)
            finish()
        },2700)
        //Toast.makeText(this@HomeActivity, "Enable New Icon", Toast.LENGTH_LONG).show()
    }
    private fun appIcon3() {
        Log.i("My --------------------", "appIcon3() called")
        val pm = packageManager
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.SplashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        pm.setComponentEnabledSetting(
            ComponentName("com.demomvvm", "com.demomvvm.Register_Login.splashActivity3"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        val handler = Handler()
        handler.postDelayed({
            //recreate()
            val intent1 = Intent(this, HomeActivity::class.java)
            startActivity(intent1)
            finish()
        },2700)
        //Toast.makeText(this@HomeActivity, "Enable New Icon", Toast.LENGTH_LONG).show()
    }



    private fun logout() {
        Log.i("My --------------------", "logoutbutton clicked")
        val sharedPreferences = this.getSharedPreferences(getString(R.string.login_detail), Context.MODE_PRIVATE)
        val alertDialog: AlertDialog.Builder = AlertDialog.Builder(this)
        alertDialog.setTitle("Logout")
        alertDialog.setMessage("Do you really want to logout ?")
        alertDialog.setPositiveButton("yes") { _, _ ->
            Log.i("My --------------------", "Yes clicked(logoutbutton)")
            val editor = sharedPreferences.edit()
            editor.clear()
            editor.apply()

            val intent1 = Intent(this, LoginActivity::class.java)
            intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent1)
            finish()
        }
        alertDialog.setNegativeButton("No") { _, _ ->
            Log.i("My --------------------", "No clicked(logoutbutton)")
        }
        val alert: AlertDialog = alertDialog.create()
        alert.setCanceledOnTouchOutside(false)
        alert.show()
    }






    override fun onDestroy() {
        Log.i("My HomeActivity ","onDestroy called")
        super.onDestroy()
    }

    //For No Internet Connection Dialog
    override fun onResume() {
        Log.i("My HomeActivity ","onResume called")
        super.onResume()
        Log.i(TAG, "inside onResume")
        //on resume = every time when any screen come to home screen = on resume again show last screen

        if(sliderHandle2!=null)
        {
            sliderRun2?.let { sliderHandle2?.postDelayed(it,4000) } //for viewpager auto scroll after 3 second
        }
        if(sliderHandle3!=null)
        {
            sliderRun3?.let { sliderHandle3?.postDelayed(it,4000) } //for viewpager auto scroll after 3 second
        }
    }


    override fun onBackPressed() {
        Log.i("My HomeActivity ", "onBackPressed()")
        super.onBackPressed()
    }



    //todo for show Our Brands - app fix banner start
    //for autoscroll viewpage
    fun getBrandsBannerListStatic()
    {

        val networkConnection = Lifemark(applicationContext)
        try {
            if (networkConnection.isNetworkConnected())
            {
                //1.
                //todo for add static list in second banner start

                my_brands_banner_list = ArrayList()
                val ecomapre_banner_dic1 = ViewPagerThirdPojo("1", "101", "manufacturerBannerClick1", getString(R.string.domain_url)+"/images/app/manufacturer/1.png", "https://www.vsbenefitssmitsubishi.com.au/", "")
                val ecomapre_banner_dic2 = ViewPagerThirdPojo("2", "101", "manufacturerBannerClick2", getString(R.string.domain_url)+"/images/app/manufacturer/2.png", "https://www.vsbenefitss.net.au/", "")
                val ecomapre_banner_dic3 = ViewPagerThirdPojo("3", "101", "manufacturerBannerClick3", getString(R.string.domain_url)+"/images/app/manufacturer/3.png", "https://vsbenefitssldv.com.au/", "")
                val ecomapre_banner_dic4 = ViewPagerThirdPojo("4", "101", "manufacturerBannerClick4", getString(R.string.domain_url)+"/images/app/manufacturer/4.png", "https://www.vsbenefitss.net.au", "")

                val ecomapre_banner_dic5 = ViewPagerThirdPojo("5", "101", "manufacturerBannerClick5", getString(R.string.domain_url)+"/images/app/manufacturer/5.png", "https://www.vsbenefitssgwmhaval.com.au/", "")
                val ecomapre_banner_dic6 = ViewPagerThirdPojo("6", "101", "manufacturerBannerClick6", getString(R.string.domain_url)+"/images/app/manufacturer/6.png", "https://www.vsbenefitsssubaru.com.au/", "")
                val ecomapre_banner_dic7 = ViewPagerThirdPojo("7", "101", "manufacturerBannerClick7", getString(R.string.domain_url)+"/images/app/manufacturer/7.png", "https://www.vsbenefitss.net.au/brands/holden", "")
                //val ecomapre_banner_dic8 = ViewPagerThirdPojo("8", "101", "manufacturerBannerClick8", getString(R.string.domain_url)+"/images/app/manufacturer/8.png", "https://www.evmotobrisbane.com.au/", "")
                val ecomapre_banner_dic9 = ViewPagerThirdPojo("9", "101", "manufacturerBannerClick9", getString(R.string.domain_url)+"/images/app/manufacturer/9.png", "https://www.vsbenefitsschery.com.au/", "")

                my_brands_banner_list.add(ecomapre_banner_dic1)
                my_brands_banner_list.add(ecomapre_banner_dic2)
                my_brands_banner_list.add(ecomapre_banner_dic3)
                my_brands_banner_list.add(ecomapre_banner_dic4)
                my_brands_banner_list.add(ecomapre_banner_dic5)
                my_brands_banner_list.add(ecomapre_banner_dic6)
                my_brands_banner_list.add(ecomapre_banner_dic7)
                //my_brands_banner_list.add(ecomapre_banner_dic8)
                my_brands_banner_list.add(ecomapre_banner_dic9)
                //todo for add static list in second banner end


                Log.i(TAG, "getBrandsBannerListStatic binding.viewPager my_brands_banner_list.size  ${my_brands_banner_list.size} ")


                //todo for added viewpager start
                val viewPagerBrandsBanner = binding.contentHome.viewPagerBrandsBanner
                //sliderAdapter = ViewpagerThirdBanner(context!!.applicationContext, viewPagerBrandsBanner, my_second_banner_list)
                sliderAdapter = ViewpagerThirdBanner(this@HomeActivity, viewPagerBrandsBanner, my_brands_banner_list, "brands")
                /*sliderAdapter = ViewpagerThirdBanner(this@HomeActivity, viewPagerBrandsBanner, my_second_banner_list, "home", "secondbanner", ThirdBannerECompareAdapter.OnItemClickListener() { bannerEComparePojo: BannerEComparePojo, indexPos: Int, objectName: String, viewobject: View ->
                }))*/
                viewPagerBrandsBanner.adapter = sliderAdapter


                //todo for binding.contentHome.imgLeftarrowBrand left,right click start
                if(my_brands_banner_list.size==1)
                {
                    //when only two item = remove left/right arrow
                    binding.contentHome.imgLeftarrowBrand.setVisibility(View.GONE)
                    binding.contentHome.imgLeftarrowBrand.setVisibility(View.GONE)
                }
                //for viewPagerBrandsBanner - left,right image event
                binding.contentHome.imgLeftarrowBrand.setOnClickListener{
                    Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgLeftarrowBrand = new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem)
                    var tab = viewPagerBrandsBanner?.currentItem
                    if (tab != null) {
                        if (tab > 0) {
                            tab--
                            viewPagerBrandsBanner?.currentItem = tab
                        }
                        else if (tab == 0) {
                            viewPagerBrandsBanner?.currentItem = tab
                            //binding.imgLeftarrow.setVisibility(View.GONE)
                        }
                        Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgLeftarrowBrand = tab is not null new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                    }
                    else
                    {
                        Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgLeftarrowBrand = tab is null new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                    }

                    binding.contentHome.imgRightarrowBrand.setVisibility(View.VISIBLE)
                    Log.i(TAG, "getBrandsBannerListStatic new binding.contentHome.imgLeftarrowBrand = new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.currentItem.size = "+my_brands_banner_list.size)

                }

                binding.contentHome.imgRightarrowBrand.setOnClickListener{
                    Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgRightarrowBrand = viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)


                    var tab = viewPagerBrandsBanner?.currentItem
                    if (tab != null) {
                        Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgRightarrowBrand = tab is not null new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                        tab++
                        viewPagerBrandsBanner?.currentItem = tab
                    }
                    else
                    {
                        Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgRightarrowBrand = tab is null new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                    }
                    binding.contentHome.imgLeftarrowBrand.setVisibility(View.VISIBLE)

                    Log.i(TAG, "getBrandsBannerListStatic binding.contentHome.imgRightarrowBrand = new viewPagerBrandsBanner.currentItem = "+viewPagerBrandsBanner?.currentItem+" and tab = "+tab+" and viewPagerBrandsBanner.size = "+my_brands_banner_list.size)
                }

                //todo for binding.contentHome.imgLeftarrowBrand left,right click end




                //for auto scroll viewpage
                viewPagerBrandsBanner.clipToPadding = false  //comment this for only 1 image(padding 20)
                viewPagerBrandsBanner.clipChildren = false //comment this for only 1 image(padding 20)
                viewPagerBrandsBanner.offscreenPageLimit = 3 //comment this for only 1 image(padding 20)
                viewPagerBrandsBanner.getChildAt(0).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
                val comPosPageTarn = CompositePageTransformer()
                //viewPagerThirdBanner.setPageTransformer(MarginPageTransformer(40)) //or
                comPosPageTarn.addTransformer(MarginPageTransformer(40))
                comPosPageTarn.addTransformer { page, position ->
                    val r:Float = 1 - Math.abs(position)
                    page.scaleY = 0.85f + r * 0.15f
                }
                viewPagerBrandsBanner.setPageTransformer(comPosPageTarn)
                sliderHandle2 = Handler()
                sliderRun2 = Runnable {
                    viewPagerBrandsBanner.currentItem = viewPagerBrandsBanner.currentItem+1
                }

                //for autoscroll item at every 3 second
                viewPagerBrandsBanner.registerOnPageChangeCallback(
                    object : ViewPager2.OnPageChangeCallback(){
                        override fun onPageSelected(position: Int) {
                            sliderHandle2!!.removeCallbacks(sliderRun2!!)
                            sliderHandle2!!.postDelayed(sliderRun2!!,4000)
                        }
                    }
                )
                //todo for added viewpager end

            }
            else
            {
                // do something when device disconnected to internet
                ToastyWarning(getString(R.string.no_internet_message))
            }
        }
        catch (ex: Exception)
        {
            Log.i(TAG, "getSecondBannerListStatic Error in catch getDataCardList ex = " + ex)
        }

    }
    //todo for show Our Brands - app fix banner end

    public fun ToastyWarning(s: String) {
        //Toasty.warning(this,s,Toasty.LENGTH_SHORT).show()
        Toasty.warning(applicationContext,s, Toasty.LENGTH_SHORT).show()
    }
    public fun ToastySuccess(s: String) {
        //Toasty.success(this,s,Toasty.LENGTH_SHORT).show()
        Toasty.success(applicationContext,s, Toasty.LENGTH_SHORT).show()
    }
    
    
}