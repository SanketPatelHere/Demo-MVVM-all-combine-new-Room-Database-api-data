package com.demomvvm.HomePageECompareBanner;

//home page first banner, second banner pojo, use in travel using json
public class BannerEComparePojo {

    public String id;
    public String site_id;
    public String banner_name;
    public String banner_image;
    public String banner_link;
    public String status;
    public String banner_cat;
    public String banner_logo_image;

    public BannerEComparePojo()
    {

    }

    public BannerEComparePojo(String id, String site_id, String banner_name, String banner_image, String banner_link, String status) {
        this.id = id;
        this.site_id = site_id;
        this.banner_name = banner_name;
        this.banner_image = banner_image;
        this.banner_link = banner_link;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSite_id() {
        return site_id;
    }

    public void setSite_id(String site_id) {
        this.site_id = site_id;
    }

    public String getBanner_name() {
        return banner_name;
    }

    public void setBanner_name(String banner_name) {
        this.banner_name = banner_name;
    }

    public String getBanner_image() {
        return banner_image;
    }

    public void setBanner_image(String banner_image) {
        this.banner_image = banner_image;
    }

    public String getBanner_link() {
        return banner_link;
    }

    public void setBanner_link(String banner_link) {
        this.banner_link = banner_link;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBanner_cat() {
        return banner_cat;
    }

    public void setBanner_cat(String banner_cat) {
        this.banner_cat = banner_cat;
    }

    public String getBanner_logo_image() {
        return banner_logo_image;
    }

    public void setBanner_logo_image(String banner_logo_image) {
        this.banner_logo_image = banner_logo_image;
    }
}
